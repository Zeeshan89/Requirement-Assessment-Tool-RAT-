<?php
  ob_start();
  session_start();
  require_once 'database1.php';
  if( !isset($_SESSION['user']) ) {
    header("Location: ../../index.php");
    exit;
  }
  // if session is not set this will redirect to login page
  
  // select loggedin users detail
  $res=mysqli_query($connection,"SELECT * FROM users WHERE userId=".$_SESSION['user']);
   while ($userRow=mysqli_fetch_array($res)) {
  $name=$userRow['userName'];
  $email=$userRow['userEmail'];

  } 
?><!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Welcome - <?php echo $name; ?></title>
<link rel="stylesheet" type="text/css" href="assets/css/bootstrap.css">
<link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="assets/css/bootstrap.theme.min.css">
<link rel="stylesheet" type="text/css" href="assets/css/bootstrap.theme.css">
<script type="text/javascript" src="assets/js/bootstrap.js"></script>
<script type="text/javascript" src="assets/js/bootstrap.min.js"></script>
<script type="text/javascript" src="assets/jquery/jquery.min.js"></script>

<script type="text/javascript" src="assets/js/modal.js"></script>
<script type="text/javascript" src="assets/js/collapse.js"></script>

<script type="text/javascript" src="assets/js/tab.js"></script>
<script type="text/javascript" src="assets/js/dropdown.js"></script>
<style>
  body {
      font: 400 15px Lato, sans-serif;
      line-height: 1.8;

  }
  h2 {
      font-size: 24px;
      text-transform: uppercase;
      color: #303030;
      font-weight: 600;
      margin-bottom: 30px;
  }
  h4 {
      font-size: 19px;
      line-height: 1.375em;
      color: #303030;
      font-weight: 400;
      margin-bottom: 30px;
  }  
  .jumbotron {
      background-color:black;
      color: #fff;
      padding: 100px 25px;
      font-family: Montserrat, sans-serif;
  }
  .container-fluid {
      padding: 60px 50px;
  }
  .bg-grey {
      background-color: #f6f6f6;
  }
  .logo-small {
      color: #330033;
      font-size: 50px;
  }
  .logo {
    margin-top: 120px;
      color: black;
      font-size: 200px;
  }
  .thumbnail {
      padding: 0 0 15px 0;
      border: none;
      border-radius: 0;
  }
  .thumbnail img {
      width: 100%;
      height: 100%;
      margin-bottom: 10px;
  }
  .carousel-control.right, .carousel-control.left {
      background-image: none;
      color: #f4511e;
  }
  .carousel-indicators li {
      border-color: #f4511e;
  }
  .carousel-indicators li.active {
      background-color: #f4511e;
  }
  .item h4 {
      font-size: 19px;
      line-height: 1.375em;
      font-weight: 400;
      font-style: italic;
      margin: 70px 0;
  }
  .item span {
      font-style: normal;
  }
  .panel {
      border: 1px solid #f4511e; 
      border-radius:0 !important;
      transition: box-shadow 0.5s;
  }
  .panel:hover {
      box-shadow: 5px 0px 40px rgba(0,0,0, .2);
  }
  .panel-footer .btn:hover {
      border: 1px solid #330033;
      background-color: #fff !important;
      color: #330033;
  }
  .panel-heading {
      color: #fff !important;
      background-color: #f4511e !important;
      padding: 25px;
      border-bottom: 1px solid transparent;
      border-top-left-radius: 0px;
      border-top-right-radius: 0px;
      border-bottom-left-radius: 0px;
      border-bottom-right-radius: 0px;
  }
  .panel-footer {
      background-color: white !important;
  }
  .panel-footer h3 {
      font-size: 32px;
  }
  .panel-footer h4 {
      color: #aaa;
      font-size: 14px;
  }
  .panel-footer .btn {
      margin: 10px 10px;
      background-color: #330033;
      color: #fff;
  }
  .navbar {
      margin-bottom: 0;
      background-color: purple;
      z-index: 9999;
      border: 0;
      font-size: 12px !important;
      line-height: 1.42857143 !important;
      letter-spacing: 4px;
      border-radius: 0;
      font-family: Montserrat, sans-serif;
  }

  .navbar li a, .navbar  {
     
  }
  .navbar-nav li a:hover, .navbar-nav li.active a {
      color: #330033 !important;
      background-color: #E8DAEF !important;
  }
  .navbar-default .navbar-toggle {
      border-color: transparent;
      color: #fff !important;
  }


  footer.glyphicon {
      font-size: 20px;
      margin-bottom: 20px;
      color: #330033;
  }
  .slideanim {visibility:hidden;}
  .slide {
      animation-name: slide;
      -webkit-animation-name: slide;
      animation-duration: 1s;
      -webkit-animation-duration: 1s;
      visibility: visible;
  }
  @keyframes slide {
    0% {
      opacity: 0;
      transform: translateY(70%);
    } 
    100% {
      opacity: 1;
      transform: translateY(0%);
    }
  }
  @-webkit-keyframes slide {
    0% {
      opacity: 0;
      -webkit-transform: translateY(70%);
    } 
    100% {
      opacity: 1;
      -webkit-transform: translateY(0%);
    }
  }
  @media screen and (max-width: 768px) {
    .col-sm-4 {
      text-align: center;
      margin: 25px 0;
    }
    .btn-lg {
        width: 100%;
        margin-bottom: 35px;
    }
  }
  @media screen and (max-width: 480px) {
    .logo {
        font-size: 150px;
    }
  }

.alignmnt{
  margin-top: 100px;
  
}

  </style>
  <script type="text/javascript" src="assets/js/transition.js"></script>
</head>
<body id="myPage" data-spy="scroll"  data-offset="60">

  <nav class="navbar navbar-default navbar-fixed-top">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
              <a class="navbar-brand" href="../main.php" style="margin-top: -9px;">
        <img alt="Brand" src="pic.jpg" width="60px" height="40px">
      </a>
      
        
        </div>
          <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav">
            <li ><a href="../main.php" style="color: #fff;">Home</a></li>
            <li><a href="#myModal" data-toggle="modal" style="color: #fff;">Trigger words</a></li> 
          </ul>
          <ul class="nav navbar-nav navbar-right"> 
          
            <li class="dropdown ">
              <a href="#" style="color: #fff;" class=" dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false" data-target="dropdown-item">
         <span class="glyphicon glyphicon-user"></span>&nbsp;Hi' <?php echo $name; ?>&nbsp;<span class="caret"></span></a>
              <ul class="dropdown-menu ">
                <li class="dropdown-item " ><a href="logout.php?logout"><span class="glyphicon glyphicon-log-out"></span>&nbsp;Sign Out</a></li>
              </ul>
            </li>
          </ul>
        </div><!--/.nav-collapse -->
      </div>
    </nav> 
    <nav>

<br>


  <!-- Modal -->
  <div class="modal fade" id="myModal"  role="dialog">
    <div class="modal-dialog modal-lg">
    
      <!-- Modal content-->
      <br>
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Trigger Words for SRS</h4>
        </div>
        <div class="modal-body">
          
<ul class="nav nav-tabs">
    <li class="active"><a data-toggle="tab"  class="btn btn-lg" href="#home">Imperatives</a></li>
    
    <li><a data-toggle="tab" class="btn btn-lg" href="#menu1">Vagues</a></li>
 
    <li><a data-toggle="tab"  class="btn btn-lg" href="#menu3">Directives</a></li>

     <li><a data-toggle="tab" class="btn btn-lg" href="#menu5">Universal Quantifiers</a></li>
  </ul>

  <div class="tab-content">
    <div id="home" class="tab-pane fade in active">
      <h3>Imperatives</h3>
      <p> Imperatives are words and phrases that command something must be done <br> RAT scores each requirement based on following best practice: <br> A proper requirement must contain one imperative. <br> <b> Recommendation: </b> Split the requirement with more than one imperative into multiple requirements.</p><br>
      <li>shall</li><li>will</li><li>Responsible for</li>
      <li>must</li><li>required to</li><li>are applicable</li><li>are too</li>
    </div>
    <div id="menu1" class="tab-pane fade">
      <h3>Vagues</h3>
      <p> Vagues words are imprecise, ambigious and unclear, leaving room for multiple interpretations, which significantly increases risks. Weak Phrases is the category of clauses that are apt to cause uncertainty and leave room for multiple interpretations. Use of phrases such as 'adequate' and 'as appropriate' indicate that what is required is either defined elsewhere or, worse, that the requirement is open to subjective interpretation. Phrases such as 'but not limited to' and 'as a minimum' provide a basis for expanding a requirement or adding future requirements. <br> RAT scores each requirement based on following best practice: <br> A proper requirement does not use vague words or phrases. <br> <b> Recommendation: </b> Restate the requirements with vague words as one or more requirements with clear and definite intent. <br></p><br>
          <li>adequate</li><li>appropriate</li><li>bad</li>
      <li>as small</li><li>consistent with</li><li>easy</li><li>enough</li>
    </div>
   
    <div id="menu3" class="tab-pane fade">
      <h3>Directives</h3>
      <p> Directives are the words and phrases pointing to the information that strengthen and clarify the specification as examples, tables, figures or refrences to the other section in document <br> RAT scores each requirement based on following best practice: <br> A proper requiremnt use directives to increase understanding and clarify of context <br> <b> Note: </b> Some requirements may be sufficiently concise and directives may not be required.</p><br>
      <li>for example</li><li>figure</li><li>table</li>
      <li>note:</li><li>e.g.</li><li>i.e.</li>
    </div>
    
     <div id="menu5" class="tab-pane fade">
      <h3>Universal Quantifiers</h3>
      <p> Universal quantifier are the words and phrases that generalize quantity or quantities relating to a subject. <br> These words should be used carefully and sparingly as they make requirement difficult or impossible to verify without thorough understanding of the context. <br>  <b> Recommendation: </b>Unless avoidable, aim to restate the requirement with specific values for any quantities mentioned.</p>
  <li>most</li><li>every</li><li>none</li>
      <li>never</li><li>nothing</li><li>many</li><li>usually</li>

    </div>
  </div>

        </div>
        <div class="modal-footer">

          <button type="button" class="btn btn-primary" data-dismiss="modal">Close</button>
        </div>
      </div>
      
    </div>
  </div>



<div class=" panel-footer alignmnt" >
<form method="post" action="index.php" enctype="multipart/form-data" class="form-inline" >
        <table style="margin: auto;"  align="center">
  <tr>
    <td style="padding-right: 18px; font-size: 15px; " class="form-control"><b>Query file</b></td>
      <td><input class="form-control" type="file" name="qrfile"></td>
    </tr>
    
    <tr>
      <td align="center" >
        <input class="btn "  type="submit"  name="submit"> </td>
        <td> <input class="btn" type="submit"  name="Quality" value="Quality"></td>
        
    </tr>
 </table>
       </div>
       
    
 
<?php
require("class.filetotext.php");

include 'database1.php';
  include("highlight function.php");
    

    if(isset($_POST['submit'])){
      
    
     
    $query_file = $_FILES ['qrfile']['name'];
 
    
    $temp_name2 = $_FILES ['qrfile']['tmp_name'];
   
    if($temp_name2==''){
      
      echo "<script> alert('please select the fields')</script>";
      exit();
      
      }
      else
      {
      
      //To upload images we use this command
    
     move_uploaded_file( $temp_name2,"files/$query_file");
   
      
      $insert= "insert into file (name,file)
      
      values('$name','$query_file')";
        $run_query=mysqli_query($connection,$insert);
       
//$abc=mysqli_insert_id($connection);
//echo "<br>$abc";
        if($run_query){

          echo "<script>alert('Document submitted Successfully')</script>";

        if (substr($query_file, -5) == '.docx'){
     


$docObj = new Filetotext("files/$query_file");

$return = $docObj->convertToText();


  #-----

  $text = trim($return); // remove the last \n or whitespace character
$text1 = nl2br($text);

 $string = "$text1";

    $new= $string;
    

// introductio/////////////////////////////////////////
  

 

 $f1=0; $f2=0; $f3=0; $f4=0;
 $nf1=0;$nf2=0;$nf3=0;$nf4=0;$nf5=0;$nf6=0;$nf7=0;$nf8=0;$nf9=0;$nf10=0;$nf11=0;$nf12=0;
 $p1=0; $p2=0; $p3=0; $p4=0;
 $q1=0;$q2=0;$q3=0;$q4=0;


 $re1='(\d)'; # Any Single Character 1
  $re2='(\\.)'; # Any Single Character 2
  $re3='(\\s+)';  # White Space 1
  $re4='(Introduction)';  # Word 1
  
  $ae2='(\\.)';  $ae3='(\d)';
  $ae6='(\\s+)';   $ae7='(Introduction)';  # Word 1
  $first=0;
  $be3='(\d)'; $be6='(\\s+)';  $be7='(Introduction)'; 

  if ($c=preg_match_all ("/".$re1.$re2.$re3.$re4."/is", $new, $matches  ))
  {
    $first++;
  } elseif ($ac=preg_match_all ("/".$ae3.$ae6.$ae7."/is", $new, $matches)) {
    
     $first++;
  }
  
// second chapter////////////////////////////////////////////
  
 $ce1='(\d)'; # Any Single Character 1
  $ce2='(\\.)';
  
  $ce4='(\\s+)';  # White Space 1
  $ce5='(Overall)';  # Word 1
  $ce6='(\\s+)';  # White Space 1
  $ce7='(Description)';
  $ce8='(\\s+)';  # White Space 1
  $ce9='(The)'; 
  
 $de2='(\\.)';   $de3='(\d)'; $de6='(\\s+)';  $de7='(Overall)';$de8='(\\s+)';  $de9='(Description)';

 $second=0;
     
   if ($c=preg_match_all ("/".$ce1.$ce2.$ce4.$ce5.$ce6.$ce7."/is", $new, $matches  ))
  {

    
    $second++;
  } elseif ($ac=preg_match_all ("/".$de3.$de6.$de7.$de8.$de9."/is", $new, $matches)) {
    
     $second++;
  }
  elseif ($ac=preg_match_all ("/".$de3.$de6.$ce9.$ce8.$de7.$de8.$de9."/is", $new, $matches)) {
    
     $second++;
  }
  elseif ($ac=preg_match_all ("/".$de3.$de2.$de6.$ce9.$ce8.$de7.$de8.$de9."/is", $new, $matches)) {
    
     $second++;
  }
  

   $e1='(\d)'; $e2='(\\.)';
   $e4='(\\s+)';   $e5='(General)';  # Word 1
  $e6='(\\s+)';  $e7='(Description)';  $e9='(The)'; 
  
 $d2='(\\.)';   $d3='(\d)'; $d6='(\\s+)';  $d7='(General)';$d8='(\\s+)';  $d9='(Description)';

 
   if ($c=preg_match_all ("/".$e1.$e2.$e4.$e5.$e6.$e7."/is", $new, $matches  ))
  {

    $second++;
  } elseif ($ac=preg_match_all ("/".$d3.$d6.$d7.$d8.$d9."/is", $new, $matches)) {
    
     $second++;
  }
elseif ($ac=preg_match_all ("/".$d3.$d6.$e9.$e4.$e5.$e6.$e7."/is", $new, $matches)) {
    
     $second++;
  }
  elseif ($ac=preg_match_all ("/".$d3.$d2.$d6.$e9.$e4.$e5.$e6.$e7."/is", $new, $matches)) {
    
     $second++;
  }



   $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(System)';  # Word 1
  $b6='(\\s+)';  $b7='(Description)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(System)';$f8='(\\s+)';  $f9='(Description)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $new, $matches  ))
  {

    $second++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $new, $matches)) {
     
     $second++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $new, $matches)) {
     
     $second++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $new, $matches)) {
    
     $second++;
  }
  
// third specific //////////////////////////////////////////////////

  
   $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Specific)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Specific)';$f8='(\\s+)';  $f9='(Requirements)';

 $three=0;
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $new, $matches  ))
  {

   
    $three++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $new, $matches)) {
     $three++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $new, $matches)) {
    
     $three++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $new, $matches)) {
   
     $three++;
  }
  

   $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Technical)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Technical)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $new, $matches  ))
  {

   
   $three++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $new, $matches)) {
     
     $three++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $new, $matches)) {
    
     $three++;
  }
elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $new, $matches)) {
     $three++;
  }

  

   $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Functional)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Functional)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $new, $matches  ))
  {

  
    $f1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $new, $matches)) {
    
     $f2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $new, $matches)) {
 
  $f3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $new, $matches)) {

  $f4++;
  }

  

   $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(System)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(System)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $new, $matches  ))
  {

    $three++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $new, $matches)) {
     $three++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $new, $matches)) {
     $three++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $new, $matches)) {
     $three++;
  }
  
//$txt='3.23.3 Non Functional Requirements';

   $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Non)';  # Word 1
  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$f7.$f8.$b7.$b10.$f9."/is", $new, $matches ))
  {

   
    $nf1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$b7.$b10.$f9."/is", $new, $matches)) {
    
    
     $nf2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $new, $matches)) {
   
     $nf3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $new, $matches)) {
    
     $nf4++;
  }
  
  
   
   $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Non)';  # Word 1 

  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

 $spe=0;
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$a.$b7.$b9.$b11."/is", $new, $matches  ))
  {

    
  
   $nf5++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$a.$b7.$b10.$f9."/is", $new, $matches)) {
    
     $nf6++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $new, $matches)) {
     
     $nf7++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $new, $matches)) {
     $nf8++;
    
  }
  

   $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Non)';  # Word 1 

  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b7.$b9.$b11."/is", $new, $matches  ))
  {

   
    $nf9++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$b7.$b10.$f9."/is", $new, $matches)) {
     $three++;
     $nf10++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $new, $matches)) {
   
    
     $nf11++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $new, $matches)) {
    
    
     $nf12++;
  }


   $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Non)';  # Word 1 

  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $new, $matches  ))
  {
    $three++;
    $p1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $new, $matches)) {
     $three++;
     $p2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $new, $matches)) {
   
     $three++;
     $p3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $new, $matches)) {
    
     $three++;
     $p4++;
  }
  

   $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Non)';  # Word 1 

  $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $new, $matches  ))
  {

    $spe++;
    $q1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $new, $matches)) {
     
     $three++;
     $q2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $new, $matches)) {
     
     $three++;
     $q3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $new, $matches)) {
     $three++;
     $q4++;
  }
 

   $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(System)';  # Word 1
  $b6='(\\s+)';  $b7='(Features)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(System)';$f8='(\\s+)';  $f9='(Features)';

 $spe=0;
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $new, $matches  ))
  {

    $three++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $new, $matches)) {
     $three++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $new, $matches)) {
     $three++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $new, $matches)) {
     $three++;
  }
   $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Requirements)';  # Word 1
  $b6='(\\s+)';  $b7='(Specification)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Requirements)';$f8='(\\s+)';  $f9='(Specification)';


   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $new, $matches  ))
  {
    $three++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $new, $matches)) {
    
    $three++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $new, $matches)) {
     $three++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $new, $matches)) {
     $three++;
  }
  

// Fourth Chapter////////////////////////////////////


   $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Supporting)';  # Word 1
  $b6='(\\s+)';  $b7='(Information)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Supporting)';$f8='(\\s+)';  $f9='(Information)';

 $four=0;
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $new, $matches  ))
  {
    $spe++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $new, $matches)) {

     $four++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $new, $matches)) {
      $four++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $new, $matches)) {
    
      $four++;
  }



   $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Other)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Other)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $new, $matches  ))
  {

     $four++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $new, $matches)) {
     
      $four++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $new, $matches)) {
   
      $four++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $new, $matches)) {
     
      $four++;
  }
  
   $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Appendix)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Appendix)';$f8='(\\s+)';  $f9='(Requirements)';


   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5."/is", $new, $matches  ))
  {

   
     $four++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7."/is", $new, $matches)) {
    
      $four++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7."/is", $new, $matches)) {
    
      $four++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7."/is", $new, $matches)) {
     
      $four++;
  }
  

   $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(References)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(References)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5."/is", $new, $matches  ))
  {

   
     $four++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7."/is", $new, $matches)) {
     
      $four++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7."/is", $new, $matches)) {
    
      $four++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7."/is", $new, $matches)) {
      $four++;
  }
   


   $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Glossary)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Glossary)';


   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5."/is", $new, $matches  ))
  {
$four++;
  
    

  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7."/is", $new, $matches)) {
    
     $four++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7."/is", $new, $matches)) {

      $four++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7."/is", $new, $matches)) {
    
      $four++;
  }
  




echo "<b><br><span style='margin-left:10px;'>Srs completness status: </span> </b>";
if (($first AND $second AND $three AND $four)>0) {
  echo "<br> <span style='margin-left:10px;'>SRS Complete</span>";
  echo "<br><span style='margin-left:10px;'>SRS contains All four sections</span>";
}
elseif (($first AND $second AND $three )>0) {
 echo "<br><span style='margin-left:10px;'>SRS Complete</span>";
  echo "<br><span style='margin-left:10px;'> SRS contains All four sections </span>"; 
}
elseif (($first AND $second )>0) {
  echo "<br><span style='margin-left:10px;'>SRS missing third and fourth section</span>"; 
}
elseif (($first AND $three)>0) {
  echo "<br><span style='margin-left:20px;'>SRS missing Second and fourth section</span>"; 
}
elseif (($first AND $four)>0) {
  echo "<br><span style='margin-left:10px;'>SRS missing Second and third section</span>";  
}
elseif (($second AND $three)>0) {
  echo "<br><span style='margin-left:10px;'>SRS missing first and fourth section</span>"; 
}
elseif (($second AND $four)>0) {
  echo "<br><span style='margin-left:10px;'>SRS missing first and third section</span>"; 
}
elseif (($three AND $four)>0) {
  echo "<br><span style='margin-left:10px;'>SRS missing first and second section</span>"; 
}
elseif (($first AND $second AND $four)>0) {
  echo "<br><span style='margin-left:10px;'>SRS missing third section</span>"; 
}
elseif (($second AND $three AND $four)>0) {
  echo "<br><span style='margin-left:10px;'>SRS missing first section</span>"; 
}
elseif (($first AND $three AND $four)>0) {
  echo "<br><span style='margin-left:10px;'>SRS missing Second section</span>"; 
}
elseif (($first )>0) {
  echo "<br><span style='margin-left:10px;'>SRS missing Second,third and fourth section</span>"; 
}
elseif (($second )>0) {
  echo "<br><span style='margin-left:10px;'>SRS missing First, third and fourth section</span>"; 
}
elseif (($three )>0) {
  echo "<br><span style='margin-left:10px;'>SRS missing First, Second and fourth section</span>"; 
} 
elseif (($four )>0) {
  echo "<br><span style='margin-left:10px;'>SRS missing First, Second and third section</span>"; 
} else{
   echo "<br><span style='margin-left:10px;'>SRS missing all four sections</span>";
}

echo "<br>";

if ((($f1 OR $f2 OR $f3 OR $f4) AND ( $nf1 OR $nf2 OR $nf3 OR $nf4 OR $nf5 OR $nf6 OR $nf7 OR $nf8 OR $nf9 OR $nf10 OR $nf11 OR $nf12) AND ($p1 OR $p2 OR $p3 OR $p4) AND ($q1 OR $q2 OR $q3 OR $q4)) >0) {
 echo "<b><br><span style='margin-left:10px;'>Srs contains:</span></b><br>";
 echo "<div style='margin-left:20px;'><li> Functional Requirements</li></div> ";
  echo "<div style='margin-left:20px;'><li> Non Functional Requirements </li></div> ";
   echo "<div style='margin-left:20px;'><li> Performance Requirements</li></div> ";
    echo "<div style='margin-left:20px;'><li> Quality Requirements </li></div> ";
}


elseif ((($f1 OR $f2 OR $f3 OR $f4) AND ( $nf1 OR $nf2 OR $nf3 OR $nf4 OR $nf5 OR $nf6 OR $nf7 OR $nf8 OR $nf9 OR $nf10 OR $nf11 OR $nf12) AND ($p1 OR $p2 OR $p3 OR $p4)) >0) {
 echo "<b><br><span style='margin-left:20px;'>Srs contains:</span></b><br>";
 echo "<div style='margin-left:20px;'><li> Functional Requirements</li></div> ";
  echo "<div style='margin-left:20px;'><li> Non Functional Requirements</li></div>";
   echo "<div style='margin-left:20px;'><li> Performance Requirements</li></div> ";
  
}

elseif ((($f1 OR $f2 OR $f3 OR $f4) AND ($q1 OR $q2 OR $q3 OR $q4)) >0) {
 echo "<b><br><span style='margin-left:20px;'>Srs contains:</span></b><br>";
 echo "<div style='margin-left:20px;'><li> Functional Requirements</li> </div>";
    echo "<div style='margin-left:20px;'><li> Quality Requirements</li></div> ";
}
elseif ((($f1 OR $f2 OR $f3 OR $f4) AND ($p1 OR $p2 OR $p3 OR $p4)>0)) {
 echo "<b><br><span style='margin-left:20px;'>Srs contains:</span></b><br>";
 echo "<div style='margin-left:20px;'><li> Functional Requirements</li></div> ";
 echo "<div style='margin-left:20px;'><li> Performance Requirements</li> </div>";
    
}
elseif ((($f1 OR $f2 OR $f3 OR $f4) AND ( $nf1 OR $nf2 OR $nf3 OR $nf4 OR $nf5 OR $nf6 OR $nf7 OR $nf8 OR $nf9 OR $nf10 OR $nf11 OR $nf12) >0)) {
 echo "<b><br><span style='margin-left:20px;'>Srs contains:</span></b><br>";
 echo "<div style='margin-left:20px;'><li> Functional Requirements</li></span> ";
  echo "<div style='margin-left:20px;'><li> Non Functional Requirements</li> </div>";
    
}
elseif ((($f1 OR $f2 OR $f3 OR $f4) >0)) {
  echo "<b><br><span style='margin-left:20px;'>Srs contains:</span></b><br>";
 echo "<div style='margin-left:20px;'><li> Functional Requirements</li></div> ";
    
}
elseif ((( $nf1 OR $nf2 OR $nf3 OR $nf4 OR $nf5 OR $nf6 OR $nf7 OR $nf8 OR $nf9 OR $nf10 OR $nf11 OR $nf12) >0)) {
  echo "<b><br><span style='margin-left:20px;'>Srs contains:</span></b><br>";

  echo "<div style='margin-left:20px;'><li> Non Functional Requirements</li></div> ";
    
}
elseif (( ($p1 OR $p2 OR $p3 OR $p4) AND ($q1 OR $q2 OR $q3 OR $q4)) >0) {
 echo "<b><br><span style='margin-left:20px;'>Srs contains:<span></b><br>";
   echo "<div style='margin-left:20px;'><li> Performance Requirements</li></div> ";
    echo "<div style='margin-left:20px;'><li> Quality Requirements</li></div>";
}

elseif ((  ($q1 OR $q2 OR $q3 OR $q4)) >0) {
 echo "<b><br><span style='margin-left:20px;'>Srs contains:</span></b><br>";

    echo "<div style='margin-left:20px;'><li> Quality Requirements</li></div> ";
}elseif (( ($p1 OR $p2 OR $p3 OR $p4)) >0) {
 echo "<b><br><span style='margin-left:20px;'>Srs contains:</span></b><br>";
   echo "<div style='margin-left:20px;'><li> Performance Requirements</li></div> ";
   
}

elseif ((( $nf1 OR $nf2 OR $nf3 OR $nf4 OR $nf5 OR $nf6 OR $nf7 OR $nf8 OR $nf9 OR $nf10 OR $nf11 OR $nf12) AND  ($q1 OR $q2 OR $q3 OR $q4)) >0) {
 echo "<b><br> <span style='margin-left:20px;'>Srs contains:</span></b><br>";
 
  echo "<div style='margin-left:20px;'><li> Non Functional Requirements</li></div> ";
 
    echo "<div style='margin-left:20px;'><li> Quality Requirements</li></div>";
}

elseif (( ( $nf1 OR $nf2 OR $nf3 OR $nf4 OR $nf5 OR $nf6 OR $nf7 OR $nf8 OR $nf9 OR $nf10 OR $nf11 OR $nf12) AND ($p1 OR $p2 OR $p3 OR $p4) ) >0) {
 echo "<b><br><span style='margin-left:20px;'>Srs contains:</span></b><br>";
 echo "<div style='margin-left:20px;'><li> Functional Requirements</li> </div>";
  echo "<div style='margin-left:20px;'><li> Non Functional Requirements</li></div>";
   echo "<div style='margin-left:20px;'><li> Performance Requirements</li> </div>";
 
}
elseif (( ( $nf1 OR $nf2 OR $nf3 OR $nf4 OR $nf5 OR $nf6 OR $nf7 OR $nf8 OR $nf9 OR $nf10 OR $nf11 OR $nf12)) >0) {
 echo "<b><br><span style='margin-left:20px;'>Srs contains:</span></b><br>";

  echo "<div style='margin-left:20px;'><li> Non Functional Requirements</li> </div>";
 
}
elseif ((($f1 OR $f2 OR $f3 OR $f4) AND ($p1 OR $p2 OR $p3 OR $p4) AND ($q1 OR $q2 OR $q3 OR $q4)) >0) {
 echo "<b><br><span style='margin-left:20px;'>Srs contains:</span></b><br>";
 echo "<div style='margin-left:20px;'><li> Functional Requirements</li></div> ";

   echo "<div style='margin-left:20px;'><li> Performance Requirements</li></div>";
    echo "<div style='margin-left:20px;'><li> Quality Requirements</li></div>";
}






}elseif (substr($query_file, -4) == '.doc') {
  require 'Docx/fun.class.php';
           $docObj = new Filetotext("files/$query_file");
//$docObj = new Filetotext("test.pdf");

$return = $docObj->convertToText();

$text = trim($return); // remove the last \n or whitespace character
$text1 = nl2br($text);
 $string = "$text1";
 $new=$string;



 $f1=0; $f2=0; $f3=0; $f4=0;
 $nf1=0;$nf2=0;$nf3=0;$nf4=0;$nf5=0;$nf6=0;$nf7=0;$nf8=0;$nf9=0;$nf10=0;$nf11=0;$nf12=0;
 $p1=0; $p2=0; $p3=0; $p4=0;
 $q1=0;$q2=0;$q3=0;$q4=0;


 $re1='(\d)'; # Any Single Character 1
  $re2='(\\.)'; # Any Single Character 2
  $re3='(\\s+)';  # White Space 1
  $re4='(Introduction)';  # Word 1
  
  $ae2='(\\.)';  $ae3='(\d)';
  $ae6='(\\s+)';   $ae7='(Introduction)';  # Word 1
  $first=0;
  $be3='(\d)'; $be6='(\\s+)';  $be7='(Introduction)'; 

  if ($c=preg_match_all ("/".$re1.$re2.$re3.$re4."/is", $new, $matches  ))
  {
    $first++;
  } elseif ($ac=preg_match_all ("/".$ae3.$ae6.$ae7."/is", $new, $matches)) {
    
     $first++;
  }
  
// second chapter////////////////////////////////////////////
  
 $ce1='(\d)'; # Any Single Character 1
  $ce2='(\\.)';
  
  $ce4='(\\s+)';  # White Space 1
  $ce5='(Overall)';  # Word 1
  $ce6='(\\s+)';  # White Space 1
  $ce7='(Description)';
  $ce8='(\\s+)';  # White Space 1
  $ce9='(The)'; 
  
 $de2='(\\.)';   $de3='(\d)'; $de6='(\\s+)';  $de7='(Overall)';$de8='(\\s+)';  $de9='(Description)';

 $second=0;
     
   if ($c=preg_match_all ("/".$ce1.$ce2.$ce4.$ce5.$ce6.$ce7."/is", $new, $matches  ))
  {

    
    $second++;
  } elseif ($ac=preg_match_all ("/".$de3.$de6.$de7.$de8.$de9."/is", $new, $matches)) {
    
     $second++;
  }
  elseif ($ac=preg_match_all ("/".$de3.$de6.$ce9.$ce8.$de7.$de8.$de9."/is", $new, $matches)) {
    
     $second++;
  }
  elseif ($ac=preg_match_all ("/".$de3.$de2.$de6.$ce9.$ce8.$de7.$de8.$de9."/is", $new, $matches)) {
    
     $second++;
  }
  

   $e1='(\d)'; $e2='(\\.)';
   $e4='(\\s+)';   $e5='(General)';  # Word 1
  $e6='(\\s+)';  $e7='(Description)';  $e9='(The)'; 
  
 $d2='(\\.)';   $d3='(\d)'; $d6='(\\s+)';  $d7='(General)';$d8='(\\s+)';  $d9='(Description)';

 
   if ($c=preg_match_all ("/".$e1.$e2.$e4.$e5.$e6.$e7."/is", $new, $matches  ))
  {

    $second++;
  } elseif ($ac=preg_match_all ("/".$d3.$d6.$d7.$d8.$d9."/is", $new, $matches)) {
    
     $second++;
  }
elseif ($ac=preg_match_all ("/".$d3.$d6.$e9.$e4.$e5.$e6.$e7."/is", $new, $matches)) {
    
     $second++;
  }
  elseif ($ac=preg_match_all ("/".$d3.$d2.$d6.$e9.$e4.$e5.$e6.$e7."/is", $new, $matches)) {
    
     $second++;
  }



   $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(System)';  # Word 1
  $b6='(\\s+)';  $b7='(Description)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(System)';$f8='(\\s+)';  $f9='(Description)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $new, $matches  ))
  {

    $second++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $new, $matches)) {
     
     $second++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $new, $matches)) {
     
     $second++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $new, $matches)) {
    
     $second++;
  }
  
// third specific //////////////////////////////////////////////////

  
   $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Specific)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Specific)';$f8='(\\s+)';  $f9='(Requirements)';

 $three=0;
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $new, $matches  ))
  {

   
    $three++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $new, $matches)) {
     $three++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $new, $matches)) {
    
     $three++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $new, $matches)) {
   
     $three++;
  }
  

   $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Technical)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Technical)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $new, $matches  ))
  {

   
   $three++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $new, $matches)) {
     
     $three++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $new, $matches)) {
    
     $three++;
  }
elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $new, $matches)) {
     $three++;
  }

  

   $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Functional)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Functional)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $new, $matches  ))
  {

  
    $f1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $new, $matches)) {
    
     $f2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $new, $matches)) {
 
  $f3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $new, $matches)) {

  $f4++;
  }

  

   $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(System)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(System)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $new, $matches  ))
  {

    $three++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $new, $matches)) {
     $three++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $new, $matches)) {
     $three++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $new, $matches)) {
     $three++;
  }
  
//$txt='3.23.3 Non Functional Requirements';

   $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Non)';  # Word 1
  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$f7.$f8.$b7.$b10.$f9."/is", $new, $matches ))
  {

   
    $nf1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$b7.$b10.$f9."/is", $new, $matches)) {
    
    
     $nf2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $new, $matches)) {
   
     $nf3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $new, $matches)) {
    
     $nf4++;
  }
  
  
   
   $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Non)';  # Word 1 

  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

 $spe=0;
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$a.$b7.$b9.$b11."/is", $new, $matches  ))
  {

    
  
   $nf5++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$a.$b7.$b10.$f9."/is", $new, $matches)) {
    
     $nf6++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $new, $matches)) {
     
     $nf7++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $new, $matches)) {
     $nf8++;
    
  }
  

   $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Non)';  # Word 1 

  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b7.$b9.$b11."/is", $new, $matches  ))
  {

   
    $nf9++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$b7.$b10.$f9."/is", $new, $matches)) {
     $three++;
     $nf10++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $new, $matches)) {
   
    
     $nf11++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $new, $matches)) {
    
    
     $nf12++;
  }


   $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Non)';  # Word 1 

  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $new, $matches  ))
  {
    $three++;
    $p1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $new, $matches)) {
     $three++;
     $p2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $new, $matches)) {
   
     $three++;
     $p3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $new, $matches)) {
    
     $three++;
     $p4++;
  }
  

   $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Non)';  # Word 1 

  $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $new, $matches  ))
  {

    $spe++;
    $q1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $new, $matches)) {
     
     $three++;
     $q2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $new, $matches)) {
     
     $three++;
     $q3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $new, $matches)) {
     $three++;
     $q4++;
  }
 

   $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(System)';  # Word 1
  $b6='(\\s+)';  $b7='(Features)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(System)';$f8='(\\s+)';  $f9='(Features)';

 $spe=0;
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $new, $matches  ))
  {

    $three++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $new, $matches)) {
     $three++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $new, $matches)) {
     $three++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $new, $matches)) {
     $three++;
  }
   $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Requirements)';  # Word 1
  $b6='(\\s+)';  $b7='(Specification)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Requirements)';$f8='(\\s+)';  $f9='(Specification)';


   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $new, $matches  ))
  {
    $three++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $new, $matches)) {
    
    $three++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $new, $matches)) {
     $three++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $new, $matches)) {
     $three++;
  }
  

// Fourth Chapter////////////////////////////////////


   $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Supporting)';  # Word 1
  $b6='(\\s+)';  $b7='(Information)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Supporting)';$f8='(\\s+)';  $f9='(Information)';

 $four=0;
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $new, $matches  ))
  {
    $spe++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $new, $matches)) {

     $four++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $new, $matches)) {
      $four++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $new, $matches)) {
    
      $four++;
  }



   $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Other)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Other)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $new, $matches  ))
  {

     $four++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $new, $matches)) {
     
      $four++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $new, $matches)) {
   
      $four++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $new, $matches)) {
     
      $four++;
  }
  
   $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Appendix)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Appendix)';$f8='(\\s+)';  $f9='(Requirements)';


   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5."/is", $new, $matches  ))
  {

   
     $four++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7."/is", $new, $matches)) {
    
      $four++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7."/is", $new, $matches)) {
    
      $four++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7."/is", $new, $matches)) {
     
      $four++;
  }
  

   $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(References)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(References)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5."/is", $new, $matches  ))
  {

   
     $four++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7."/is", $new, $matches)) {
     
      $four++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7."/is", $new, $matches)) {
    
      $four++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7."/is", $new, $matches)) {
      $four++;
  }
   


   $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Glossary)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Glossary)';


   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5."/is", $new, $matches  ))
  {
$four++;
  
    

  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7."/is", $new, $matches)) {
    
     $four++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7."/is", $new, $matches)) {

      $four++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7."/is", $new, $matches)) {
    
      $four++;
  }
  


echo "<b><br><span style='margin-left:10px;'>Srs completness status: </span> </b>";
if (($first AND $second AND $three AND $four)>0) {
  echo "<br> <span style='margin-left:10px;'>SRS Complete</span>";
  echo "<br><span style='margin-left:10px;'>SRS contains All four sections</span>";
}
elseif (($first AND $second AND $three )>0) {
 echo "<br><span style='margin-left:10px;'>SRS Complete</span>";
  echo "<br><span style='margin-left:10px;'> SRS contains All four sections </span>"; 
}
elseif (($first AND $second )>0) {
  echo "<br><span style='margin-left:10px;'>SRS missing third and fourth section</span>"; 
}
elseif (($first AND $three)>0) {
  echo "<br><span style='margin-left:20px;'>SRS missing Second and fourth section</span>"; 
}
elseif (($first AND $four)>0) {
  echo "<br><span style='margin-left:10px;'>SRS missing Second and third section</span>";  
}
elseif (($second AND $three)>0) {
  echo "<br><span style='margin-left:10px;'>SRS missing first and fourth section</span>"; 
}
elseif (($second AND $four)>0) {
  echo "<br><span style='margin-left:10px;'>SRS missing first and third section</span>"; 
}
elseif (($three AND $four)>0) {
  echo "<br><span style='margin-left:10px;'>SRS missing first and second section</span>"; 
}
elseif (($first AND $second AND $four)>0) {
  echo "<br><span style='margin-left:10px;'>SRS missing third section</span>"; 
}
elseif (($second AND $three AND $four)>0) {
  echo "<br><span style='margin-left:10px;'>SRS missing first section</span>"; 
}
elseif (($first AND $three AND $four)>0) {
  echo "<br><span style='margin-left:10px;'>SRS missing Second section</span>"; 
}
elseif (($first )>0) {
  echo "<br><span style='margin-left:10px;'>SRS missing Second,third and fourth section</span>"; 
}
elseif (($second )>0) {
  echo "<br><span style='margin-left:10px;'>SRS missing First, third and fourth section</span>"; 
}
elseif (($three )>0) {
  echo "<br><span style='margin-left:10px;'>SRS missing First, Second and fourth section</span>"; 
} 
elseif (($four )>0) {
  echo "<br><span style='margin-left:10px;'>SRS missing First, Second and third section</span>"; 
} else{
   echo "<br><span style='margin-left:10px;'>SRS missing all four sections</span>";
}


echo "<br>";


if ((($f1 OR $f2 OR $f3 OR $f4) AND ( $nf1 OR $nf2 OR $nf3 OR $nf4 OR $nf5 OR $nf6 OR $nf7 OR $nf8 OR $nf9 OR $nf10 OR $nf11 OR $nf12) AND ($p1 OR $p2 OR $p3 OR $p4) AND ($q1 OR $q2 OR $q3 OR $q4)) >0) {
 echo "<b><br><span style='margin-left:10px;'>Srs contains:</span></b><br>";
 echo "<div style='margin-left:20px;'><li> Functional Requirements</li></div> ";
  echo "<div style='margin-left:20px;'><li> Non Functional Requirements </li></div> ";
   echo "<div style='margin-left:20px;'><li> Performance Requirements</li></div> ";
    echo "<div style='margin-left:20px;'><li> Quality Requirements </li></div> ";
}


elseif ((($f1 OR $f2 OR $f3 OR $f4) AND ( $nf1 OR $nf2 OR $nf3 OR $nf4 OR $nf5 OR $nf6 OR $nf7 OR $nf8 OR $nf9 OR $nf10 OR $nf11 OR $nf12) AND ($p1 OR $p2 OR $p3 OR $p4)) >0) {
 echo "<b><br><span style='margin-left:20px;'>Srs contains:</span></b><br>";
 echo "<div style='margin-left:20px;'><li> Functional Requirements</li></div> ";
  echo "<div style='margin-left:20px;'><li> Non Functional Requirements</li></div>";
   echo "<div style='margin-left:20px;'><li> Performance Requirements</li></div> ";
  
}
elseif ((($f1 OR $f2 OR $f3 OR $f4) AND ( $nf1 OR $nf2 OR $nf3 OR $nf4 OR $nf5 OR $nf6 OR $nf7 OR $nf8 OR $nf9 OR $nf10 OR $nf11 OR $nf12) AND ($p1 OR $p2 OR $p3 OR $p4)>0)) {
 echo "<b><br><span style='margin-left:20px;'>Srs contains:</span></b><br>";
 echo "<div style='margin-left:20px;'><li> Functional Requirements</li></div> ";
  echo "<div style='margin-left:20px;'><li> Non Functional Requirements</li></div> ";
   echo "<div style='margin-left:20px;'><li> Performance Requirements</li></div> ";
    
}
elseif ((($f1 OR $f2 OR $f3 OR $f4) AND ($q1 OR $q2 OR $q3 OR $q4)) >0) {
 echo "<b><br><span style='margin-left:20px;'>Srs contains:</span></b><br>";
 echo "<div style='margin-left:20px;'><li> Functional Requirements</li> </div>";
    echo "<div style='margin-left:20px;'><li> Quality Requirements</li></div> ";
}
elseif ((($f1 OR $f2 OR $f3 OR $f4) AND ($p1 OR $p2 OR $p3 OR $p4)>0)) {
 echo "<b><br><span style='margin-left:20px;'>Srs contains:</span></b><br>";
 echo "<div style='margin-left:20px;'><li> Functional Requirements</li></div> ";
 echo "<div style='margin-left:20px;'><li> Performance Requirements</li> </div>";
    
}
elseif ((($f1 OR $f2 OR $f3 OR $f4) AND ( $nf1 OR $nf2 OR $nf3 OR $nf4 OR $nf5 OR $nf6 OR $nf7 OR $nf8 OR $nf9 OR $nf10 OR $nf11 OR $nf12) >0)) {
 echo "<b><br><span style='margin-left:20px;'>Srs contains:</span></b><br>";
 echo "<div style='margin-left:20px;'><li> Functional Requirements</li></span> ";
  echo "<div style='margin-left:20px;'><li> Non Functional Requirements</li> </div>";
    
}
elseif ((($f1 OR $f2 OR $f3 OR $f4) >0)) {
  echo "<b><br><span style='margin-left:20px;'>Srs contains:</span></b><br>";
 echo "<div style='margin-left:20px;'><li> Functional Requirements</li></div> ";
    
}
elseif ((( $nf1 OR $nf2 OR $nf3 OR $nf4 OR $nf5 OR $nf6 OR $nf7 OR $nf8 OR $nf9 OR $nf10 OR $nf11 OR $nf12) >0)) {
  echo "<b><br><span style='margin-left:20px;'>Srs contains:</span></b><br>";

  echo "<div style='margin-left:20px;'><li> Non Functional Requirements</li></div> ";
    
}
elseif (( ($p1 OR $p2 OR $p3 OR $p4) AND ($q1 OR $q2 OR $q3 OR $q4)) >0) {
 echo "<b><br><span style='margin-left:20px;'>Srs contains:<span></b><br>";
   echo "<div style='margin-left:20px;'><li> Performance Requirements</li></div> ";
    echo "<div style='margin-left:20px;'><li> Quality Requirements</li></div>";
}

elseif ((  ($q1 OR $q2 OR $q3 OR $q4)) >0) {
 echo "<b><br><span style='margin-left:20px;'>Srs contains:</span></b><br>";

    echo "<div style='margin-left:20px;'><li> Quality Requirements</li></div> ";
}elseif (( ($p1 OR $p2 OR $p3 OR $p4)) >0) {
 echo "<b><br><span style='margin-left:20px;'>Srs contains:</span></b><br>";
   echo "<div style='margin-left:20px;'><li> Performance Requirements</li></div> ";
   
}

elseif ((( $nf1 OR $nf2 OR $nf3 OR $nf4 OR $nf5 OR $nf6 OR $nf7 OR $nf8 OR $nf9 OR $nf10 OR $nf11 OR $nf12) AND  ($q1 OR $q2 OR $q3 OR $q4)) >0) {
 echo "<b><br> <span style='margin-left:20px;'>Srs contains:</span></b><br>";
 
  echo "<div style='margin-left:20px;'><li> Non Functional Requirements</li></div> ";
 
    echo "<div style='margin-left:20px;'><li> Quality Requirements</li></div>";
}

elseif (( ( $nf1 OR $nf2 OR $nf3 OR $nf4 OR $nf5 OR $nf6 OR $nf7 OR $nf8 OR $nf9 OR $nf10 OR $nf11 OR $nf12) AND ($p1 OR $p2 OR $p3 OR $p4) ) >0) {
 echo "<b><br><span style='margin-left:20px;'>Srs contains:</span></b><br>";
 echo "<div style='margin-left:20px;'><li> Functional Requirements</li> </div>";
  echo "<div style='margin-left:20px;'><li> Non Functional Requirements</li></div>";
   echo "<div style='margin-left:20px;'><li> Performance Requirements</li> </div>";
 
}
elseif (( ( $nf1 OR $nf2 OR $nf3 OR $nf4 OR $nf5 OR $nf6 OR $nf7 OR $nf8 OR $nf9 OR $nf10 OR $nf11 OR $nf12)) >0) {
 echo "<b><br><span style='margin-left:20px;'>Srs contains:</span></b><br>";

  echo "<div style='margin-left:20px;'><li> Non Functional Requirements</li> </div>";
 
}
elseif ((($f1 OR $f2 OR $f3 OR $f4) AND ($p1 OR $p2 OR $p3 OR $p4) AND ($q1 OR $q2 OR $q3 OR $q4)) >0) {
 echo "<b><br><span style='margin-left:20px;'>Srs contains:</span></b><br>";
 echo "<div style='margin-left:20px;'><li> Functional Requirements</li></div> ";

   echo "<div style='margin-left:20px;'><li> Performance Requirements</li></div>";
    echo "<div style='margin-left:20px;'><li> Quality Requirements</li></div>";
}




        
}elseif (substr($query_file, -4)  == '.pdf') {


// Include Composer autoloader if not already done.
include 'vendor/autoload.php';
// Parse pdf file and build necessary objects.
$parser = new \Smalot\PdfParser\Parser();
$pdf = $parser->parseFile("files/$query_file");
// Retrieve all pages from the pdf file.
 
$text = $pdf->getText();


$string = "$text";

    $new= $string;
   
    
$pages  = $pdf->getPages();
 
// Loop over each page to extract text.

foreach ($pages as $page) {
    $z= $page->getText();
 // $string = "$z";
   // echo "$z";
  $text = trim($z); // remove the last \n or whitespace character
$text1 = nl2br($text);


}
 
 $new= $string;

 $f1=0; $f2=0; $f3=0; $f4=0;
 $nf1=0;$nf2=0;$nf3=0;$nf4=0;$nf5=0;$nf6=0;$nf7=0;$nf8=0;$nf9=0;$nf10=0;$nf11=0;$nf12=0;
 $p1=0; $p2=0; $p3=0; $p4=0;
 $q1=0;$q2=0;$q3=0;$q4=0;


 $re1='(\d)'; # Any Single Character 1
  $re2='(\\.)'; # Any Single Character 2
  $re3='(\\s+)';  # White Space 1
  $re4='(Introduction)';  # Word 1
  
  $ae2='(\\.)';  $ae3='(\d)';
  $ae6='(\\s+)';   $ae7='(Introduction)';  # Word 1
  $first=0;
  $be3='(\d)'; $be6='(\\s+)';  $be7='(Introduction)'; 

  if ($c=preg_match_all ("/".$re1.$re2.$re3.$re4."/is", $new, $matches  ))
  {
    $first++;
  } elseif ($ac=preg_match_all ("/".$ae3.$ae6.$ae7."/is", $new, $matches)) {
    
     $first++;
  }
  
// second chapter////////////////////////////////////////////
  
 $ce1='(\d)'; # Any Single Character 1
  $ce2='(\\.)';
  
  $ce4='(\\s+)';  # White Space 1
  $ce5='(Overall)';  # Word 1
  $ce6='(\\s+)';  # White Space 1
  $ce7='(Description)';
  $ce8='(\\s+)';  # White Space 1
  $ce9='(The)'; 
  
 $de2='(\\.)';   $de3='(\d)'; $de6='(\\s+)';  $de7='(Overall)';$de8='(\\s+)';  $de9='(Description)';

 $second=0;
     
   if ($c=preg_match_all ("/".$ce1.$ce2.$ce4.$ce5.$ce6.$ce7."/is", $new, $matches  ))
  {

    
    $second++;
  } elseif ($ac=preg_match_all ("/".$de3.$de6.$de7.$de8.$de9."/is", $new, $matches)) {
    
     $second++;
  }
  elseif ($ac=preg_match_all ("/".$de3.$de6.$ce9.$ce8.$de7.$de8.$de9."/is", $new, $matches)) {
    
     $second++;
  }
  elseif ($ac=preg_match_all ("/".$de3.$de2.$de6.$ce9.$ce8.$de7.$de8.$de9."/is", $new, $matches)) {
    
     $second++;
  }
  

   $e1='(\d)'; $e2='(\\.)';
   $e4='(\\s+)';   $e5='(General)';  # Word 1
  $e6='(\\s+)';  $e7='(Description)';  $e9='(The)'; 
  
 $d2='(\\.)';   $d3='(\d)'; $d6='(\\s+)';  $d7='(General)';$d8='(\\s+)';  $d9='(Description)';

 
   if ($c=preg_match_all ("/".$e1.$e2.$e4.$e5.$e6.$e7."/is", $new, $matches  ))
  {

    $second++;
  } elseif ($ac=preg_match_all ("/".$d3.$d6.$d7.$d8.$d9."/is", $new, $matches)) {
    
     $second++;
  }
elseif ($ac=preg_match_all ("/".$d3.$d6.$e9.$e4.$e5.$e6.$e7."/is", $new, $matches)) {
    
     $second++;
  }
  elseif ($ac=preg_match_all ("/".$d3.$d2.$d6.$e9.$e4.$e5.$e6.$e7."/is", $new, $matches)) {
    
     $second++;
  }



   $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(System)';  # Word 1
  $b6='(\\s+)';  $b7='(Description)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(System)';$f8='(\\s+)';  $f9='(Description)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $new, $matches  ))
  {

    $second++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $new, $matches)) {
     
     $second++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $new, $matches)) {
     
     $second++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $new, $matches)) {
    
     $second++;
  }
  
// third specific //////////////////////////////////////////////////

  
   $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Specific)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Specific)';$f8='(\\s+)';  $f9='(Requirements)';

 $three=0;
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $new, $matches  ))
  {

   
    $three++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $new, $matches)) {
     $three++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $new, $matches)) {
    
     $three++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $new, $matches)) {
   
     $three++;
  }
  

   $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Technical)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Technical)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $new, $matches  ))
  {

   
   $three++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $new, $matches)) {
     
     $three++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $new, $matches)) {
    
     $three++;
  }
elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $new, $matches)) {
     $three++;
  }

  

   $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Functional)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Functional)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $new, $matches  ))
  {

  
    $f1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $new, $matches)) {
    
     $f2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $new, $matches)) {
 
  $f3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $new, $matches)) {

  $f4++;
  }

  

   $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(System)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(System)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $new, $matches  ))
  {

    $three++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $new, $matches)) {
     $three++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $new, $matches)) {
     $three++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $new, $matches)) {
     $three++;
  }
  
//$txt='3.23.3 Non Functional Requirements';

   $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Non)';  # Word 1
  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$f7.$f8.$b7.$b10.$f9."/is", $new, $matches ))
  {

   
    $nf1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$b7.$b10.$f9."/is", $new, $matches)) {
    
    
     $nf2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $new, $matches)) {
   
     $nf3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $new, $matches)) {
    
     $nf4++;
  }
  
  
   
   $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Non)';  # Word 1 

  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

 $spe=0;
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$a.$b7.$b9.$b11."/is", $new, $matches  ))
  {

    
  
   $nf5++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$a.$b7.$b10.$f9."/is", $new, $matches)) {
    
     $nf6++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $new, $matches)) {
     
     $nf7++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $new, $matches)) {
     $nf8++;
    
  }
  

   $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Non)';  # Word 1 

  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b7.$b9.$b11."/is", $new, $matches  ))
  {

   
    $nf9++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$b7.$b10.$f9."/is", $new, $matches)) {
     $three++;
     $nf10++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $new, $matches)) {
   
    
     $nf11++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $new, $matches)) {
    
    
     $nf12++;
  }


   $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Non)';  # Word 1 

  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $new, $matches  ))
  {
    $three++;
    $p1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $new, $matches)) {
     $three++;
     $p2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $new, $matches)) {
   
     $three++;
     $p3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $new, $matches)) {
    
     $three++;
     $p4++;
  }
  

   $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Non)';  # Word 1 

  $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $new, $matches  ))
  {

    $spe++;
    $q1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $new, $matches)) {
     
     $three++;
     $q2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $new, $matches)) {
     
     $three++;
     $q3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $new, $matches)) {
     $three++;
     $q4++;
  }
 

   $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(System)';  # Word 1
  $b6='(\\s+)';  $b7='(Features)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(System)';$f8='(\\s+)';  $f9='(Features)';

 $spe=0;
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $new, $matches  ))
  {

    $three++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $new, $matches)) {
     $three++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $new, $matches)) {
     $three++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $new, $matches)) {
     $three++;
  }
   $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Requirements)';  # Word 1
  $b6='(\\s+)';  $b7='(Specification)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Requirements)';$f8='(\\s+)';  $f9='(Specification)';


   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $new, $matches  ))
  {
    $three++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $new, $matches)) {
    
    $three++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $new, $matches)) {
     $three++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $new, $matches)) {
     $three++;
  }
  

// Fourth Chapter////////////////////////////////////


   $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Supporting)';  # Word 1
  $b6='(\\s+)';  $b7='(Information)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Supporting)';$f8='(\\s+)';  $f9='(Information)';

 $four=0;
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $new, $matches  ))
  {
    $spe++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $new, $matches)) {

     $four++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $new, $matches)) {
      $four++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $new, $matches)) {
    
      $four++;
  }



   $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Other)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Other)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $new, $matches  ))
  {

     $four++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $new, $matches)) {
     
      $four++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $new, $matches)) {
   
      $four++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $new, $matches)) {
     
      $four++;
  }
  
   $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Appendix)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Appendix)';$f8='(\\s+)';  $f9='(Requirements)';


   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5."/is", $new, $matches  ))
  {

   
     $four++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7."/is", $new, $matches)) {
    
      $four++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7."/is", $new, $matches)) {
    
      $four++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7."/is", $new, $matches)) {
     
      $four++;
  }
  

   $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(References)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(References)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5."/is", $new, $matches  ))
  {

   
     $four++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7."/is", $new, $matches)) {
     
      $four++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7."/is", $new, $matches)) {
    
      $four++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7."/is", $new, $matches)) {
      $four++;
  }
   


   $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Glossary)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Glossary)';


   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5."/is", $new, $matches  ))
  {
$four++;
  
    

  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7."/is", $new, $matches)) {
    
     $four++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7."/is", $new, $matches)) {

      $four++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7."/is", $new, $matches)) {
    
      $four++;
  }
  



echo "<b><br><span style='margin-left:10px;'>Srs completness status: </span> </b>";
if (($first AND $second AND $three AND $four)>0) {
  echo "<br> <span style='margin-left:10px;'>SRS Complete</span>";
  echo "<br><span style='margin-left:10px;'>SRS contains All four sections</span>";
}
elseif (($first AND $second AND $three )>0) {
 echo "<br><span style='margin-left:10px;'>SRS Complete</span>";
  echo "<br><span style='margin-left:10px;'> SRS contains All four sections </span>"; 
}
elseif (($first AND $second )>0) {
  echo "<br><span style='margin-left:10px;'>SRS missing third and fourth section</span>"; 
}
elseif (($first AND $three)>0) {
  echo "<br><span style='margin-left:20px;'>SRS missing Second and fourth section</span>"; 
}
elseif (($first AND $four)>0) {
  echo "<br><span style='margin-left:10px;'>SRS missing Second and third section</span>";  
}
elseif (($second AND $three)>0) {
  echo "<br><span style='margin-left:10px;'>SRS missing first and fourth section</span>"; 
}
elseif (($second AND $four)>0) {
  echo "<br><span style='margin-left:10px;'>SRS missing first and third section</span>"; 
}
elseif (($three AND $four)>0) {
  echo "<br><span style='margin-left:10px;'>SRS missing first and second section</span>"; 
}
elseif (($first AND $second AND $four)>0) {
  echo "<br><span style='margin-left:10px;'>SRS missing third section</span>"; 
}
elseif (($second AND $three AND $four)>0) {
  echo "<br><span style='margin-left:10px;'>SRS missing first section</span>"; 
}
elseif (($first AND $three AND $four)>0) {
  echo "<br><span style='margin-left:10px;'>SRS missing Second section</span>"; 
}
elseif (($first )>0) {
  echo "<br><span style='margin-left:10px;'>SRS missing Second,third and fourth section</span>"; 
}
elseif (($second )>0) {
  echo "<br><span style='margin-left:10px;'>SRS missing First, third and fourth section</span>"; 
}
elseif (($three )>0) {
  echo "<br><span style='margin-left:10px;'>SRS missing First, Second and fourth section</span>"; 
} 
elseif (($four )>0) {
  echo "<br><span style='margin-left:10px;'>SRS missing First, Second and third section</span>"; 
} else{
   echo "<br><span style='margin-left:10px;'>SRS missing all four sections</span>";
}


echo "<br>";

if ((($f1 OR $f2 OR $f3 OR $f4) AND ( $nf1 OR $nf2 OR $nf3 OR $nf4 OR $nf5 OR $nf6 OR $nf7 OR $nf8 OR $nf9 OR $nf10 OR $nf11 OR $nf12) AND ($p1 OR $p2 OR $p3 OR $p4) AND ($q1 OR $q2 OR $q3 OR $q4)) >0) {
 echo "<b><br><span style='margin-left:10px;'>Srs contains:</span></b><br>";
 echo "<div style='margin-left:20px;'><li> Functional Requirements</li></div> ";
  echo "<div style='margin-left:20px;'><li> Non Functional Requirements </li></div> ";
   echo "<div style='margin-left:20px;'><li> Performance Requirements</li></div> ";
    echo "<div style='margin-left:20px;'><li> Quality Requirements </li></div> ";
}


elseif ((($f1 OR $f2 OR $f3 OR $f4) AND ( $nf1 OR $nf2 OR $nf3 OR $nf4 OR $nf5 OR $nf6 OR $nf7 OR $nf8 OR $nf9 OR $nf10 OR $nf11 OR $nf12) AND ($p1 OR $p2 OR $p3 OR $p4)) >0) {
 echo "<b><br><span style='margin-left:20px;'>Srs contains:</span></b><br>";
 echo "<div style='margin-left:20px;'><li> Functional Requirements</li></div> ";
  echo "<div style='margin-left:20px;'><li> Non Functional Requirements</li></div>";
   echo "<div style='margin-left:20px;'><li> Performance Requirements</li></div> ";
  
}
elseif ((($f1 OR $f2 OR $f3 OR $f4) AND ( $nf1 OR $nf2 OR $nf3 OR $nf4 OR $nf5 OR $nf6 OR $nf7 OR $nf8 OR $nf9 OR $nf10 OR $nf11 OR $nf12) AND ($p1 OR $p2 OR $p3 OR $p4)>0)) {
 echo "<b><br><span style='margin-left:20px;'>Srs contains:</span></b><br>";
 echo "<div style='margin-left:20px;'><li> Functional Requirements</li></div> ";
  echo "<div style='margin-left:20px;'><li> Non Functional Requirements</li></div> ";
   echo "<div style='margin-left:20px;'><li> Performance Requirements</li></div> ";
    
}
elseif ((($f1 OR $f2 OR $f3 OR $f4) AND ($q1 OR $q2 OR $q3 OR $q4)) >0) {
 echo "<b><br><span style='margin-left:20px;'>Srs contains:</span></b><br>";
 echo "<div style='margin-left:20px;'><li> Functional Requirements</li> </div>";
    echo "<div style='margin-left:20px;'><li> Quality Requirements</li></div> ";
}
elseif ((($f1 OR $f2 OR $f3 OR $f4) AND ($p1 OR $p2 OR $p3 OR $p4)>0)) {
 echo "<b><br><span style='margin-left:20px;'>Srs contains:</span></b><br>";
 echo "<div style='margin-left:20px;'><li> Functional Requirements</li></div> ";
 echo "<div style='margin-left:20px;'><li> Performance Requirements</li> </div>";
    
}
elseif ((($f1 OR $f2 OR $f3 OR $f4) AND ( $nf1 OR $nf2 OR $nf3 OR $nf4 OR $nf5 OR $nf6 OR $nf7 OR $nf8 OR $nf9 OR $nf10 OR $nf11 OR $nf12) >0)) {
 echo "<b><br><span style='margin-left:20px;'>Srs contains:</span></b><br>";
 echo "<div style='margin-left:20px;'><li> Functional Requirements</li></span> ";
  echo "<div style='margin-left:20px;'><li> Non Functional Requirements</li> </div>";
    
}
elseif ((($f1 OR $f2 OR $f3 OR $f4) >0)) {
  echo "<b><br><span style='margin-left:20px;'>Srs contains:</span></b><br>";
 echo "<div style='margin-left:20px;'><li> Functional Requirements</li></div> ";
    
}
elseif ((( $nf1 OR $nf2 OR $nf3 OR $nf4 OR $nf5 OR $nf6 OR $nf7 OR $nf8 OR $nf9 OR $nf10 OR $nf11 OR $nf12) >0)) {
  echo "<b><br><span style='margin-left:20px;'>Srs contains:</span></b><br>";

  echo "<div style='margin-left:20px;'><li> Non Functional Requirements</li></div> ";
    
}
elseif (( ($p1 OR $p2 OR $p3 OR $p4) AND ($q1 OR $q2 OR $q3 OR $q4)) >0) {
 echo "<b><br><span style='margin-left:20px;'>Srs contains:<span></b><br>";
   echo "<div style='margin-left:20px;'><li> Performance Requirements</li></div> ";
    echo "<div style='margin-left:20px;'><li> Quality Requirements</li></div>";
}

elseif ((  ($q1 OR $q2 OR $q3 OR $q4)) >0) {
 echo "<b><br><span style='margin-left:20px;'>Srs contains:</span></b><br>";

    echo "<div style='margin-left:20px;'><li> Quality Requirements</li></div> ";
}elseif (( ($p1 OR $p2 OR $p3 OR $p4)) >0) {
 echo "<b><br><span style='margin-left:20px;'>Srs contains:</span></b><br>";
   echo "<div style='margin-left:20px;'><li> Performance Requirements</li></div> ";
   
}

elseif ((( $nf1 OR $nf2 OR $nf3 OR $nf4 OR $nf5 OR $nf6 OR $nf7 OR $nf8 OR $nf9 OR $nf10 OR $nf11 OR $nf12) AND  ($q1 OR $q2 OR $q3 OR $q4)) >0) {
 echo "<b><br> <span style='margin-left:20px;'>Srs contains:</span></b><br>";
 
  echo "<div style='margin-left:20px;'><li> Non Functional Requirements</li></div> ";
 
    echo "<div style='margin-left:20px;'><li> Quality Requirements</li></div>";
}

elseif (( ( $nf1 OR $nf2 OR $nf3 OR $nf4 OR $nf5 OR $nf6 OR $nf7 OR $nf8 OR $nf9 OR $nf10 OR $nf11 OR $nf12) AND ($p1 OR $p2 OR $p3 OR $p4) ) >0) {
 echo "<b><br><span style='margin-left:20px;'>Srs contains:</span></b><br>";
 echo "<div style='margin-left:20px;'><li> Functional Requirements</li> </div>";
  echo "<div style='margin-left:20px;'><li> Non Functional Requirements</li></div>";
   echo "<div style='margin-left:20px;'><li> Performance Requirements</li> </div>";
 
}
elseif (( ( $nf1 OR $nf2 OR $nf3 OR $nf4 OR $nf5 OR $nf6 OR $nf7 OR $nf8 OR $nf9 OR $nf10 OR $nf11 OR $nf12)) >0) {
 echo "<b><br><span style='margin-left:20px;'>Srs contains:</span></b><br>";

  echo "<div style='margin-left:20px;'><li> Non Functional Requirements</li> </div>";
 
}
elseif ((($f1 OR $f2 OR $f3 OR $f4) AND ($p1 OR $p2 OR $p3 OR $p4) AND ($q1 OR $q2 OR $q3 OR $q4)) >0) {
 echo "<b><br><span style='margin-left:20px;'>Srs contains:</span></b><br>";
 echo "<div style='margin-left:20px;'><li> Functional Requirements</li></div> ";

   echo "<div style='margin-left:20px;'><li> Performance Requirements</li></div>";
    echo "<div style='margin-left:20px;'><li> Quality Requirements</li></div>";
}




//echo $a;
}

elseif (substr($query_file, -4)  == '.txt') {
  
$my=fopen("files/$query_file", "r") or die(" Can't Open file");
$myfile=fread($my, filesize("files/$query_file"));

fclose($my);
$new= $myfile;
$text = trim($new); // remove the last \n or whitespace character
$text1 = nl2br($text);
$string = "$text1";

$new= $string;

 $f1=0; $f2=0; $f3=0; $f4=0;
 $nf1=0;$nf2=0;$nf3=0;$nf4=0;$nf5=0;$nf6=0;$nf7=0;$nf8=0;$nf9=0;$nf10=0;$nf11=0;$nf12=0;
 $p1=0; $p2=0; $p3=0; $p4=0;
 $q1=0;$q2=0;$q3=0;$q4=0;


 $re1='(\d)'; # Any Single Character 1
  $re2='(\\.)'; # Any Single Character 2
  $re3='(\\s+)';  # White Space 1
  $re4='(Introduction)';  # Word 1
  
  $ae2='(\\.)';  $ae3='(\d)';
  $ae6='(\\s+)';   $ae7='(Introduction)';  # Word 1
  $first=0;
  $be3='(\d)'; $be6='(\\s+)';  $be7='(Introduction)'; 

  if ($c=preg_match_all ("/".$re1.$re2.$re3.$re4."/is", $new, $matches  ))
  {
    $first++;
  } elseif ($ac=preg_match_all ("/".$ae3.$ae6.$ae7."/is", $new, $matches)) {
    
     $first++;
  }
  
// second chapter////////////////////////////////////////////
  
 $ce1='(\d)'; # Any Single Character 1
  $ce2='(\\.)';
  
  $ce4='(\\s+)';  # White Space 1
  $ce5='(Overall)';  # Word 1
  $ce6='(\\s+)';  # White Space 1
  $ce7='(Description)';
  $ce8='(\\s+)';  # White Space 1
  $ce9='(The)'; 
  
 $de2='(\\.)';   $de3='(\d)'; $de6='(\\s+)';  $de7='(Overall)';$de8='(\\s+)';  $de9='(Description)';

 $second=0;
     
   if ($c=preg_match_all ("/".$ce1.$ce2.$ce4.$ce5.$ce6.$ce7."/is", $new, $matches  ))
  {

    
    $second++;
  } elseif ($ac=preg_match_all ("/".$de3.$de6.$de7.$de8.$de9."/is", $new, $matches)) {
    
     $second++;
  }
  elseif ($ac=preg_match_all ("/".$de3.$de6.$ce9.$ce8.$de7.$de8.$de9."/is", $new, $matches)) {
    
     $second++;
  }
  elseif ($ac=preg_match_all ("/".$de3.$de2.$de6.$ce9.$ce8.$de7.$de8.$de9."/is", $new, $matches)) {
    
     $second++;
  }
  

   $e1='(\d)'; $e2='(\\.)';
   $e4='(\\s+)';   $e5='(General)';  # Word 1
  $e6='(\\s+)';  $e7='(Description)';  $e9='(The)'; 
  
 $d2='(\\.)';   $d3='(\d)'; $d6='(\\s+)';  $d7='(General)';$d8='(\\s+)';  $d9='(Description)';

 
   if ($c=preg_match_all ("/".$e1.$e2.$e4.$e5.$e6.$e7."/is", $new, $matches  ))
  {

    $second++;
  } elseif ($ac=preg_match_all ("/".$d3.$d6.$d7.$d8.$d9."/is", $new, $matches)) {
    
     $second++;
  }
elseif ($ac=preg_match_all ("/".$d3.$d6.$e9.$e4.$e5.$e6.$e7."/is", $new, $matches)) {
    
     $second++;
  }
  elseif ($ac=preg_match_all ("/".$d3.$d2.$d6.$e9.$e4.$e5.$e6.$e7."/is", $new, $matches)) {
    
     $second++;
  }



   $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(System)';  # Word 1
  $b6='(\\s+)';  $b7='(Description)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(System)';$f8='(\\s+)';  $f9='(Description)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $new, $matches  ))
  {

    $second++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $new, $matches)) {
     
     $second++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $new, $matches)) {
     
     $second++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $new, $matches)) {
    
     $second++;
  }
  
// third specific //////////////////////////////////////////////////

  
   $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Specific)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Specific)';$f8='(\\s+)';  $f9='(Requirements)';

 $three=0;
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $new, $matches  ))
  {

   
    $three++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $new, $matches)) {
     $three++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $new, $matches)) {
    
     $three++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $new, $matches)) {
   
     $three++;
  }
  

   $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Technical)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Technical)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $new, $matches  ))
  {

   
   $three++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $new, $matches)) {
     
     $three++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $new, $matches)) {
    
     $three++;
  }
elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $new, $matches)) {
     $three++;
  }

  

   $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Functional)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Functional)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $new, $matches  ))
  {

  
    $f1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $new, $matches)) {
    
     $f2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $new, $matches)) {
 
  $f3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $new, $matches)) {

  $f4++;
  }

  

   $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(System)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(System)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $new, $matches  ))
  {

    $three++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $new, $matches)) {
     $three++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $new, $matches)) {
     $three++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $new, $matches)) {
     $three++;
  }
  
//$txt='3.23.3 Non Functional Requirements';

   $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Non)';  # Word 1
  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$f7.$f8.$b7.$b10.$f9."/is", $new, $matches ))
  {

   
    $nf1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$b7.$b10.$f9."/is", $new, $matches)) {
    
    
     $nf2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $new, $matches)) {
   
     $nf3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $new, $matches)) {
    
     $nf4++;
  }
  
  
   
   $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Non)';  # Word 1 

  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

 $spe=0;
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$a.$b7.$b9.$b11."/is", $new, $matches  ))
  {

    
  
   $nf5++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$a.$b7.$b10.$f9."/is", $new, $matches)) {
    
     $nf6++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $new, $matches)) {
     
     $nf7++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $new, $matches)) {
     $nf8++;
    
  }
  

   $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Non)';  # Word 1 

  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b7.$b9.$b11."/is", $new, $matches  ))
  {

   
    $nf9++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$b7.$b10.$f9."/is", $new, $matches)) {
     $three++;
     $nf10++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $new, $matches)) {
   
    
     $nf11++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $new, $matches)) {
    
    
     $nf12++;
  }


   $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Non)';  # Word 1 

  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $new, $matches  ))
  {
    $three++;
    $p1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $new, $matches)) {
     $three++;
     $p2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $new, $matches)) {
   
     $three++;
     $p3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $new, $matches)) {
    
     $three++;
     $p4++;
  }
  

   $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Non)';  # Word 1 

  $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $new, $matches  ))
  {

    $spe++;
    $q1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $new, $matches)) {
     
     $three++;
     $q2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $new, $matches)) {
     
     $three++;
     $q3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $new, $matches)) {
     $three++;
     $q4++;
  }
 

   $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(System)';  # Word 1
  $b6='(\\s+)';  $b7='(Features)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(System)';$f8='(\\s+)';  $f9='(Features)';

 $spe=0;
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $new, $matches  ))
  {

    $three++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $new, $matches)) {
     $three++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $new, $matches)) {
     $three++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $new, $matches)) {
     $three++;
  }
   $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Requirements)';  # Word 1
  $b6='(\\s+)';  $b7='(Specification)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Requirements)';$f8='(\\s+)';  $f9='(Specification)';


   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $new, $matches  ))
  {
    $three++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $new, $matches)) {
    
    $three++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $new, $matches)) {
     $three++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $new, $matches)) {
     $three++;
  }
  

// Fourth Chapter////////////////////////////////////


   $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Supporting)';  # Word 1
  $b6='(\\s+)';  $b7='(Information)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Supporting)';$f8='(\\s+)';  $f9='(Information)';

 $four=0;
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $new, $matches  ))
  {
    $spe++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $new, $matches)) {

     $four++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $new, $matches)) {
      $four++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $new, $matches)) {
    
      $four++;
  }



   $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Other)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Other)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $new, $matches  ))
  {

     $four++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $new, $matches)) {
     
      $four++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $new, $matches)) {
   
      $four++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $new, $matches)) {
     
      $four++;
  }
  
   $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Appendix)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Appendix)';$f8='(\\s+)';  $f9='(Requirements)';


   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5."/is", $new, $matches  ))
  {

   
     $four++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7."/is", $new, $matches)) {
    
      $four++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7."/is", $new, $matches)) {
    
      $four++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7."/is", $new, $matches)) {
     
      $four++;
  }
  

   $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(References)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(References)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5."/is", $new, $matches  ))
  {

   
     $four++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7."/is", $new, $matches)) {
     
      $four++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7."/is", $new, $matches)) {
    
      $four++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7."/is", $new, $matches)) {
      $four++;
  }
   


   $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Glossary)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Glossary)';


   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5."/is", $new, $matches  ))
  {
$four++;
  
    

  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7."/is", $new, $matches)) {
    
     $four++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7."/is", $new, $matches)) {

      $four++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7."/is", $new, $matches)) {
    
      $four++;
  }
  


echo "<b><br><span style='margin-left:10px;'>Srs completness status: </span> </b>";
if (($first AND $second AND $three AND $four)>0) {
  echo "<br> <span style='margin-left:10px;'>SRS Complete</span>";
  echo "<br><span style='margin-left:10px;'>SRS contains All four sections</span>";
}
elseif (($first AND $second AND $three )>0) {
 echo "<br><span style='margin-left:10px;'>SRS Complete</span>";
  echo "<br><span style='margin-left:10px;'> SRS contains All four sections </span>"; 
}
elseif (($first AND $second )>0) {
  echo "<br><span style='margin-left:10px;'>SRS missing third and fourth section</span>"; 
}
elseif (($first AND $three)>0) {
  echo "<br><span style='margin-left:20px;'>SRS missing Second and fourth section</span>"; 
}
elseif (($first AND $four)>0) {
  echo "<br><span style='margin-left:10px;'>SRS missing Second and third section</span>";  
}
elseif (($second AND $three)>0) {
  echo "<br><span style='margin-left:10px;'>SRS missing first and fourth section</span>"; 
}
elseif (($second AND $four)>0) {
  echo "<br><span style='margin-left:10px;'>SRS missing first and third section</span>"; 
}
elseif (($three AND $four)>0) {
  echo "<br><span style='margin-left:10px;'>SRS missing first and second section</span>"; 
}
elseif (($first AND $second AND $four)>0) {
  echo "<br><span style='margin-left:10px;'>SRS missing third section</span>"; 
}
elseif (($second AND $three AND $four)>0) {
  echo "<br><span style='margin-left:10px;'>SRS missing first section</span>"; 
}
elseif (($first AND $three AND $four)>0) {
  echo "<br><span style='margin-left:10px;'>SRS missing Second section</span>"; 
}
elseif (($first )>0) {
  echo "<br><span style='margin-left:10px;'>SRS missing Second,third and fourth section</span>"; 
}
elseif (($second )>0) {
  echo "<br><span style='margin-left:10px;'>SRS missing First, third and fourth section</span>"; 
}
elseif (($three )>0) {
  echo "<br><span style='margin-left:10px;'>SRS missing First, Second and fourth section</span>"; 
} 
elseif (($four )>0) {
  echo "<br><span style='margin-left:10px;'>SRS missing First, Second and third section</span>"; 
} else{
   echo "<br><span style='margin-left:10px;'>SRS missing all four sections</span>";
}


echo "<br>";

if ((($f1 OR $f2 OR $f3 OR $f4) AND ( $nf1 OR $nf2 OR $nf3 OR $nf4 OR $nf5 OR $nf6 OR $nf7 OR $nf8 OR $nf9 OR $nf10 OR $nf11 OR $nf12) AND ($p1 OR $p2 OR $p3 OR $p4) AND ($q1 OR $q2 OR $q3 OR $q4)) >0) {
 echo "<b><br><span style='margin-left:10px;'>Srs contains:</span></b><br>";
 echo "<div style='margin-left:20px;'><li> Functional Requirements</li></div> ";
  echo "<div style='margin-left:20px;'><li> Non Functional Requirements </li></div> ";
   echo "<div style='margin-left:20px;'><li> Performance Requirements</li></div> ";
    echo "<div style='margin-left:20px;'><li> Quality Requirements </li></div> ";
}


elseif ((($f1 OR $f2 OR $f3 OR $f4) AND ( $nf1 OR $nf2 OR $nf3 OR $nf4 OR $nf5 OR $nf6 OR $nf7 OR $nf8 OR $nf9 OR $nf10 OR $nf11 OR $nf12) AND ($p1 OR $p2 OR $p3 OR $p4)) >0) {
 echo "<b><br><span style='margin-left:20px;'>Srs contains:</span></b><br>";
 echo "<div style='margin-left:20px;'><li> Functional Requirements</li></div> ";
  echo "<div style='margin-left:20px;'><li> Non Functional Requirements</li></div>";
   echo "<div style='margin-left:20px;'><li> Performance Requirements</li></div> ";
  
}
elseif ((($f1 OR $f2 OR $f3 OR $f4) AND ( $nf1 OR $nf2 OR $nf3 OR $nf4 OR $nf5 OR $nf6 OR $nf7 OR $nf8 OR $nf9 OR $nf10 OR $nf11 OR $nf12) AND ($p1 OR $p2 OR $p3 OR $p4)>0)) {
 echo "<b><br><span style='margin-left:20px;'>Srs contains:</span></b><br>";
 echo "<div style='margin-left:20px;'><li> Functional Requirements</li></div> ";
  echo "<div style='margin-left:20px;'><li> Non Functional Requirements</li></div> ";
   echo "<div style='margin-left:20px;'><li> Performance Requirements</li></div> ";
    
}
elseif ((($f1 OR $f2 OR $f3 OR $f4) AND ($q1 OR $q2 OR $q3 OR $q4)) >0) {
 echo "<b><br><span style='margin-left:20px;'>Srs contains:</span></b><br>";
 echo "<div style='margin-left:20px;'><li> Functional Requirements</li> </div>";
    echo "<div style='margin-left:20px;'><li> Quality Requirements</li></div> ";
}
elseif ((($f1 OR $f2 OR $f3 OR $f4) AND ($p1 OR $p2 OR $p3 OR $p4)>0)) {
 echo "<b><br><span style='margin-left:20px;'>Srs contains:</span></b><br>";
 echo "<div style='margin-left:20px;'><li> Functional Requirements</li></div> ";
 echo "<div style='margin-left:20px;'><li> Performance Requirements</li> </div>";
    
}
elseif ((($f1 OR $f2 OR $f3 OR $f4) AND ( $nf1 OR $nf2 OR $nf3 OR $nf4 OR $nf5 OR $nf6 OR $nf7 OR $nf8 OR $nf9 OR $nf10 OR $nf11 OR $nf12) >0)) {
 echo "<b><br><span style='margin-left:20px;'>Srs contains:</span></b><br>";
 echo "<div style='margin-left:20px;'><li> Functional Requirements</li></span> ";
  echo "<div style='margin-left:20px;'><li> Non Functional Requirements</li> </div>";
    
}
elseif ((($f1 OR $f2 OR $f3 OR $f4) >0)) {
  echo "<b><br><span style='margin-left:20px;'>Srs contains:</span></b><br>";
 echo "<div style='margin-left:20px;'><li> Functional Requirements</li></div> ";
    
}
elseif ((( $nf1 OR $nf2 OR $nf3 OR $nf4 OR $nf5 OR $nf6 OR $nf7 OR $nf8 OR $nf9 OR $nf10 OR $nf11 OR $nf12) >0)) {
  echo "<b><br><span style='margin-left:20px;'>Srs contains:</span></b><br>";

  echo "<div style='margin-left:20px;'><li> Non Functional Requirements</li></div> ";
    
}
elseif (( ($p1 OR $p2 OR $p3 OR $p4) AND ($q1 OR $q2 OR $q3 OR $q4)) >0) {
 echo "<b><br><span style='margin-left:20px;'>Srs contains:<span></b><br>";
   echo "<div style='margin-left:20px;'><li> Performance Requirements</li></div> ";
    echo "<div style='margin-left:20px;'><li> Quality Requirements</li></div>";
}

elseif ((  ($q1 OR $q2 OR $q3 OR $q4)) >0) {
 echo "<b><br><span style='margin-left:20px;'>Srs contains:</span></b><br>";

    echo "<div style='margin-left:20px;'><li> Quality Requirements</li></div> ";
}elseif (( ($p1 OR $p2 OR $p3 OR $p4)) >0) {
 echo "<b><br><span style='margin-left:20px;'>Srs contains:</span></b><br>";
   echo "<div style='margin-left:20px;'><li> Performance Requirements</li></div> ";
   
}

elseif ((( $nf1 OR $nf2 OR $nf3 OR $nf4 OR $nf5 OR $nf6 OR $nf7 OR $nf8 OR $nf9 OR $nf10 OR $nf11 OR $nf12) AND  ($q1 OR $q2 OR $q3 OR $q4)) >0) {
 echo "<b><br> <span style='margin-left:20px;'>Srs contains:</span></b><br>";
 
  echo "<div style='margin-left:20px;'><li> Non Functional Requirements</li></div> ";
 
    echo "<div style='margin-left:20px;'><li> Quality Requirements</li></div>";
}

elseif (( ( $nf1 OR $nf2 OR $nf3 OR $nf4 OR $nf5 OR $nf6 OR $nf7 OR $nf8 OR $nf9 OR $nf10 OR $nf11 OR $nf12) AND ($p1 OR $p2 OR $p3 OR $p4) ) >0) {
 echo "<b><br><span style='margin-left:20px;'>Srs contains:</span></b><br>";
 echo "<div style='margin-left:20px;'><li> Functional Requirements</li> </div>";
  echo "<div style='margin-left:20px;'><li> Non Functional Requirements</li></div>";
   echo "<div style='margin-left:20px;'><li> Performance Requirements</li> </div>";
 
}
elseif (( ( $nf1 OR $nf2 OR $nf3 OR $nf4 OR $nf5 OR $nf6 OR $nf7 OR $nf8 OR $nf9 OR $nf10 OR $nf11 OR $nf12)) >0) {
 echo "<b><br><span style='margin-left:20px;'>Srs contains:</span></b><br>";

  echo "<div style='margin-left:20px;'><li> Non Functional Requirements</li> </div>";
 
}
elseif ((($f1 OR $f2 OR $f3 OR $f4) AND ($p1 OR $p2 OR $p3 OR $p4) AND ($q1 OR $q2 OR $q3 OR $q4)) >0) {
 echo "<b><br><span style='margin-left:20px;'>Srs contains:</span></b><br>";
 echo "<div style='margin-left:20px;'><li> Functional Requirements</li></div> ";

   echo "<div style='margin-left:20px;'><li> Performance Requirements</li></div>";
    echo "<div style='margin-left:20px;'><li> Quality Requirements</li></div>";
}



}

   else
          {
            echo "<script>alert('Question not successfully added')</script>";
          } 

    } 

  }
}


if(isset($_POST['Quality'])){


 $b1='(\d)'; $b2='(\\.)';

   $b4='(\\s+)';   $b5='(Functional)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Functional)';$f8='(\\s+)';  $f9='(Requirements)';

$a1=0; $a2=0;




$f1=0; $f2=0; $f3=0;$f4=0;
$nf1=0;$nf2=0;$nf3=0;
$nf4=0;$nf5=0;$nf6=0;
$nf7=0;$nf8=0;$nf9=0;$nf10=0;$nf11=0;$nf12=0;
$p1=0; $p2=0;$p3=0; $p4=0;
$q1=0; $q2=0; $q3=0;$q4=0;


$fu1=0;
$fu2=0;$fu3=0;$fu4=0;
$a1=0;$a2=0;$a3=0;$a4=0;$a5=0;$a6=0;$a7=0;$a8=0;$a9=0;$a10=0;$a11=0;$a12=0;$a13=0;$a14=0;$a15=0;$a16=0;
 $result = mysqli_query($connection,"SELECT MAX(id) AS id FROM file ");
$row = mysqli_fetch_array($result);
$ab= $row["id"];

$res=mysqli_query($connection,"SELECT * FROM file where id='$ab' and name='$name'");
 $rowcount=mysqli_num_rows($res);

  if ($rowcount > 0) {
    
   while ($userRow=mysqli_fetch_array($res)) {
  $name=$userRow['file'];

if (substr($name, -4)  == '.txt') { 

$my=fopen("files/$name", "r") or die(" Can't Open file");
$myfile=fread($my, filesize("files/$name"));
fclose($my);
$new= $myfile;
$text1 = trim($new); // remove the last \n or whitespace character

function striplines($s,$n){
    $arr = explode("\n", $s);
    for ($i=0;$i<$n;$i++) array_shift($arr);
    return implode("\n", $arr);
}

$zn= striplines($text1,120);

$zan = join("\n", array_slice(explode("\n", $zn), 0, -100));




$b1='(\d)'; $b2='(\\.)'; $a='(-)';
   $b4='(\\s+)';   $b5='(Specific)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Specific)';$f8='(\\s+)';  $f9='(Requirements)';

 if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $zan, $matches  ))
  {
  
      $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
      $c3=$matches[6][0];
     // print "<br><br>$d1 $c1 $d2 $c2 $d3 $c3  actual ye ha heading\n";


if (strstr($zan, "$d1$c1$d2$c2$d3$c3"))
{
$ab= strstr($zan, "$d1$c1$d2$c2$d3$c3");

$az=newAll($ab);
echo "$az";

  

 $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Functional)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Functional)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $ab, $matches  ))
  {

  
    $fu1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $ab, $matches)) {
    
     $fu2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {
 
  $fu3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $new, $matches)) {

  $fu4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7.$b10.$f9."/is", $ab, $matches ))
  {
   $nf1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; 
 $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
   $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';


   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$a.$b7.$b9.$b11."/is", $ab, $matches ))
  {
   $nf5++;

  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf6++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf7++;
  
  }elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf8++;
  }
 
    
   $b1='(\d)'; $b2='(\\.)';$b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
    $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';
   
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
$nf9++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf10++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf11++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf12++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
    $p1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p4++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
   $q1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
    $q2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q4++;
  }



}


}

 elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $zan, $matches)) {

  $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];


if ($ab=strstr($zan, "$d1$c1$d2$c2$d3")){
$ab=strstr($zan, "$d1$c1$d2$c2$d3");

 
$az=newAll($ab);
echo "$az";




 $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Functional)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Functional)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $ab, $matches  ))
  {

  
    $fu1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $ab, $matches)) {
    
     $fu2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {
 
  $fu3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {

  $fu4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7.$b10.$f9."/is", $ab, $matches ))
  {
   $nf1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; 
 $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
   $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';


   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$a.$b7.$b9.$b11."/is", $ab, $matches ))
  {
   $nf5++;

  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf6++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf7++;
  
  }elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf8++;
  }
 

   $b1='(\d)'; $b2='(\\.)';$b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
    $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';
   
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
$nf9++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf10++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf11++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf12++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
    $p1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p4++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
   $q1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
    $q2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q4++;
  }

}
}
 elseif ($c=preg_match_all ("/".$b1.$b2.$b4.$b8.$b6.$b5.$b6.$b7."/is", $zan, $matches  ))
  {
  
      $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
      $c3=$matches[6][0];
       $d4=$matches[7][0];
      $c4=$matches[8][0];
     // print "<br><br>$d1 $c1 $d2 $c2 $d3 $c3  actual ye ha heading\n";


if (strstr($zan, "$d1$c1$d2$c2$d3$c3$d4$c4"))
{
$ab= strstr($zan, "$d1$c1$d2$c2$d3$c3$d4$c4");

$az=newAll($ab);
echo "$az";





 $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Functional)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Functional)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $ab, $matches  ))
  {

  
    $fu1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $ab, $matches)) {
    
     $fu2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {
 
  $fu3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {

  $fu4++;
  }


 $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7.$b10.$f9."/is", $ab, $matches ))
  {
   $nf1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; 
 $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
   $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';


   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$a.$b7.$b9.$b11."/is", $ab, $matches ))
  {
   $nf5++;

  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf6++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf7++;
  
  }elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf8++;
  }
 

   $b1='(\d)'; $b2='(\\.)';$b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
    $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';
   
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
$nf9++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf10++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf11++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf12++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
    $p1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p4++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
   $q1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
    $q2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q4++;
  }


}
}
 elseif ($c=preg_match_all ("/".$b1.$b4.$b8.$b6.$b5.$b6.$b7."/is", $zan, $matches  )) {


  $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
       $c3=$matches[6][0];     
      $d4=$matches[7][0];


if ($ab=strstr($zan, "$d1$c1$d2$c2$d3$c3$d4")){
$ab=strstr($zan, "$d1$c1$d2$c2$d3$c3$d4");
$az=newAll($ab);
echo "$az";




 $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Functional)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Functional)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $ab, $matches  ))
  {

  
    $fu1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $ab, $matches)) {
    
     $fu2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {
 
  $fu3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {

  $fu4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7.$b10.$f9."/is", $ab, $matches ))
  {
   $nf1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; 
 $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
   $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';


   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$a.$b7.$b9.$b11."/is", $ab, $matches ))
  {
   $nf5++;

  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf6++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf7++;
  
  }elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf8++;
  }
 

   $b1='(\d)'; $b2='(\\.)';$b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
    $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';
   
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
$nf9++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf10++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf11++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf12++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
    $p1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p4++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
   $q1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
    $q2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q4++;
  }

}

}



/////////////////////////////// First typeeeeeeeeeee endddddddddddddddddddddddd////////////////////////////////


   $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Technical)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Technical)';$f8='(\\s+)';  $f9='(Requirements)';

  if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $zan, $matches  ))
  {
 $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
 $c3=$matches[6][0];



if ($ab=strstr($zan, "$d1$c1$d2$c2$d3$c3")){
$ab=strstr($zan, "$d1$c1$d2$c2$d3$c3");




$az=newAll($ab);
echo "$az";



 $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Functional)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Functional)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $ab, $matches  ))
  {

  
    $fu1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $ab, $matches)) {
    
     $fu2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {
 
  $fu3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {

  $fu4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7.$b10.$f9."/is", $ab, $matches ))
  {
   $nf1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; 
 $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
   $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';


   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$a.$b7.$b9.$b11."/is", $ab, $matches ))
  {
   $nf5++;

  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf6++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf7++;
  
  }elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf8++;
  }
 

   $b1='(\d)'; $b2='(\\.)';$b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
    $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';
   
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
$nf9++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf10++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf11++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf12++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
    $p1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p4++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
   $q1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
    $q2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q4++;
  }

}

}


 elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $zan, $matches)) {

$d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];



if ($ab=strstr($zan, "$d1$c1$d2$c2$d3")){
$ab=strstr($zan, "$d1$c1$d2$c2$d3");


$az=newAll($ab);
echo "$az";




 $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Functional)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Functional)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $ab, $matches  ))
  {

  
    $fu1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $ab, $matches)) {
    
     $fu2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {
 
  $fu3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {

  $fu4++;
  }

    $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7.$b10.$f9."/is", $ab, $matches ))
  {
   $nf1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; 
 $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
   $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';


   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$a.$b7.$b9.$b11."/is", $ab, $matches ))
  {
   $nf5++;

  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf6++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf7++;
  
  }elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf8++;
  }
 

   $b1='(\d)'; $b2='(\\.)';$b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
    $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';
   
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
$nf9++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf10++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf11++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf12++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
    $p1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p4++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
   $q1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
    $q2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q4++;
  }

}
}
   elseif ($c=preg_match_all ("/".$b1.$b2.$b4.$b8.$b9.$b5.$b6.$b7."/is", $zan, $matches  ))
  {
 $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
 $c3=$matches[6][0];
$d4=$matches[7][0];
 $c4=$matches[8][0];



if ($ab=strstr($zan, "$d1$c1$d2$c2$d3$c3$d4$c4")){
$ab=strstr($zan, "$d1$c1$d2$c2$d3$c3$d4$c4");

$az=newAll($ab);
echo "$az";



 $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Functional)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Functional)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $ab, $matches  ))
  {

  
    $fu1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $ab, $matches)) {
    
     $fu2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {
 
  $fu3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {

  $fu4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7.$b10.$f9."/is", $ab, $matches ))
  {
   $nf1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; 
 $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
   $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';


   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$a.$b7.$b9.$b11."/is", $ab, $matches ))
  {
   $nf5++;

  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf6++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf7++;
  
  }elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf8++;
  }
 

   $b1='(\d)'; $b2='(\\.)';$b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
    $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';
   
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
$nf9++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf10++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf11++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf12++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
    $p1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p4++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
   $q1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
    $q2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q4++;
  }

}
}


 elseif ($c=preg_match_all ("/".$b1.$b4.$b8.$b6.$b5.$b6.$b7."/is", $zan, $matches  )) {


  $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
       $c3=$matches[6][0];     
      $d4=$matches[7][0];


if ($ab=strstr($zan, "$d1$c1$d2$c2$d3$c3$d4")){
$ab=strstr($zan, "$d1$c1$d2$c2$d3$c3$d4");
$az=newAll($ab);
echo "$az";


 $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Functional)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Functional)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $ab, $matches  ))
  {

  
    $fu1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $ab, $matches)) {
    
     $fu2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {
 
  $fu3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {

  $fu4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7.$b10.$f9."/is", $ab, $matches ))
  {
   $nf1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; 
 $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
   $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';


   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$a.$b7.$b9.$b11."/is", $ab, $matches ))
  {
   $nf5++;

  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf6++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf7++;
  
  }elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf8++;
  }
 

   $b1='(\d)'; $b2='(\\.)';$b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
    $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';
   
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
$nf9++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf10++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf11++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf12++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
    $p1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p4++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
   $q1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
    $q2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q4++;
  }


}

}



////////////////////////////////////second///////////////////////////////////////////////////
  


   $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(System)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(System)';$f8='(\\s+)';  $f9='(Requirements)';

  
  if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $zan, $matches  ))
  {
$d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
        $c3=$matches[6][0];



if ($ab=strstr($zan, "$d1$c1$d2$c2$d3$c3")){
$ab=strstr($zan, "$d1$c1$d2$c2$d3$c3");


$az=newAll($ab);
echo "$az";



 $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Functional)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Functional)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $ab, $matches  ))
  {

  
    $fu1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $ab, $matches)) {
    
     $fu2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {
 
  $fu3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {

  $fu4++;
  }

 $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7.$b10.$f9."/is", $ab, $matches ))
  {
   $nf1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; 
 $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
   $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';


   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$a.$b7.$b9.$b11."/is", $ab, $matches ))
  {
   $nf5++;

  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf6++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf7++;
  
  }elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf8++;
  }
 

   $b1='(\d)'; $b2='(\\.)';$b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
    $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';
   
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
$nf9++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf10++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf11++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf12++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
    $p1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p4++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
   $q1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
    $q2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q4++;
  }

}


}

 elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $zan, $matches)) {
$d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];


if ($ab=strstr($zan, "$d1$c1$d2$c2$d3")){
$ab=strstr($zan, "$d1$c1$d2$c2$d3");


$az=newAll($ab);
echo "$az";



 $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Functional)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Functional)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $ab, $matches  ))
  {

  
    $fu1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $ab, $matches)) {
    
     $fu2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {
 
  $fu3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {

  $fu4++;
  }

    $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7.$b10.$f9."/is", $ab, $matches ))
  {
   $nf1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; 
 $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
   $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';


   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$a.$b7.$b9.$b11."/is", $ab, $matches ))
  {
   $nf5++;

  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf6++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf7++;
  
  }elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf8++;
  }
 

   $b1='(\d)'; $b2='(\\.)';$b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
    $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';
   
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
$nf9++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf10++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf11++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf12++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
    $p1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p4++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
   $q1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
    $q2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q4++;
  }

} 
}
elseif ($c=preg_match_all ("/".$b1.$b2.$b4.$b8.$b9.$b5.$b6.$b7."/is", $zan, $matches  ))
  {
 $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
 $c3=$matches[6][0];
$d4=$matches[7][0];
 $c4=$matches[8][0];



if ($ab=strstr($zan, "$d1$c1$d2$c2$d3$c3$d4$c4")){
$ab=strstr($zan, "$d1$c1$d2$c2$d3$c3$d4$c4");
$az=newAll($ab);
echo "$az";


 $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Functional)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Functional)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $ab, $matches  ))
  {

  
    $fu1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $ab, $matches)) {
    
     $fu2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {
 
  $fu3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {

  $fu4++;
  }


 $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7.$b10.$f9."/is", $ab, $matches ))
  {
   $nf1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; 
 $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
   $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';


   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$a.$b7.$b9.$b11."/is", $ab, $matches ))
  {
   $nf5++;

  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf6++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf7++;
  
  }elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf8++;
  }
 

   $b1='(\d)'; $b2='(\\.)';$b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
    $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';
   
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
$nf9++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf10++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf11++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf12++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
    $p1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p4++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
   $q1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
    $q2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q4++;
  }


}
}


 elseif ($c=preg_match_all ("/".$b1.$b4.$b8.$b6.$b5.$b6.$b7."/is", $zan, $matches  )) {


  $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
       $c3=$matches[6][0];     
      $d4=$matches[7][0];


if ($ab=strstr($zan, "$d1$c1$d2$c2$d3$c3$d4")){
$ab=strstr($zan, "$d1$c1$d2$c2$d3$c3$d4");
$az=newAll($ab);
echo "$az";




 $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Functional)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Functional)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $ab, $matches  ))
  {

  
    $fu1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $ab, $matches)) {
    
     $fu2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {
 
  $fu3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {

  $fu4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7.$b10.$f9."/is", $ab, $matches ))
  {
   $nf1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; 
 $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
   $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';


   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$a.$b7.$b9.$b11."/is", $ab, $matches ))
  {
   $nf5++;

  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf6++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf7++;
  
  }elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf8++;
  }
 

   $b1='(\d)'; $b2='(\\.)';$b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
    $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';
   
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
$nf9++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf10++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf11++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf12++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
    $p1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p4++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
   $q1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
    $q2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q4++;
  }

}

}
  

  ///////////////////////////////////////////////////third/////////////////////////////////////////////////////////////////////

   $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(System)';  # Word 1
  $b6='(\\s+)';  $b7='(Features)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(System)';$f8='(\\s+)';  $f9='(Features)';

if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $zan, $matches  ))
  {
 $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
 $c3=$matches[6][0];
//echo "$zan";

if ($ab=strstr($zan, "$d1$c1$d2$c2$d3$c3")){
$ab=strstr($zan, "$d1$c1$d2$c2$d3$c3");

$az=newAll($ab);
echo "$az";


 $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Functional)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Functional)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $ab, $matches  ))
  {

  
    $fu1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $ab, $matches)) {
    
     $fu2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {
 
  $fu3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {

  $fu4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7.$b10.$f9."/is", $ab, $matches ))
  {
   $nf1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; 
 $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
   $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';


   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$a.$b7.$b9.$b11."/is", $ab, $matches ))
  {
   $nf5++;

  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf6++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf7++;
  
  }elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf8++;
  }
 

   $b1='(\d)'; $b2='(\\.)';$b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
    $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';
   
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
$nf9++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf10++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf11++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf12++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
    $p1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p4++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
   $q1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
    $q2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q4++;
  }

}


}
elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $zan, $matches)) {
 $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];




if ($ab=strstr($zan, "$d1$c1$d2$c2$d3")){
$ab=strstr($zan, "$d1$c1$d2$c2$d3");


$az=newAll($ab);
echo "$az";



 $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Functional)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Functional)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $ab, $matches  ))
  {

  
    $fu1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $ab, $matches)) {
    
     $fu2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {
 
  $fu3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {

  $fu4++;
  }



  $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7.$b10.$f9."/is", $ab, $matches ))
  {
   $nf1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; 
 $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
   $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';


   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$a.$b7.$b9.$b11."/is", $ab, $matches ))
  {
   $nf5++;

  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf6++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf7++;
  
  }elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf8++;
  }
 

   $b1='(\d)'; $b2='(\\.)';$b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
    $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';
   
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
$nf9++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf10++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf11++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf12++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
    $p1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p4++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
   $q1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
    $q2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q4++;
  }

}

 }
elseif ($c=preg_match_all ("/".$b1.$b2.$b4.$b8.$b9.$b5.$b6.$b7."/is", $zan, $matches  ))
  {
 $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
 $c3=$matches[6][0];
$d4=$matches[7][0];
 $c4=$matches[8][0];


if ($ab=strstr($zan, "$d1$c1$d2$c2$d3$c3$d4$c4")){
$ab=strstr($zan, "$d1$c1$d2$c2$d3$c3$d4$c4");
$az=newAll($ab);
echo "$az";


 $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Functional)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Functional)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $ab, $matches  ))
  {

  
    $fu1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $ab, $matches)) {
    
     $fu2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {
 
  $fu3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {

  $fu4++;
  }


  $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7.$b10.$f9."/is", $ab, $matches ))
  {
   $nf1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; 
 $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
   $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';


   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$a.$b7.$b9.$b11."/is", $ab, $matches ))
  {
   $nf5++;

  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf6++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf7++;
  
  }elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf8++;
  }
 

   $b1='(\d)'; $b2='(\\.)';$b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
    $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';
   
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
$nf9++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf10++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf11++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf12++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
    $p1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p4++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
   $q1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
    $q2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q4++;
  }

}
}


 elseif ($c=preg_match_all ("/".$b1.$b4.$b8.$b6.$b5.$b6.$b7."/is", $zan, $matches  )) {


  $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
       $c3=$matches[6][0];     
      $d4=$matches[7][0];


if ($ab=strstr($zan, "$d1$c1$d2$c2$d3$c3$d4")){
$ab=strstr($zan, "$d1$c1$d2$c2$d3$c3$d4");
$az=newAll($ab);
echo "$az";


 $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Functional)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Functional)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $ab, $matches  ))
  {

  
    $fu1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $ab, $matches)) {
    
     $fu2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {
 
  $fu3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {

  $fu4++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7.$b10.$f9."/is", $ab, $matches ))
  {
   $nf1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; 
 $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
   $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';


   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$a.$b7.$b9.$b11."/is", $ab, $matches ))
  {
   $nf5++;

  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf6++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf7++;
  
  }elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf8++;
  }
 

   $b1='(\d)'; $b2='(\\.)';$b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
    $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';
   
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
$nf9++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf10++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf11++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf12++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
    $p1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p4++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
   $q1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
    $q2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q4++;
  }

}

}
  


   $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Requirements)';  # Word 1
  $b6='(\\s+)';  $b7='(Specification)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Requirements)';$f8='(\\s+)';  $f9='(Specification)';


if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $zan, $matches  ))
  {
$d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
 $c3=$matches[6][0];



if ($ab=strstr($zan, "$d1$c1$d2$c2$d3$c3")){
$ab=strstr($zan, "$d1$c1$d2$c2$d3$c3");


$az=newAll($ab);
echo "$az";



 $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Functional)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Functional)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $ab, $matches  ))
  {

  
    $fu1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $ab, $matches)) {
    
     $fu2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {
 
  $fu3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {

  $fu4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7.$b10.$f9."/is", $ab, $matches ))
  {
   $nf1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; 
 $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
   $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';


   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$a.$b7.$b9.$b11."/is", $ab, $matches ))
  {
   $nf5++;

  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf6++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf7++;
  
  }elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf8++;
  }
 

   $b1='(\d)'; $b2='(\\.)';$b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
    $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';
   
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
$nf9++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf10++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf11++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf12++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
    $p1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p4++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
   $q1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
    $q2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q4++;
  }

}


}
 elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $zan, $matches)) {
$d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];


if ($ab=strstr($zan, "$d1$c1$d2$c2$d3")){
$ab=strstr($zan, "$d1$c1$d2$c2$d3");


$az=newAll($ab);
echo "$az";



 $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Functional)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Functional)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $ab, $matches  ))
  {

  
    $fu1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $ab, $matches)) {
    
     $fu2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {
 
  $fu3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {

  $fu4++;
  }


 $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7.$b10.$f9."/is", $ab, $matches ))
  {
   $nf1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; 
 $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
   $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';


   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$a.$b7.$b9.$b11."/is", $ab, $matches ))
  {
   $nf5++;

  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf6++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf7++;
  
  }elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf8++;
  }
 

   $b1='(\d)'; $b2='(\\.)';$b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
    $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';
   
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
$nf9++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf10++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf11++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf12++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
    $p1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p4++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
   $q1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
    $q2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q4++;
  }

    }

 }
 elseif ($c=preg_match_all ("/".$b1.$b2.$b4.$b8.$b9.$b5.$b6.$b7."/is", $zan, $matches  ))
  {
 $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
 $c3=$matches[6][0];
$d4=$matches[7][0];
 $c4=$matches[8][0];


if ($ab=strstr($zan, "$d1$c1$d2$c2$d3$c3$d4$c4")){
$ab=strstr($zan, "$d1$c1$d2$c2$d3$c3$d4$c4");
$az=newAll($ab);
echo "$az";




 $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Functional)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Functional)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $ab, $matches  ))
  {

  
    $fu1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $ab, $matches)) {
    
     $fu2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {
 
  $fu3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {

  $fu4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7.$b10.$f9."/is", $ab, $matches ))
  {
   $nf1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; 
 $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
   $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';


   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$a.$b7.$b9.$b11."/is", $ab, $matches ))
  {
   $nf5++;

  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf6++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf7++;
  
  }elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf8++;
  }
 

   $b1='(\d)'; $b2='(\\.)';$b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
    $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';
   
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
$nf9++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf10++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf11++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf12++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
    $p1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p4++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
   $q1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
    $q2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q4++;
  }

}
}


 elseif ($c=preg_match_all ("/".$b1.$b4.$b8.$b6.$b5.$b6.$b7."/is", $zan, $matches  )) {


  $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
       $c3=$matches[6][0];     
      $d4=$matches[7][0];


if ($ab=strstr($zan, "$d1$c1$d2$c2$d3$c3$d4")){
$ab=strstr($zan, "$d1$c1$d2$c2$d3$c3$d4");
$az=newAll($ab);
echo "$az";



 $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Functional)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Functional)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $ab, $matches  ))
  {

  
    $fu1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $ab, $matches)) {
    
     $fu2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {
 
  $fu3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {

  $fu4++;
  }

 $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7.$b10.$f9."/is", $ab, $matches ))
  {
   $nf1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; 
 $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
   $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';


   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$a.$b7.$b9.$b11."/is", $ab, $matches ))
  {
   $nf5++;

  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf6++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf7++;
  
  }elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf8++;
  }
 

   $b1='(\d)'; $b2='(\\.)';$b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
    $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';
   
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
$nf9++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf10++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf11++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf12++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
    $p1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p4++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
   $q1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
    $q2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q4++;
  }

}

}
  

$j1=0;$j2=0;$j3=0;$j4=0;$j5=0;$j6=0;$j7=0;$j8=0;$j9=0;$j10=0;$j11=0;$j12=0;$j13=0;$j14=0;$j15=0;$j16=0;$j17=0;$j18=0;$j19=0; $j20=0;
$j21=0;$j22=0;$j23=0;$j24=0;$j25=0;$j26=0;$j27=0;$j28=0;$j29=0;$j30=0;$j31=0;$j32=0;$j33=0;$j34=0;$j35=0;$j36=0;$j37=0;$j38=0;$j39=0; $j40=0;

$j41=0;$j42=0;$j43=0;$j44=0;$j45=0;$j46=0;$j47=0;$j48=0;$j49=0;$j50=0;$j51=0;$j52=0;$j53=0;$j54=0;$j55=0;$j56=0;$j57=0;$j58=0;$j59=0; $j60=0;
$j61=0;$j62=0;$j63=0;$j64=0;$j65=0;$j66=0;$j67=0;$j68=0;$j69=0;$j70=0;$j71=0;$j72=0;$j73=0;$j74=0;$j75=0;$j76=0;$j77=0;$j78=0;$j79=0; $j80=0;

$j81=0;$j82=0;$j83=0;$j84=0;$j85=0;$j86=0;$j87=0;$j88=0;$j89=0;$j90=0;$j91=0;$j92=0;$j93=0;$j94=0;$j95=0;$j96=0;$j97=0;$j98=0;$j99=0;

 $b1='(\d)'; $b2='(\\.)';

   $b4='(\\s+)';   $b5='(Functional)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Functional)';$f8='(\\s+)';  $f9='(Requirements)';




   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $zan, $matches  ))
  {
   

 if ($fu1 == 0) {


      $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
       $c3=$matches[6][0];     
    
 

if ($ab=strstr($zan, "$d1$c1$d2$c2$d3$c3")){
$ab1=strstr($zan, "$d1$c1$d2$c2$d3$c3");
$az=newAll($ab1);
echo "$az";



   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7.$b10.$f9."/is", $ab1, $matches ))
  {
   $j1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab1, $matches)) {
  $j3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab1, $matches)) {
  $j4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; 
 $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
   $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';


   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$a.$b7.$b9.$b11."/is", $ab1, $matches ))
  {
   $j5++;

  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$a.$b7.$b10.$f9."/is", $ab1, $matches)) {
    $j6++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j7++;
 
  }elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j8++;
  }
 

   $b1='(\d)'; $b2='(\\.)';$b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
    $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';
   
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
$j9++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$b7.$b10.$f9."/is", $ab1, $matches)) {
    $j10++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j11++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j12++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
    $j13++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j14++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j15++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j16++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
   $j17++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
    $j18++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j19++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j20++;
  }



}



 }

 
 else{
echo ".";
 }


  } 


 elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $zan, $matches)) {
 
 
 if ($fu2 ==0) {

      $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
    
    
 

if ($ab=strstr($zan, "$d1$c1$d2$c2$d3")){
$ab1=strstr($zan, "$d1$c1$d2$c2$d3");
$az=newAll($ab1);
echo "$az";




   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7.$b10.$f9."/is", $ab1, $matches ))
  {
   $j1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab1, $matches)) {
  $j3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab1, $matches)) {
  $j4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; 
 $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
   $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';


   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$a.$b7.$b9.$b11."/is", $ab1, $matches ))
  {
   $j5++;

  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$a.$b7.$b10.$f9."/is", $ab1, $matches)) {
    $j6++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j7++;
 
  }elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j8++;
  }
 

   $b1='(\d)'; $b2='(\\.)';$b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
    $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';
   
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
$j9++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$b7.$b10.$f9."/is", $ab1, $matches)) {
    $j10++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j11++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j12++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
    $j13++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j14++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j15++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j16++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
   $j17++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
    $j18++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j19++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j20++;
  }

}

 }

 
 else{
echo ".";
 }


}elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $zan, $matches)) {
    
   

 
 if ($fu3 == 0) {

      $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
      $c3=$matches[6][0];     
      $d4=$matches[7][0];
    
 

if ($ab=strstr($zan, "$d1$c1$d2$c2$d3$c3$d4")){
$ab1=strstr($zan, "$d1$c1$d2$c2$d3$c3$d4");
$az=newAll($ab1);
echo "$az";



   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7.$b10.$f9."/is", $ab1, $matches ))
  {
   $j1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab1, $matches)) {
  $j3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab1, $matches)) {
  $j4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; 
 $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
   $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';


   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$a.$b7.$b9.$b11."/is", $ab1, $matches ))
  {
   $j5++;

  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$a.$b7.$b10.$f9."/is", $ab1, $matches)) {
    $j6++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j7++;
 
  }elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j8++;
  }
 

   $b1='(\d)'; $b2='(\\.)';$b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
    $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';
   
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
$j9++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$b7.$b10.$f9."/is", $ab1, $matches)) {
    $j10++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j11++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j12++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
    $j13++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j14++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j15++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j16++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
   $j17++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
    $j18++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j19++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j20++;
  }

}


 }

 
 else{
echo ".";
 }
}

elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $zan, $matches)) {


 
 if ($fu4 == 0) {

  
     
      $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
      $c3=$matches[6][0];     
      $d4=$matches[7][0];
    $c4=$matches[8][0];
 

if ($ab=strstr($zan, "$d1$c1$d2$c2$d3$c3$d4$c4")){
$ab1=strstr($zan, "$d1$c1$d2$c2$d3$c3$d4$c4");
$az=newAll($ab1);
echo "$az";

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7.$b10.$f9."/is", $ab1, $matches ))
  {
   $j1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab1, $matches)) {
  $j3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab1, $matches)) {
  $j4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; 
 $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
   $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';


   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$a.$b7.$b9.$b11."/is", $ab1, $matches ))
  {
   $j5++;

  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$a.$b7.$b10.$f9."/is", $ab1, $matches)) {
    $j6++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j7++;
 
  }elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j8++;
  }
 

   $b1='(\d)'; $b2='(\\.)';$b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
    $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';
   
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
$j9++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$b7.$b10.$f9."/is", $ab1, $matches)) {
    $j10++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j11++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j12++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
    $j13++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j14++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j15++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j16++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
   $j17++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
    $j18++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j19++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j20++;
  }

}


 }

 
 else{
echo ".";
 }
}




$k1=0;$k2=0;$k3=0;$k4=0;$k5=0;$k6=0;$k7=0;$k8=0;$k9=0;$k10=0;$k11=0;$k12=0;$k13=0;$k14=0;$k15=0;$k16=0;$k17=0;$k18=0;$k19=0; $k20=0;
$k21=0;$k22=0;$k23=0;$k24=0;$k25=0;$k26=0;$k27=0;$k28=0;$k29=0;$k30=0;$k31=0;$k32=0;$k33=0;$k34=0;$k35=0;$k36=0;$k37=0;$k38=0;$k39=0; $k40=0;




   $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Non)';  # Word 1
  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7.$b10.$f9."/is", $zan, $matches ))
  {


 
 if ($nf1 == 0) {
    if ($j1 ==0) {
    

  
      $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
      $c3=$matches[6][0];     
      $d4=$matches[7][0];
     $c4=$matches[8][0];
 

if ($ab=strstr($zan, "$d1$c1$d2$c2$d3$c3$d4$c4")){
$ab1=strstr($zan, "$d1$c1$d2$c2$d3$c3$d4$c4");
$az=newAll($ab1);
echo "$az";


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
    $j13++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j14++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j15++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j16++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
   $j17++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
    $j18++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j19++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j20++;
  }

}
}

}

 else{
echo ".";
 }

  } 
  elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$b7.$b10.$f9."/is", $zan, $matches)) {
   

 
 if ($nf2 == 0) {
if ($j2 ==0) {
  
      $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
      $c3=$matches[6][0];     
      $d4=$matches[7][0];
     
 

if ($ab=strstr($zan, "$d1$c1$d2$c2$d3$c3$d4")){
$ab1=strstr($zan, "$d1$c1$d2$c2$d3$c3$d4");
$az=newAll($ab1);
echo "$az";


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
    $j13++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j14++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j15++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j16++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
   $j17++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
    $j18++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j19++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j20++;
  }
}
}
}

 else{
echo ".";
 }

  }
elseif  ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $zan, $matches)) {
  



 if ($nf3 == 0) {
if ($j3 ==0) {
  
      $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
      $c3=$matches[6][0];     
      $d4=$matches[7][0];
      $c4=$matches[8][0];     
      $d5=$matches[9][0];

if ($ab=strstr($zan, "$d1$c1$d2$c2$d3$c3$d4$c4$d5")){
$ab1=strstr($zan, "$d1$c1$d2$c2$d3$c3$d4$c4$d5");
$az=newAll($ab1);
echo "$az";


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
    $j13++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j14++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j15++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j16++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
   $j17++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
    $j18++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j19++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j20++;
  }
}
}
}
 
 else{
echo ".";
 }

  } elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $zan, $matches)) {

 if ($nf4 == 0) {
if ($j4 ==0) {
  
      $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
      $c3=$matches[6][0];     
      $d4=$matches[7][0];
     
 $c4=$matches[8][0];     
      $d5=$matches[9][0];
$c5=$matches[10][0];


if ($ab=strstr($zan, "$d1$c1$d2$c2$d3$c3$d4$c4$d5$c5")){
$ab1=strstr($zan, "$d1$c1$d2$c2$d3$c3$d4$c4$d5$c5");
$az=newAll($ab1);
echo "$az";


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
    $j13++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j14++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j15++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j16++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
   $j17++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
    $j18++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j19++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j20++;
  }
}
}
}
 
 else{
echo "already";
 }
  }

  

   $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Non)';  # Word 1 

  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

 $spe=0;
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$a.$b7.$b9.$b11."/is", $zan, $matches ))
  {

 if ($nf5 == 0) {
if ($j5 ==0) {
  
      $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
      $c3=$matches[6][0];     
      $d4=$matches[7][0];
     
 $c4=$matches[8][0];     
      


if ($ab=strstr($zan, "$d1$c1$d2$c2$d3$c3$d4$c4")){
$ab1=strstr($zan, "$d1$c1$d2$c2$d3$c3$d4$c4");
$az=newAll($ab1);
echo "$az";


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
    $j13++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j14++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j15++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j16++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
   $j17++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
    $j18++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j19++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j20++;
  }
}
}
}
 
 else{
echo ".";
 }


  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$a.$b7.$b10.$f9."/is", $zan, $matches)) {



 if ($nf6 == 0) {
if ($j6 ==0) {
  
      $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
      $c3=$matches[6][0];     
      $d4=$matches[7][0];
     
 

if ($ab=strstr($zan, "$d1$c1$d2$c2$d3$c3$d4")){
$ab1=strstr($zan, "$d1$c1$d2$c2$d3$c3$d4");
$az=newAll($ab1);
echo "$az";


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
    $j13++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j14++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j15++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j16++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
   $j17++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
    $j18++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j19++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j20++;
  }
}
}
}
 else{
echo ".";
 }


  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $zan, $matches)) {

 if ($nf7 == 0) {
if ($j7 ==0) {
  
      $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
      $c3=$matches[6][0];     
      $d4=$matches[7][0];
     
 $c4=$matches[8][0];     
      $d5=$matches[9][0];



if ($ab=strstr($zan, "$d1$c1$d2$c2$d3$c3$d4$c4$d5")){
$ab1=strstr($zan, "$d1$c1$d2$c2$d3$c3$d4$c4$d5");
$az=newAll($ab1);
echo "$az";

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
    $j13++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j14++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j15++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j16++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
   $j17++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
    $j18++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j19++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j20++;
  }
}
}
}
 
 else{
echo ".";
 }
  
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $zan, $matches)) {


 if ($nf8 == 0) {
if ($j8 ==0) {
  
      $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
      $c3=$matches[6][0];     
      $d4=$matches[7][0];
     
 $c4=$matches[8][0];     
      $d5=$matches[9][0];
$c5=$matches[10][0];


if ($ab=strstr($zan, "$d1$c1$d2$c2$d3$c3$d4$c4$d5$c5")){
$ab1=strstr($zan, "$d1$c1$d2$c2$d3$c3$d4$c4$d5$c5");
$az=newAll($ab1);
echo "$az";


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
    $j13++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j14++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j15++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j16++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
   $j17++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
    $j18++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j19++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j20++;
  }
}
}
}
 
 else{
echo ".";
 }
  }
  



   $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Non)';  # Word 1 

  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b7.$b9.$b11."/is", $zan, $matches  ))
  {


 if ($nf9 == 0) {
if ($j9 ==0) {
  
      $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
      $c3=$matches[6][0];     
      $d4=$matches[7][0];
     
 

if ($ab=strstr($zan, "$d1$c1$d2$c2$d3$c3$d4")){
$ab1=strstr($zan, "$d1$c1$d2$c2$d3$c3$d4");
$az=newAll($ab1);
echo "$az";


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
    $j13++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j14++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j15++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j16++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
   $j17++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
    $j18++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j19++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j20++;
  }
}
}
}
 else{
echo ".";
 }


  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$b7.$b10.$f9."/is", $zan, $matches)) {


 if ($nf10 == 0) {
if ($j10 ==0) {
  
      $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
      $c3=$matches[6][0];     
    
     
 

if ($ab=strstr($zan, "$d1$c1$d2$c2$d3$c3")){
$ab1=strstr($zan, "$d1$c1$d2$c2$d3$c3");
$az=newAll($ab1);
echo "$az";


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
    $j13++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j14++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j15++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j16++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
   $j17++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
    $j18++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j19++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j20++;
  }
}
}
}
 
 else{
echo ".";
 }


  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $zan, $matches)) {
   


 if ($nf11 == 0) {
if ($j11 ==0) {
  
      $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
      $c3=$matches[6][0];     
      $d4=$matches[7][0];
     $c4=$matches[8][0];
 

if ($ab=strstr($zan, "$d1$c1$d2$c2$d3$c3$d4$c4")){
$ab1=strstr($zan, "$d1$c1$d2$c2$d3$c3$d4$c4");
$az=newAll($ab1);
echo "$az";


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
    $j13++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j14++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j15++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j16++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
   $j17++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
    $j18++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j19++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j20++;
  }
}
}
}
 
 else{
echo ".";
 }

  }
 elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $zan, $matches)) {
 


 if ($nf12 == 0) {
if ($j12 ==0) {
  
      $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
      $c3=$matches[6][0];     
      $d4=$matches[7][0];
     $c4=$matches[8][0];
 $d5=$matches[9][0];

if ($ab=strstr($zan, "$d1$c1$d2$c2$d3$c3$d4$c4$d5")){
$ab1=strstr($zan, "$d1$c1$d2$c2$d3$c3$d4$c4$d5");
$az=newAll($ab1);
echo "$az";


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
    $j13++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j14++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j15++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j16++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
   $j17++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
    $j18++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j19++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j20++;
  }
}
}
}
 
 else{
echo ".";
 }
  }

/////////////////////// non functionals end//////////////////////

  
$y1=0;$y2=0;$y3=0;$y4=0;$y5=0;$y6=0;$y7=0;$y8=0;$y9=0;$y10=0;$y11=0;$y12=0;$y13=0;$y14=0;$y15=0;$y16=0;$y17=0;$y18=0;$y19=0;$y20=0;$y21=0;$y22=0;$y23=0;

   $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Non)';  # Word 1 

  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $zan, $matches  ))
  {


 if ($p1 == 0) {
if (($j13 AND $j14 AND $j15 AND $j16) > 0) {
 

      $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
      $c3=$matches[6][0];     
   

if ($ab=strstr($zan, "$d1$c1$d2$c2$d3$c3")){
$ab1=strstr($zan, "$d1$c1$d2$c2$d3$c3");
$az=newAll($ab1);
echo "$az";


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
   $j17++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
    $j18++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j19++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j20++;
  }
}
} 
}
 
 else{
echo " ";
 }


  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $zan, $matches)) {


 if ($p2 == 0) {
if (($j13 AND $j14 AND $j15 AND $j16) > 0) {
  
      $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
      

if ($ab=strstr($zan, "$d1$c1$d2$c2$d3")){
$ab1=strstr($zan, "$d1$c1$d2$c2$d3");
$az=newAll($ab1);
echo "$az";


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
   $j17++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
    $j18++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j19++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j20++;
  }
}
}
}
 
 
 else{
echo ".";
 }

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $zan, $matches)) {
   


 if ($p3 == 0) {

  if (($j13 AND $j14 AND $j15 AND $j16) > 0) {
      $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
      $c3=$matches[6][0];     
      $d4=$matches[7][0];
    

if ($ab=strstr($zan, "$d1$c1$d2$c2$d3$c3$d4")){
$ab1=strstr($zan, "$d1$c1$d2$c2$d3$c3$d4");
$az=newAll($ab1);
echo "$az";



   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
   $j17++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
    $j18++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j19++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j20++;
  }
}
}
}
 

 else{
echo ".";
 }
  }
 elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $zan, $matches)) {
   

 if ($p4 == 0) {
if (($j13 AND $j14 AND $j15 AND $j16) > 0) {
  
      $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
      $c3=$matches[6][0];     
      $d4=$matches[7][0];
     $c4=$matches[8][0];


if ($ab=strstr($zan, "$d1$c1$d2$c2$d3$c3$d4$c4")){
$ab1=strstr($zan, "$d1$c1$d2$c2$d3$c3$d4$c4");
$az=newAll($ab1);
echo "$az";



   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
   $j17++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
    $j18++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j19++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j20++;
  }
}
}
}
 
 else{
echo ".";
 }
  }



   $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Non)';  # Word 1 

  $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $zan, $matches  ))
  {


 if ($q1 == 0) {
if (($j17 AND $j18 AND $j19 AND $j20) > 0) {
  
      $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
      $c3=$matches[6][0];     
    


if ($ab=strstr($zan, "$d1$c1$d2$c2$d3$c3")){
$ab1=strstr($zan, "$d1$c1$d2$c2$d3$c3");
$az=newAll($ab1);
echo "$az";
}
}
 }
 
 else{
echo " ";
 }

   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $zan, $matches)) {
    

 if ($q2 == 0) {
if (($j17 AND $j18 AND $j19 AND $j20) > 0) {
  
      $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
      


if ($ab=strstr($zan, "$d1$c1$d2$c2$d3")){
$ab1=strstr($zan, "$d1$c1$d2$c2$d3");
$az=newAll($ab1);
echo "$az";
}
}
}
 
 else{
echo " ";
 }

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $zan, $matches)) {



 if ($q3 == 0) {

  if (($j17 AND $j18 AND $j19 AND $j20) > 0) {
      $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
      $c3=$matches[6][0];     
      $d4=$matches[7][0];
     


if ($ab=strstr($zan, "$d1$c1$d2$c2$d3$c3$d4")){
$ab1=strstr($zan, "$d1$c1$d2$c2$d3$c3$d4");
$az=newAll($ab1);
echo "$az";
}
}
 }
 else{
echo " ";
 }

  }
elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $zan, $matches)) {
  


 if ($q4 == 0) {
if (($j17 AND $j18 AND $j19 AND $j20) > 0) {
  
      $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
      $c3=$matches[6][0];     
      $d4=$matches[7][0];
      $c4=$matches[8][0];


if ($ab=strstr($zan, "$d1$c1$d2$c2$d3$c3$d4$c4")){
$ab1=strstr($zan, "$d1$c1$d2$c2$d3$c3$d4$c4");
$az=newAll($ab1);
echo "$az";
}
}
}
   else{
echo " ";
 }

  }

 
 
}
  elseif (substr($name, -4)  == '.pdf') {


// Include Composer autoloader if not already done.
include 'vendor/autoload.php';
// Parse pdf file and build necessary objects.
$parser = new \Smalot\PdfParser\Parser();
$pdf = $parser->parseFile("files/$name");
// Retrieve all pages from the pdf file.

$tex = $pdf->getText();
$text = trim($tex); // remove the last \n or whitespace character
function striplines($s,$n){
    $arr = explode("\n", $s);
    for ($i=0;$i<$n;$i++) array_shift($arr);
    return implode("\n", $arr);
}

$zn= striplines($text,100);

$zan = join("\n", array_slice(explode("\n", $zn), 0, -100));
$pd=pdf($zan);
echo "$pd";

}
elseif (substr($name, -5) == '.docx') {


$docObj = new Filetotext("files/$name");
$return = $docObj->convertToText();


  $text = trim($return); // remove the last \n or whitespace character
$text1 = nl2br($text);

function striplines($s,$n){
    $arr = explode("\n", $s);
    for ($i=0;$i<$n;$i++) array_shift($arr);
    return implode("\n", $arr);
}

$zn= striplines($text1,100);

$zan = join("\n", array_slice(explode("\n", $zn), 0, -100));


$pd=docx($zan);
echo "$pd";


}
elseif (substr($name, -4) == '.doc') {
require 'Docx/fun.class.php';
       $docObj = new Filetotext("files/$name");




$return = $docObj->convertToText();

$text1 = nl2br($return);
$text = trim($text1); // remove the last \n or whitespace character

$rest = substr("$text",3500,-7000); 
$pd=doc($rest);
echo "$pd";
/*
 $lines = explode("\n", $text1);
foreach( $lines as $index => $line )
{

 echo $lines[$index] = $line . '<br/>';
}
*/
 }

}
}
else{
  echo "You did not enter any SRS ";
}
}



?>


</table>
</form>
</body>
</html>