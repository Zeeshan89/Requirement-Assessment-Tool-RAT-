<?php
include 'database1.php';
$connection=mysqli_connect("localhost","root","","fyp");
 global $connection;


$a1=0;$a2=0;$a3=0;$a4=0;$a5=0;$a6=0;$a7=0;$a8=0;$a9=0;$a10=0;$a11=0;$a12=0;$a13=0;$a14=0;$a15=0;$a16=0;






function highlightkeyword($str, $search) {
    $highlightcolor = "yellow";
    $occurrences = substr_count(strtolower($str), strtolower($search));
    $newstring = $str;
    $match = array();
 
    for ($i=0;$i<$occurrences;$i++) {
        $match[$i] = stripos($str, $search, $i);    // index start word in str
        $match[$i] = substr($str, $match[$i], strlen($search));
        $newstring = str_replace($match[$i], '[#]'.$match[$i].'[@]', strip_tags($newstring,"<span>"));
    }
 
    $newstring = str_replace('[#]', '<span style="background-color: '.$highlightcolor.';">', $newstring);
    $newstring = str_replace('[@]', '</span>', $newstring);
    return $newstring;
 
}

















function highlight($sp)
{
    global $connection;


$sql = "select words from srswords";
$result = mysqli_query($connection, $sql);
if (mysqli_num_rows($result) > 0) {
  while($row = mysqli_fetch_assoc($result)) {
    $keyword = $row["words"];
    $sp = highlightkeyword($sp, $keyword) ;

  }   
}
$xy=$sp;
$text = trim($xy); // remove the last \n or whitespace character
$text1 = nl2br($text);
return $text1;
}















function All($ab)
{
  global $connection;


 $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Supporting)';  # Word 1
  $b6='(\\s+)';  $b7='(Information)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Supporting)';$f8='(\\s+)';  $f9='(Information)';
if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $ab, $matches  ))
  {
   
///// 1. Supporting Information////
      $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
       $c3=$matches[6][0];     

if ($ab2=strstr($ab, "$d1$c1$d2$c2$d3$c3")){
$ab2=strstr($ab, "$d1$c1$d2$c2$d3$c3");
 $ann=strlen($ab2);
      $sp=substr($ab, 0, -$ann);
$ne=highlight($sp);

$text1 = nl2br($ne);

  $words = explode(' ', $text1);
 echo "<p style='text-align: justify;'>";

  $counter = 0;
  foreach ($words as $word) {
    echo $word . ' ';
    if (++$counter >= 10) {
      if (substr($word, -1) === '.') {
        echo "</p><p style='text-align: justify;'>"; // End the paragraph and start a new one.
        $counter = 0;
      }
    }
  }
  echo '</p>';



}



}  elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $ab, $matches)) {
    

/////////////1 Supporting Information///////////
     $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
      

if ($ab2=strstr($ab, "$d1$c1$d2$c2$d3")){
$ab2=strstr($ab, "$d1$c1$d2$c2$d3");
$ann=strlen($ab2);
$sp=substr($ab, 0, -$ann);
$ne=highlight($sp);
$text1 = nl2br($ne);

  $words = explode(' ', $text1);
 echo "<p style='text-align: justify;'>";

  $counter = 0;
  foreach ($words as $word) {
    echo $word . ' ';
    if (++$counter >= 10) {
      if (substr($word, -1) === '.') {
        echo "</p><p style='text-align: justify;'>"; // End the paragraph and start a new one.
        $counter = 0;
      }
    }
  }
  echo '</p>';
}


  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {


////////////////// 1 The Supporting Information//////////
      $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
       $c3=$matches[6][0];
       $d4=$matches[7][0];     

if ($ab2=strstr($ab, "$d1$c1$d2$c2$d3$c3$d4")){
$ab2=strstr($ab, "$d1$c1$d2$c2$d3$c3$d4");
$ann=strlen($ab2);
      $sp=substr($ab, 0, -$ann);
$ne=highlight($sp);
$text1 = nl2br($ne);

  $words = explode(' ', $text1);
 echo "<p style='text-align: justify;'>";

  $counter = 0;
  foreach ($words as $word) {
    echo $word . ' ';
    if (++$counter >= 10) {
      if (substr($word, -1) === '.') {
        echo "</p><p style='text-align: justify;'>"; // End the paragraph and start a new one.
        $counter = 0;
      }
    }
  }
  echo '</p>';
}

  }
   elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)){
    
    $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
       $c3=$matches[6][0];
       $d4=$matches[7][0];     
      $c4=$matches[8][0];


if ($ab2=strstr($ab, "$d1$c1$d2$c2$d3$c3$d4$c4")){
$ab2=strstr($ab, "$d1$c1$d2$c2$d3$c3$d4$c4");
$ann=strlen($ab2);
$sp=substr($ab, 0, -$ann);
$ne=highlight($sp);
$text1 = nl2br($ne);

  $words = explode(' ', $text1);
 echo "<p style='text-align: justify;'>";

  $counter = 0;
  foreach ($words as $word) {
    echo $word . ' ';
    if (++$counter >= 10) {
      if (substr($word, -1) === '.') {
        echo "</p><p style='text-align: justify;'>"; // End the paragraph and start a new one.
        $counter = 0;
      }
    }
  }
  echo '</p>';

  }

  }



   $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Other)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Other)';$f8='(\\s+)';  $f9='(Requirements)';
if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $ab, $matches  ))
  {
    
  $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
       $c3=$matches[6][0];

if ($ab2=strstr($ab, "$d1$c1$d2$c2$d3$c3")){
$ab2=strstr($ab, "$d1$c1$d2$c2$d3$c3");
$ann=strlen($ab2);
      $sp=substr($ab, 0, -$ann);
$ne=highlight($sp);
$text1 = nl2br($ne);

  $words = explode(' ', $text1);
 echo "<p style='text-align: justify;'>";

  $counter = 0;
  foreach ($words as $word) {
    echo $word . ' ';
    if (++$counter >= 10) {
      if (substr($word, -1) === '.') {
        echo "</p><p style='text-align: justify;'>"; // End the paragraph and start a new one.
        $counter = 0;
      }
    }
  }
  echo '</p>';

  }   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $ab, $matches))  {
  
  $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
      

if ($ab2=strstr($ab, "$d1$c1$d2$c2$d3")){
$ab2=strstr($ab, "$d1$c1$d2$c2$d3");
$ann=strlen($ab2);
      $sp=substr($ab, 0, -$ann);
$ne=highlight($sp);
$text1 = nl2br($ne);

  $words = explode(' ', $text1);
 echo "<p style='text-align: justify;'>";

  $counter = 0;
  foreach ($words as $word) {
    echo $word . ' ';
    if (++$counter >= 10) {
      if (substr($word, -1) === '.') {
        echo "</p><p style='text-align: justify;'>"; // End the paragraph and start a new one.
        $counter = 0;
      }
    }
  }
  echo '</p>';

}
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {
     $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
      $d4=$matches[7][0];     
   



if ($ab2=strstr($ab, "$d1$c1$d2$c2$d3$c3$d4")){
$ab2=strstr($ab, "$d1$c1$d2$c2$d3$c3$d4");
$ann=strlen($ab2);
    $sp=substr($ab, 0, -$ann);
$ne=highlight($sp);
$text1 = nl2br($ne);

  $words = explode(' ', $text1);
 echo "<p style='text-align: justify;'>";

  $counter = 0;
  foreach ($words as $word) {
    echo $word . ' ';
    if (++$counter >= 10) {
      if (substr($word, -1) === '.') {
        echo "</p><p style='text-align: justify;'>"; // End the paragraph and start a new one.
        $counter = 0;
      }
    }
  }
  echo '</p>';
}
  }
elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {
     $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
      $d4=$matches[7][0];     
      $c4=$matches[8][0];



if ($ab2=strstr($ab, "$d1$c1$d2$c2$d3$c3$d4$c4")){
$ab2=strstr($ab, "$d1$c1$d2$c2$d3$c3$d4$c4");
$ann=strlen($ab2);
    $sp=substr($ab, 0, -$ann);
$ne=highlight($sp);
$text1 = nl2br($ne);

  $words = explode(' ', $text1);
 echo "<p style='text-align: justify;'>";

  $counter = 0;
  foreach ($words as $word) {
    echo $word . ' ';
    if (++$counter >= 10) {
      if (substr($word, -1) === '.') {
        echo "</p><p style='text-align: justify;'>"; // End the paragraph and start a new one.
        $counter = 0;
      }
    }
  }
  echo '</p>';


  }
}



   $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Appendix)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Appendix)';$f8='(\\s+)';  $f9='(Requirements)';


   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5."/is", $ab, $matches  ))
  {
 $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     

if ($ab2=strstr($ab, "$d1$c1$d2$c2")){
$ab2=strstr($ab, "$d1$c1$d2$c2");
$ann=strlen($ab2);
      $sp=substr($ab, 0, -$ann);
$ne=highlight($sp);


  $words = explode(' ', $ne);
 echo "<p style='text-align: justify;'>";

  $counter = 0;
  foreach ($words as $word) {
    echo $word . ' ';
    if (++$counter >= 10) {
      if (substr($word, -1) === '.') {
        echo "</p><p style='text-align: justify;'>"; // End the paragraph and start a new one.
        $counter = 0;
      }
    }
  }
  echo '</p>';
}

  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7."/is", $ab, $matches)) {
      $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];

if ($ab2=strstr($ab, "$d1$c1$d2")){
$ab2=strstr($ab, "$d1$c1$d2");
$ann=strlen($ab2);
      $sp=substr($ab, 0, -$ann);
$ne=highlight($sp);
$text1 = nl2br($ne);

  $words = explode(' ', $text1);
 echo "<p style='text-align: justify;'>";

  $counter = 0;
  foreach ($words as $word) {
    echo $word . ' ';
    if (++$counter >= 10) {
      if (substr($word, -1) === '.') {
        echo "</p><p style='text-align: justify;'>"; // End the paragraph and start a new one.
        $counter = 0;
      }
    }
  }
  echo '</p>';
}
    
  }elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7."/is", $ab, $matches)) {
   $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
       $c3=$matches[6][0];

if ($ab2=strstr($ab, "$d1$c1$d2$c2$d3$c3")){
$ab2=strstr($ab, "$d1$c1$d2$c2$d3$c3");
$ann=strlen($ab2);
      $sp=substr($ab, 0, -$ann);
$ne=highlight($sp);
$text1 = nl2br($ne);

  $words = explode(' ', $text1);
 echo "<p style='text-align: justify;'>";

  $counter = 0;
  foreach ($words as $word) {
    echo $word . ' ';
    if (++$counter >= 10) {
      if (substr($word, -1) === '.') {
        echo "</p><p style='text-align: justify;'>"; // End the paragraph and start a new one.
        $counter = 0;
      }
    }
  }
  echo '</p>';


  }
}

////////////////// 1 The Appendix////////////

  elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7."/is", $ab, $matches)) {

$d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
      

if ($ab2=strstr($ab, "$d1$c1$d2$c2$d3")){
$ab2=strstr($ab, "$d1$c1$d2$c2$d3");
$ann=strlen($ab2);
      $sp=substr($ab, 0, -$ann);
$ne=highlight($sp);
$text1 = nl2br($ne);

  $words = explode(' ', $text1);
 echo "<p style='text-align: justify;'>";

  $counter = 0;
  foreach ($words as $word) {
    echo $word . ' ';
    if (++$counter >= 10) {
      if (substr($word, -1) === '.') {
        echo "</p><p style='text-align: justify;'>"; // End the paragraph and start a new one.
        $counter = 0;
      }
    }
  }
  echo '</p>';

}
}




   

   $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(References)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(References)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5."/is", $ab, $matches  ))
  { 
     $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      

if ($ab2=strstr($ab, "$d1$c1$d2$c2")){
$ab2=strstr($ab, "$d1$c1$d2$c2");
$ann=strlen($ab2);
      $sp=substr($ab, 0, -$ann);
$ne=highlight($sp);
$text1 = nl2br($ne);

  $words = explode(' ', $text1);
 echo "<p style='text-align: justify;'>";

  $counter = 0;
  foreach ($words as $word) {
    echo $word . ' ';
    if (++$counter >= 10) {
      if (substr($word, -1) === '.') {
        echo "</p><p style='text-align: justify;'>"; // End the paragraph and start a new one.
        $counter = 0;
      }
    }
  }
  echo '</p>';

}

  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7."/is", $ab, $matches)) {
    $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
         

if ($ab2=strstr($ab, "$d1$c1$d2")){
$ab2=strstr($ab, "$d1$c1$d2");
$ann=strlen($ab2);
      $sp=substr($ab, 0, -$ann);
$ne=highlight($sp);
$text1 = nl2br($ne);

  $words = explode(' ', $text1);
 echo "<p style='text-align: justify;'>";

  $counter = 0;
  foreach ($words as $word) {
    echo $word . ' ';
    if (++$counter >= 10) {
      if (substr($word, -1) === '.') {
        echo "</p><p style='text-align: justify;'>"; // End the paragraph and start a new one.
        $counter = 0;
      }
    }
  }
  echo '</p>';

   }  
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7."/is", $ab, $matches)) {
     
       $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
     
 
if ($ab2=strstr($ab, "$d1$c1$d2$c2$d3")){
$ab2=strstr($ab, "$d1$c1$d2$c2$d3");
$ann=strlen($ab2);
      $sp=substr($ab, 0, -$ann);
$ne=highlight($sp);
$text1 = nl2br($ne);

  $words = explode(' ', $text1);
 echo "<p style='text-align: justify;'>";

  $counter = 0;
  foreach ($words as $word) {
    echo $word . ' ';
    if (++$counter >= 10) {
      if (substr($word, -1) === '.') {
        echo "</p><p style='text-align: justify;'>"; // End the paragraph and start a new one.
        $counter = 0;
      }
    }
  }
  echo '</p>';
}
  }
elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7."/is", $ab, $matches)) {
    
       $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
      $c3=$matches[6][0];
          

if ($ab2=strstr($ab, "$d1$c1$d2$c2$d3$c3")){
$ab2=strstr($ab, "$d1$c1$d2$c2$d3$c3");
$ann=strlen($ab2);
      $sp=substr($ab, 0, -$ann);
$ne=highlight($sp);
$text1 = nl2br($ne);

  $words = explode(' ', $text1);
 echo "<p style='text-align: justify;'>";

  $counter = 0;
  foreach ($words as $word) {
    echo $word . ' ';
    if (++$counter >= 10) {
      if (substr($word, -1) === '.') {
        echo "</p><p style='text-align: justify;'>"; // End the paragraph and start a new one.
        $counter = 0;
      }
    }
  }
  echo '</p>';
  }

}


   $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Glossary)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Glossary)';


   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5."/is", $ab, $matches  ))
  {
     $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      

if ($ab2=strstr($ab, "$d1$c1$d2$c2")){
$ab2=strstr($ab, "$d1$c1$d2$c2");
$ann=strlen($ab2);
      $sp=substr($ab, 0, -$ann);
$ne=highlight($sp);
$text1 = nl2br($ne);

  $words = explode(' ', $text1);
 echo "<p style='text-align: justify;'>";

  $counter = 0;
  foreach ($words as $word) {
    echo $word . ' ';
    if (++$counter >= 10) {
      if (substr($word, -1) === '.') {
        echo "</p><p style='text-align: justify;'>"; // End the paragraph and start a new one.
        $counter = 0;
      }
    }
  }
  echo '</p>';

}
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7."/is", $ab, $matches)) {
   $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
     

if ($ab2=strstr($ab, "$d1$c1$d2")){
$ab2=strstr($ab, "$d1$c1$d2");
$ann=strlen($ab2);
      $sp=substr($ab, 0, -$ann);
$ne=highlight($sp);
$text1 = nl2br($ne);

  $words = explode(' ', $text1);
 echo "<p style='text-align: justify;'>";

  $counter = 0;
  foreach ($words as $word) {
    echo $word . ' ';
    if (++$counter >= 10) {
      if (substr($word, -1) === '.') {
        echo "</p><p style='text-align: justify;'>"; // End the paragraph and start a new one.
        $counter = 0;
      }
    }
  }
  echo '</p>';
}
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7."/is", $ab, $matches)) {

     $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
    
 
if ($ab2=strstr($ab, "$d1$c1$d2$c2$d3")){
$ab2=strstr($ab, "$d1$c1$d2$c2$d3");
$ann=strlen($ab2);
      $sp=substr($ab, 0, -$ann);
$ne=highlight($sp);
$text1 = nl2br($ne);

  $words = explode(' ', $text1);
 echo "<p style='text-align: justify;'>";

  $counter = 0;
  foreach ($words as $word) {
    echo $word . ' ';
    if (++$counter >= 10) {
      if (substr($word, -1) === '.') {
        echo "</p><p style='text-align: justify;'>"; // End the paragraph and start a new one.
        $counter = 0;
      }
    }
  }
  echo '</p>';
  } 
}
elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7."/is", $ab, $matches)) {
   $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
      $c3=$matches[6][0];
          

if ($ab2=strstr($ab, "$d1$c1$d2$c2$d3$c3")){
$ab2=strstr($ab, "$d1$c1$d2$c2$d3$c3");
$ann=strlen($ab2);
      $sp=substr($ab, 0, -$ann);
$ne=highlight($sp);
$text1 = nl2br($ne);

  $words = explode(' ', $text1);
 echo "<p style='text-align: justify;'>";

  $counter = 0;
  foreach ($words as $word) {
    echo $word . ' ';
    if (++$counter >= 10) {
      if (substr($word, -1) === '.') {
        echo "</p><p style='text-align: justify;'>"; // End the paragraph and start a new one.
        $counter = 0;
      }
    }
  }
  echo '</p>';
  } 
}


else{

      $sp=substr($ab, 0, -5000);
   $ne=highlight($sp);
$text1 = nl2br($ne);

  $words = explode(' ', $text1);
 echo "<p style='text-align: justify;'>";

  $counter = 0;
  foreach ($words as $word) {
    echo $word . ' ';
    if (++$counter >= 10) {
      if (substr($word, -1) === '.') {
        echo "</p><p style='text-align: justify;'>"; // End the paragraph and start a new one.
        $counter = 0;
      }
    }
  }
  echo '</p>';

}



}







function newAll($ab)
{
  
   global $connection;


 $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Supporting)';  # Word 1
  $b6='(\\s+)';  $b7='(Information)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Supporting)';$f8='(\\s+)';  $f9='(Information)';
if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $ab, $matches  ))
  {
   
///// 1. Supporting Information////
      $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
       $c3=$matches[6][0];     

if ($ab2=strstr($ab, "$d1$c1$d2$c2$d3$c3")){
$ab2=strstr($ab, "$d1$c1$d2$c2$d3$c3");
 $ann=strlen($ab2);
      $sp=substr($ab, 0, -$ann);
$ne=highlight($sp);

$text1 = nl2br($ne);

  $words = explode(' ', $text1);
 echo "<p style='text-align: justify;'>";

  $counter = 0;
  foreach ($words as $word) {
    echo $word . ' ';
    if (++$counter >= 10) {
      if (substr($word, -1) === '.') {
        echo "</p><p style='text-align: justify;'>"; // End the paragraph and start a new one.
        $counter = 0;
      }
    }
  }
  echo '</p>';



}



}  elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $ab, $matches)) {
    

/////////////1 Supporting Information///////////
     $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
      

if ($ab2=strstr($ab, "$d1$c1$d2$c2$d3")){
$ab2=strstr($ab, "$d1$c1$d2$c2$d3");
$ann=strlen($ab2);
$sp=substr($ab, 0, -$ann);
$ne=highlight($sp);
$text1 = nl2br($ne);

  $words = explode(' ', $text1);
 echo "<p style='text-align: justify;'>";

  $counter = 0;
  foreach ($words as $word) {
    echo $word . ' ';
    if (++$counter >= 10) {
      if (substr($word, -1) === '.') {
        echo "</p><p style='text-align: justify;'>"; // End the paragraph and start a new one.
        $counter = 0;
      }
    }
  }
  echo '</p>';
}


  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {


////////////////// 1 The Supporting Information//////////
      $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
       $c3=$matches[6][0];
       $d4=$matches[7][0];     

if ($ab2=strstr($ab, "$d1$c1$d2$c2$d3$c3$d4")){
$ab2=strstr($ab, "$d1$c1$d2$c2$d3$c3$d4");
$ann=strlen($ab2);
      $sp=substr($ab, 0, -$ann);
$ne=highlight($sp);
$text1 = nl2br($ne);

  $words = explode(' ', $text1);
 echo "<p style='text-align: justify;'>";

  $counter = 0;
  foreach ($words as $word) {
    echo $word . ' ';
    if (++$counter >= 10) {
      if (substr($word, -1) === '.') {
        echo "</p><p style='text-align: justify;'>"; // End the paragraph and start a new one.
        $counter = 0;
      }
    }
  }
  echo '</p>';
}

  }
   elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)){
    
    $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
       $c3=$matches[6][0];
       $d4=$matches[7][0];     
      $c4=$matches[8][0];


if ($ab2=strstr($ab, "$d1$c1$d2$c2$d3$c3$d4$c4")){
$ab2=strstr($ab, "$d1$c1$d2$c2$d3$c3$d4$c4");
$ann=strlen($ab2);
$sp=substr($ab, 0, -$ann);
$ne=highlight($sp);
$text1 = nl2br($ne);

  $words = explode(' ', $text1);
 echo "<p style='text-align: justify;'>";

  $counter = 0;
  foreach ($words as $word) {
    echo $word . ' ';
    if (++$counter >= 10) {
      if (substr($word, -1) === '.') {
        echo "</p><p style='text-align: justify;'>"; // End the paragraph and start a new one.
        $counter = 0;
      }
    }
  }
  echo '</p>';

  }

  }



   $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Other)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Other)';$f8='(\\s+)';  $f9='(Requirements)';
if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $ab, $matches  ))
  {
    
  $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
       $c3=$matches[6][0];

if ($ab2=strstr($ab, "$d1$c1$d2$c2$d3$c3")){
$ab2=strstr($ab, "$d1$c1$d2$c2$d3$c3");
$ann=strlen($ab2);
      $sp=substr($ab, 0, -$ann);
$ne=highlight($sp);
$text1 = nl2br($ne);

  $words = explode(' ', $text1);
 echo "<p style='text-align: justify;'>";

  $counter = 0;
  foreach ($words as $word) {
    echo $word . ' ';
    if (++$counter >= 10) {
      if (substr($word, -1) === '.') {
        echo "</p><p style='text-align: justify;'>"; // End the paragraph and start a new one.
        $counter = 0;
      }
    }
  }
  echo '</p>';

  }   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $ab, $matches))  {
  
  $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
      

if ($ab2=strstr($ab, "$d1$c1$d2$c2$d3")){
$ab2=strstr($ab, "$d1$c1$d2$c2$d3");
$ann=strlen($ab2);
      $sp=substr($ab, 0, -$ann);
$ne=highlight($sp);
$text1 = nl2br($ne);

  $words = explode(' ', $text1);
 echo "<p style='text-align: justify;'>";

  $counter = 0;
  foreach ($words as $word) {
    echo $word . ' ';
    if (++$counter >= 10) {
      if (substr($word, -1) === '.') {
        echo "</p><p style='text-align: justify;'>"; // End the paragraph and start a new one.
        $counter = 0;
      }
    }
  }
  echo '</p>';

}
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {
     $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
      $d4=$matches[7][0];     
   



if ($ab2=strstr($ab, "$d1$c1$d2$c2$d3$c3$d4")){
$ab2=strstr($ab, "$d1$c1$d2$c2$d3$c3$d4");
$ann=strlen($ab2);
    $sp=substr($ab, 0, -$ann);
$ne=highlight($sp);
$text1 = nl2br($ne);

  $words = explode(' ', $text1);
 echo "<p style='text-align: justify;'>";

  $counter = 0;
  foreach ($words as $word) {
    echo $word . ' ';
    if (++$counter >= 10) {
      if (substr($word, -1) === '.') {
        echo "</p><p style='text-align: justify;'>"; // End the paragraph and start a new one.
        $counter = 0;
      }
    }
  }
  echo '</p>';
}
  }
elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {
     $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
      $d4=$matches[7][0];     
      $c4=$matches[8][0];



if ($ab2=strstr($ab, "$d1$c1$d2$c2$d3$c3$d4$c4")){
$ab2=strstr($ab, "$d1$c1$d2$c2$d3$c3$d4$c4");
$ann=strlen($ab2);
    $sp=substr($ab, 0, -$ann);
$ne=highlight($sp);
$text1 = nl2br($ne);

  $words = explode(' ', $text1);
 echo "<p style='text-align: justify;'>";

  $counter = 0;
  foreach ($words as $word) {
    echo $word . ' ';
    if (++$counter >= 10) {
      if (substr($word, -1) === '.') {
        echo "</p><p style='text-align: justify;'>"; // End the paragraph and start a new one.
        $counter = 0;
      }
    }
  }
  echo '</p>';


  }
}



   $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Appendix)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Appendix)';$f8='(\\s+)';  $f9='(Requirements)';


   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5."/is", $ab, $matches  ))
  {
 $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     

if ($ab2=strstr($ab, "$d1$c1$d2$c2")){
$ab2=strstr($ab, "$d1$c1$d2$c2");
$ann=strlen($ab2);
      $sp=substr($ab, 0, -$ann);
$ne=highlight($sp);


  $words = explode(' ', $ne);
 echo "<p style='text-align: justify;'>";

  $counter = 0;
  foreach ($words as $word) {
    echo $word . ' ';
    if (++$counter >= 10) {
      if (substr($word, -1) === '.') {
        echo "</p><p style='text-align: justify;'>"; // End the paragraph and start a new one.
        $counter = 0;
      }
    }
  }
  echo '</p>';
}

  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7."/is", $ab, $matches)) {
      $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];

if ($ab2=strstr($ab, "$d1$c1$d2")){
$ab2=strstr($ab, "$d1$c1$d2");
$ann=strlen($ab2);
      $sp=substr($ab, 0, -$ann);
$ne=highlight($sp);
$text1 = nl2br($ne);

  $words = explode(' ', $text1);
 echo "<p style='text-align: justify;'>";

  $counter = 0;
  foreach ($words as $word) {
    echo $word . ' ';
    if (++$counter >= 10) {
      if (substr($word, -1) === '.') {
        echo "</p><p style='text-align: justify;'>"; // End the paragraph and start a new one.
        $counter = 0;
      }
    }
  }
  echo '</p>';
}
    
  }elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7."/is", $ab, $matches)) {
   $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
       $c3=$matches[6][0];

if ($ab2=strstr($ab, "$d1$c1$d2$c2$d3$c3")){
$ab2=strstr($ab, "$d1$c1$d2$c2$d3$c3");
$ann=strlen($ab2);
      $sp=substr($ab, 0, -$ann);
$ne=highlight($sp);
$text1 = nl2br($ne);

  $words = explode(' ', $text1);
 echo "<p style='text-align: justify;'>";

  $counter = 0;
  foreach ($words as $word) {
    echo $word . ' ';
    if (++$counter >= 10) {
      if (substr($word, -1) === '.') {
        echo "</p><p style='text-align: justify;'>"; // End the paragraph and start a new one.
        $counter = 0;
      }
    }
  }
  echo '</p>';


  }
}

////////////////// 1 The Appendix////////////

  elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7."/is", $ab, $matches)) {

$d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
      

if ($ab2=strstr($ab, "$d1$c1$d2$c2$d3")){
$ab2=strstr($ab, "$d1$c1$d2$c2$d3");
$ann=strlen($ab2);
      $sp=substr($ab, 0, -$ann);
$ne=highlight($sp);
$text1 = nl2br($ne);

  $words = explode(' ', $text1);
 echo "<p style='text-align: justify;'>";

  $counter = 0;
  foreach ($words as $word) {
    echo $word . ' ';
    if (++$counter >= 10) {
      if (substr($word, -1) === '.') {
        echo "</p><p style='text-align: justify;'>"; // End the paragraph and start a new one.
        $counter = 0;
      }
    }
  }
  echo '</p>';

}
}




   

   $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(References)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(References)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5."/is", $ab, $matches  ))
  { 
     $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      

if ($ab2=strstr($ab, "$d1$c1$d2$c2")){
$ab2=strstr($ab, "$d1$c1$d2$c2");
$ann=strlen($ab2);
      $sp=substr($ab, 0, -$ann);
$ne=highlight($sp);
$text1 = nl2br($ne);

  $words = explode(' ', $text1);
 echo "<p style='text-align: justify;'>";

  $counter = 0;
  foreach ($words as $word) {
    echo $word . ' ';
    if (++$counter >= 10) {
      if (substr($word, -1) === '.') {
        echo "</p><p style='text-align: justify;'>"; // End the paragraph and start a new one.
        $counter = 0;
      }
    }
  }
  echo '</p>';

}

  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7."/is", $ab, $matches)) {
    $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
         

if ($ab2=strstr($ab, "$d1$c1$d2")){
$ab2=strstr($ab, "$d1$c1$d2");
$ann=strlen($ab2);
      $sp=substr($ab, 0, -$ann);
$ne=highlight($sp);
$text1 = nl2br($ne);

  $words = explode(' ', $text1);
 echo "<p style='text-align: justify;'>";

  $counter = 0;
  foreach ($words as $word) {
    echo $word . ' ';
    if (++$counter >= 10) {
      if (substr($word, -1) === '.') {
        echo "</p><p style='text-align: justify;'>"; // End the paragraph and start a new one.
        $counter = 0;
      }
    }
  }
  echo '</p>';

   }  
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7."/is", $ab, $matches)) {
     
       $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
     
 
if ($ab2=strstr($ab, "$d1$c1$d2$c2$d3")){
$ab2=strstr($ab, "$d1$c1$d2$c2$d3");
$ann=strlen($ab2);
      $sp=substr($ab, 0, -$ann);
$ne=highlight($sp);
$text1 = nl2br($ne);

  $words = explode(' ', $text1);
 echo "<p style='text-align: justify;'>";

  $counter = 0;
  foreach ($words as $word) {
    echo $word . ' ';
    if (++$counter >= 10) {
      if (substr($word, -1) === '.') {
        echo "</p><p style='text-align: justify;'>"; // End the paragraph and start a new one.
        $counter = 0;
      }
    }
  }
  echo '</p>';
}
  }
elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7."/is", $ab, $matches)) {
    
       $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
      $c3=$matches[6][0];
          

if ($ab2=strstr($ab, "$d1$c1$d2$c2$d3$c3")){
$ab2=strstr($ab, "$d1$c1$d2$c2$d3$c3");
$ann=strlen($ab2);
      $sp=substr($ab, 0, -$ann);
$ne=highlight($sp);
$text1 = nl2br($ne);

  $words = explode(' ', $text1);
 echo "<p style='text-align: justify;'>";

  $counter = 0;
  foreach ($words as $word) {
    echo $word . ' ';
    if (++$counter >= 10) {
      if (substr($word, -1) === '.') {
        echo "</p><p style='text-align: justify;'>"; // End the paragraph and start a new one.
        $counter = 0;
      }
    }
  }
  echo '</p>';
  }

}


   $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Glossary)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Glossary)';


   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5."/is", $ab, $matches  ))
  {
     $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      

if ($ab2=strstr($ab, "$d1$c1$d2$c2")){
$ab2=strstr($ab, "$d1$c1$d2$c2");
$ann=strlen($ab2);
      $sp=substr($ab, 0, -$ann);
$ne=highlight($sp);
$text1 = nl2br($ne);

  $words = explode(' ', $text1);
 echo "<p style='text-align: justify;'>";

  $counter = 0;
  foreach ($words as $word) {
    echo $word . ' ';
    if (++$counter >= 10) {
      if (substr($word, -1) === '.') {
        echo "</p><p style='text-align: justify;'>"; // End the paragraph and start a new one.
        $counter = 0;
      }
    }
  }
  echo '</p>';

}
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7."/is", $ab, $matches)) {
   $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
     

if ($ab2=strstr($ab, "$d1$c1$d2")){
$ab2=strstr($ab, "$d1$c1$d2");
$ann=strlen($ab2);
      $sp=substr($ab, 0, -$ann);
$ne=highlight($sp);
$text1 = nl2br($ne);

  $words = explode(' ', $text1);
 echo "<p style='text-align: justify;'>";

  $counter = 0;
  foreach ($words as $word) {
    echo $word . ' ';
    if (++$counter >= 10) {
      if (substr($word, -1) === '.') {
        echo "</p><p style='text-align: justify;'>"; // End the paragraph and start a new one.
        $counter = 0;
      }
    }
  }
  echo '</p>';
}
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7."/is", $ab, $matches)) {

     $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
    
 
if ($ab2=strstr($ab, "$d1$c1$d2$c2$d3")){
$ab2=strstr($ab, "$d1$c1$d2$c2$d3");
$ann=strlen($ab2);
      $sp=substr($ab, 0, -$ann);
$ne=highlight($sp);
$text1 = nl2br($ne);

  $words = explode(' ', $text1);
 echo "<p style='text-align: justify;'>";

  $counter = 0;
  foreach ($words as $word) {
    echo $word . ' ';
    if (++$counter >= 10) {
      if (substr($word, -1) === '.') {
        echo "</p><p style='text-align: justify;'>"; // End the paragraph and start a new one.
        $counter = 0;
      }
    }
  }
  echo '</p>';
  } 
}
elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7."/is", $ab, $matches)) {
   $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
      $c3=$matches[6][0];
          

if ($ab2=strstr($ab, "$d1$c1$d2$c2$d3$c3")){
$ab2=strstr($ab, "$d1$c1$d2$c2$d3$c3");
$ann=strlen($ab2);
      $sp=substr($ab, 0, -$ann);
$ne=highlight($sp);
$text1 = nl2br($ne);

  $words = explode(' ', $text1);
 echo "<p style='text-align: justify;'>";

  $counter = 0;
  foreach ($words as $word) {
    echo $word . ' ';
    if (++$counter >= 10) {
      if (substr($word, -1) === '.') {
        echo "</p><p style='text-align: justify;'>"; // End the paragraph and start a new one.
        $counter = 0;
      }
    }
  }
  echo '</p>';
  } 
}


else{

     $string = join("\n", array_slice(explode("\n", $ab), 0, -50));

   $ne=highlight($string);

  $words = explode(' ', $ne);
 echo "<p style='text-align: justify;'>";

  $counter = 0;
  foreach ($words as $word) {
    echo $word . ' ';
    if (++$counter >= 10) {
      if (substr($word, -1) === '.') {
        echo "</p><p style='text-align: justify;'>"; // End the paragraph and start a new one.
        $counter = 0;
      }
    }
  }
  echo '</p>';

}


}






















function pdf($text1)
{

  

$f1=0; $f2=0; $f3=0;$f4=0;
$nf1=0;$nf2=0;$nf3=0;
$nf4=0;$nf5=0;$nf6=0;
$nf7=0;$nf8=0;$nf9=0;$nf10=0;$nf11=0;$nf12=0;
$p1=0; $p2=0;$p3=0; $p4=0;
$q1=0; $q2=0; $q3=0;$q4=0;


$fu1=0;
$fu2=0;$fu3=0;$fu4=0;
$a1=0;$a2=0;$a3=0;$a4=0;$a5=0;$a6=0;$a7=0;$a8=0;$a9=0;$a10=0;$a11=0;$a12=0;$a13=0;$a14=0;$a15=0;$a16=0;

$b1='(\d)'; $b2='(\\.)'; $a='(-)';
   $b4='(\\s+)';   $b5='(Specific)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Specific)';$f8='(\\s+)';  $f9='(Requirements)';

 if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $text1, $matches  ))
  {

 
      $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
      $c3=$matches[6][0];
     // print "<br><br>$d1 $c1 $d2 $c2 $d3 $c3  actual ye ha heading\n";

if (strstr($text1, "$d1$c1$d2$c2$d3$c3"))
{
$ab= strstr($text1, "$d1$c1$d2$c2$d3$c3");

$az=newAll($ab);
echo "$az";

  
 $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Functional)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Functional)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $ab, $matches  ))
  {

  
    $fu1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $ab, $matches)) {
    
     $fu2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {
 
  $fu3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {

  $fu4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7.$b10.$f9."/is", $ab, $matches ))
  {
   $nf1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; 
 $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
   $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';


   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$a.$b7.$b9.$b11."/is", $ab, $matches ))
  {
   $nf5++;

  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf6++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf7++;
  
  }elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf8++;
  }
 
    
   $b1='(\d)'; $b2='(\\.)';$b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
    $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';
   
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
$nf9++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf10++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf11++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf12++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
    $p1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p4++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
   $q1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
    $q2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q4++;
  }



}


}

 elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $text1, $matches)) {

  $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];



if ($ab=strstr($text1, "$d1$c1$d2$c2$d3")){
$ab=strstr($text1, "$d1$c1$d2$c2$d3");

 
$az=newAll($ab);
echo "$az";




 $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Functional)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Functional)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $ab, $matches  ))
  {

  
    $fu1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $ab, $matches)) {
    
     $fu2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {
 
  $fu3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {

  $fu4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7.$b10.$f9."/is", $ab, $matches ))
  {
   $nf1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; 
 $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
   $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';


   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$a.$b7.$b9.$b11."/is", $ab, $matches ))
  {
   $nf5++;

  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf6++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf7++;
  
  }elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf8++;
  }
 

   $b1='(\d)'; $b2='(\\.)';$b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
    $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';
   
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
$nf9++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf10++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf11++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf12++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
    $p1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p4++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
   $q1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
    $q2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q4++;
  }

}
}
 elseif ($c=preg_match_all ("/".$b1.$b2.$b4.$b8.$b6.$b5.$b6.$b7."/is", $text1, $matches  ))
  {
  
      $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
      $c3=$matches[6][0];
       $d4=$matches[7][0];
      $c4=$matches[8][0];
     // print "<br><br>$d1 $c1 $d2 $c2 $d3 $c3  actual ye ha heading\n";


if (strstr($text1, "$d1$c1$d2$c2$d3$c3$d4$c4"))
{
$ab= strstr($text1, "$d1$c1$d2$c2$d3$c3$d4$c4");

$az=newAll($ab);
echo "$az";





 $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Functional)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Functional)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $ab, $matches  ))
  {

  
    $fu1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $ab, $matches)) {
    
     $fu2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {
 
  $fu3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {

  $fu4++;
  }


 $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7.$b10.$f9."/is", $ab, $matches ))
  {
   $nf1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; 
 $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
   $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';


   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$a.$b7.$b9.$b11."/is", $ab, $matches ))
  {
   $nf5++;

  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf6++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf7++;
  
  }elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf8++;
  }
 

   $b1='(\d)'; $b2='(\\.)';$b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
    $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';
   
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
$nf9++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf10++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf11++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf12++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
    $p1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p4++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
   $q1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
    $q2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q4++;
  }


}
}
 elseif ($c=preg_match_all ("/".$b1.$b4.$b8.$b6.$b5.$b6.$b7."/is", $text1, $matches  )) {


  $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
       $c3=$matches[6][0];     
      $d4=$matches[7][0];


if ($ab=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4")){
$ab=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4");
$az=newAll($ab);
echo "$az";




 $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Functional)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Functional)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $ab, $matches  ))
  {

  
    $fu1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $ab, $matches)) {
    
     $fu2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {
 
  $fu3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {

  $fu4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7.$b10.$f9."/is", $ab, $matches ))
  {
   $nf1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; 
 $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
   $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';


   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$a.$b7.$b9.$b11."/is", $ab, $matches ))
  {
   $nf5++;

  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf6++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf7++;
  
  }elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf8++;
  }
 

   $b1='(\d)'; $b2='(\\.)';$b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
    $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';
   
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
$nf9++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf10++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf11++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf12++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
    $p1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p4++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
   $q1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
    $q2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q4++;
  }

}

}



/////////////////////////////// First typeeeeeeeeeee endddddddddddddddddddddddd////////////////////////////////


   $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Technical)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Technical)';$f8='(\\s+)';  $f9='(Requirements)';

  if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $text1, $matches  ))
  {
 $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
 $c3=$matches[6][0];



if ($ab=strstr($text1, "$d1$c1$d2$c2$d3$c3")){
$ab=strstr($text1, "$d1$c1$d2$c2$d3$c3");




$az=newAll($ab);
echo "$az";



 $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Functional)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Functional)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $ab, $matches  ))
  {

  
    $fu1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $ab, $matches)) {
    
     $fu2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {
 
  $fu3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {

  $fu4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7.$b10.$f9."/is", $ab, $matches ))
  {
   $nf1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; 
 $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
   $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';


   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$a.$b7.$b9.$b11."/is", $ab, $matches ))
  {
   $nf5++;

  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf6++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf7++;
  
  }elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf8++;
  }
 

   $b1='(\d)'; $b2='(\\.)';$b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
    $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';
   
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
$nf9++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf10++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf11++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf12++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
    $p1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p4++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
   $q1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
    $q2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q4++;
  }

}

}


 elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $text1, $matches)) {

$d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];



if ($ab=strstr($text1, "$d1$c1$d2$c2$d3")){
$ab=strstr($text1, "$d1$c1$d2$c2$d3");


$az=newAll($ab);
echo "$az";




 $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Functional)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Functional)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $ab, $matches  ))
  {

  
    $fu1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $ab, $matches)) {
    
     $fu2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {
 
  $fu3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {

  $fu4++;
  }

    $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7.$b10.$f9."/is", $ab, $matches ))
  {
   $nf1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; 
 $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
   $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';


   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$a.$b7.$b9.$b11."/is", $ab, $matches ))
  {
   $nf5++;

  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf6++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf7++;
  
  }elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf8++;
  }
 

   $b1='(\d)'; $b2='(\\.)';$b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
    $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';
   
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
$nf9++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf10++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf11++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf12++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
    $p1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p4++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
   $q1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
    $q2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q4++;
  }

}
}
   elseif ($c=preg_match_all ("/".$b1.$b2.$b4.$b8.$b9.$b5.$b6.$b7."/is", $text1, $matches  ))
  {
 $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
 $c3=$matches[6][0];
$d4=$matches[7][0];
 $c4=$matches[8][0];



if ($ab=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4$c4")){
$ab=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4$c4");

$az=newAll($ab);
echo "$az";



 $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Functional)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Functional)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $ab, $matches  ))
  {

  
    $fu1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $ab, $matches)) {
    
     $fu2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {
 
  $fu3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {

  $fu4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7.$b10.$f9."/is", $ab, $matches ))
  {
   $nf1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; 
 $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
   $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';


   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$a.$b7.$b9.$b11."/is", $ab, $matches ))
  {
   $nf5++;

  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf6++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf7++;
  
  }elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf8++;
  }
 

   $b1='(\d)'; $b2='(\\.)';$b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
    $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';
   
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
$nf9++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf10++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf11++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf12++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
    $p1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p4++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
   $q1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
    $q2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q4++;
  }

}
}


 elseif ($c=preg_match_all ("/".$b1.$b4.$b8.$b6.$b5.$b6.$b7."/is", $text1, $matches  )) {


  $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
       $c3=$matches[6][0];     
      $d4=$matches[7][0];



if ($ab=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4")){
$ab=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4");
$az=newAll($ab);
echo "$az";


 $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Functional)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Functional)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $ab, $matches  ))
  {

  
    $fu1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $ab, $matches)) {
    
     $fu2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {
 
  $fu3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {

  $fu4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7.$b10.$f9."/is", $ab, $matches ))
  {
   $nf1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; 
 $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
   $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';


   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$a.$b7.$b9.$b11."/is", $ab, $matches ))
  {
   $nf5++;

  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf6++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf7++;
  
  }elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf8++;
  }
 

   $b1='(\d)'; $b2='(\\.)';$b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
    $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';
   
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
$nf9++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf10++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf11++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf12++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
    $p1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p4++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
   $q1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
    $q2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q4++;
  }


}

}




  


   $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(System)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(System)';$f8='(\\s+)';  $f9='(Requirements)';

  
  if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $text1, $matches  ))
  {
$d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
        $c3=$matches[6][0];


if ($ab=strstr($text1, "$d1$c1$d2$c2$d3$c3")){
$ab=strstr($text1, "$d1$c1$d2$c2$d3$c3");


$az=newAll($ab);
echo "$az";



 $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Functional)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Functional)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $ab, $matches  ))
  {

  
    $fu1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $ab, $matches)) {
    
     $fu2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {
 
  $fu3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {

  $fu4++;
  }

 $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7.$b10.$f9."/is", $ab, $matches ))
  {
   $nf1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; 
 $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
   $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';


   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$a.$b7.$b9.$b11."/is", $ab, $matches ))
  {
   $nf5++;

  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf6++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf7++;
  
  }elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf8++;
  }
 

   $b1='(\d)'; $b2='(\\.)';$b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
    $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';
   
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
$nf9++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf10++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf11++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf12++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
    $p1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p4++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
   $q1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
    $q2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q4++;
  }

}


}

 elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $text1, $matches)) {
$d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];


if ($ab=strstr($text1, "$d1$c1$d2$c2$d3")){
$ab=strstr($text1, "$d1$c1$d2$c2$d3");


$az=newAll($ab);
echo "$az";



 $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Functional)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Functional)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $ab, $matches  ))
  {

  
    $fu1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $ab, $matches)) {
    
     $fu2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {
 
  $fu3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {

  $fu4++;
  }

    $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7.$b10.$f9."/is", $ab, $matches ))
  {
   $nf1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; 
 $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
   $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';


   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$a.$b7.$b9.$b11."/is", $ab, $matches ))
  {
   $nf5++;

  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf6++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf7++;
  
  }elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf8++;
  }
 

   $b1='(\d)'; $b2='(\\.)';$b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
    $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';
   
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
$nf9++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf10++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf11++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf12++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
    $p1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p4++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
   $q1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
    $q2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q4++;
  }

} 
}
elseif ($c=preg_match_all ("/".$b1.$b2.$b4.$b8.$b9.$b5.$b6.$b7."/is", $text1, $matches  ))
  {
 $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
 $c3=$matches[6][0];
$d4=$matches[7][0];
 $c4=$matches[8][0];



if ($ab=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4$c4")){
$ab=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4$c4");
$az=newAll($ab);
echo "$az";


 $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Functional)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Functional)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $ab, $matches  ))
  {

  
    $fu1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $ab, $matches)) {
    
     $fu2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {
 
  $fu3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {

  $fu4++;
  }


 $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7.$b10.$f9."/is", $ab, $matches ))
  {
   $nf1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; 
 $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
   $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';


   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$a.$b7.$b9.$b11."/is", $ab, $matches ))
  {
   $nf5++;

  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf6++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf7++;
  
  }elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf8++;
  }
 

   $b1='(\d)'; $b2='(\\.)';$b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
    $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';
   
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
$nf9++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf10++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf11++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf12++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
    $p1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p4++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
   $q1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
    $q2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q4++;
  }


}
}


 elseif ($c=preg_match_all ("/".$b1.$b4.$b8.$b6.$b5.$b6.$b7."/is", $text1, $matches  )) {


  $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
       $c3=$matches[6][0];     
      $d4=$matches[7][0];


if ($ab=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4")){
$ab=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4");
$az=newAll($ab);
echo "$az";




 $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Functional)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Functional)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $ab, $matches  ))
  {

  
    $fu1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $ab, $matches)) {
    
     $fu2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {
 
  $fu3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {

  $fu4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7.$b10.$f9."/is", $ab, $matches ))
  {
   $nf1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; 
 $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
   $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';


   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$a.$b7.$b9.$b11."/is", $ab, $matches ))
  {
   $nf5++;

  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf6++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf7++;
  
  }elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf8++;
  }
 

   $b1='(\d)'; $b2='(\\.)';$b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
    $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';
   
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
$nf9++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf10++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf11++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf12++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
    $p1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p4++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
   $q1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
    $q2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q4++;
  }

}

}

  

   $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(System)';  # Word 1
  $b6='(\\s+)';  $b7='(Features)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(System)';$f8='(\\s+)';  $f9='(Features)';

if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $text1, $matches  ))
  {
 $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
 $c3=$matches[6][0];


if ($ab=strstr($text1, "$d1$c1$d2$c2$d3$c3")){
$ab=strstr($text1, "$d1$c1$d2$c2$d3$c3");

$az=newAll($ab);
echo "$az";


 $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Functional)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Functional)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $ab, $matches  ))
  {

  
    $fu1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $ab, $matches)) {
    
     $fu2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {
 
  $fu3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {

  $fu4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7.$b10.$f9."/is", $ab, $matches ))
  {
   $nf1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; 
 $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
   $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';


   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$a.$b7.$b9.$b11."/is", $ab, $matches ))
  {
   $nf5++;

  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf6++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf7++;
  
  }elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf8++;
  }
 

   $b1='(\d)'; $b2='(\\.)';$b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
    $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';
   
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
$nf9++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf10++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf11++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf12++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
    $p1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p4++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
   $q1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
    $q2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q4++;
  }

}


}
elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $text1, $matches)) {
 $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];



if ($ab=strstr($text1, "$d1$c1$d2$c2$d3")){
$ab=strstr($text1, "$d1$c1$d2$c2$d3");


$az=newAll($ab);
echo "$az";



 $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Functional)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Functional)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $ab, $matches  ))
  {

  
    $fu1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $ab, $matches)) {
    
     $fu2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {
 
  $fu3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {

  $fu4++;
  }



  $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7.$b10.$f9."/is", $ab, $matches ))
  {
   $nf1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; 
 $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
   $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';


   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$a.$b7.$b9.$b11."/is", $ab, $matches ))
  {
   $nf5++;

  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf6++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf7++;
  
  }elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf8++;
  }
 

   $b1='(\d)'; $b2='(\\.)';$b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
    $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';
   
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
$nf9++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf10++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf11++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf12++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
    $p1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p4++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
   $q1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
    $q2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q4++;
  }

}

 }
elseif ($c=preg_match_all ("/".$b1.$b2.$b4.$b8.$b9.$b5.$b6.$b7."/is", $text1, $matches  ))
  {
 $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
 $c3=$matches[6][0];
$d4=$matches[7][0];
 $c4=$matches[8][0];


if ($ab=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4$c4")){
$ab=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4$c4");
$az=newAll($ab);
echo "$az";


 $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Functional)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Functional)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $ab, $matches  ))
  {

  
    $fu1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $ab, $matches)) {
    
     $fu2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {
 
  $fu3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {

  $fu4++;
  }


  $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7.$b10.$f9."/is", $ab, $matches ))
  {
   $nf1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; 
 $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
   $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';


   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$a.$b7.$b9.$b11."/is", $ab, $matches ))
  {
   $nf5++;

  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf6++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf7++;
  
  }elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf8++;
  }
 

   $b1='(\d)'; $b2='(\\.)';$b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
    $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';
   
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
$nf9++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf10++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf11++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf12++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
    $p1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p4++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
   $q1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
    $q2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q4++;
  }

}
}


 elseif ($c=preg_match_all ("/".$b1.$b4.$b8.$b6.$b5.$b6.$b7."/is", $text1, $matches  )) {


  $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
       $c3=$matches[6][0];     
      $d4=$matches[7][0];


if ($ab=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4")){
$ab=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4");
$az=newAll($ab);
echo "$az";


 $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Functional)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Functional)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $ab, $matches  ))
  {

  
    $fu1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $ab, $matches)) {
    
     $fu2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {
 
  $fu3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {

  $fu4++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7.$b10.$f9."/is", $ab, $matches ))
  {
   $nf1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; 
 $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
   $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';


   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$a.$b7.$b9.$b11."/is", $ab, $matches ))
  {
   $nf5++;

  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf6++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf7++;
  
  }elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf8++;
  }
 

   $b1='(\d)'; $b2='(\\.)';$b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
    $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';
   
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
$nf9++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf10++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf11++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf12++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
    $p1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p4++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
   $q1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
    $q2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q4++;
  }

}

}
  


   $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Requirements)';  # Word 1
  $b6='(\\s+)';  $b7='(Specification)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Requirements)';$f8='(\\s+)';  $f9='(Specification)';


if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $text1, $matches  ))
  {
$d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
 $c3=$matches[6][0];

if ($ab=strstr($text1, "$d1$c1$d2$c2$d3$c3")){
$ab=strstr($text1, "$d1$c1$d2$c2$d3$c3");


$az=newAll($ab);
echo "$az";



 $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Functional)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Functional)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $ab, $matches  ))
  {

  
    $fu1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $ab, $matches)) {
    
     $fu2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {
 
  $fu3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {

  $fu4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7.$b10.$f9."/is", $ab, $matches ))
  {
   $nf1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; 
 $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
   $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';


   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$a.$b7.$b9.$b11."/is", $ab, $matches ))
  {
   $nf5++;

  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf6++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf7++;
  
  }elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf8++;
  }
 

   $b1='(\d)'; $b2='(\\.)';$b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
    $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';
   
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
$nf9++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf10++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf11++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf12++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
    $p1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p4++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
   $q1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
    $q2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q4++;
  }

}


}
 elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $text1, $matches)) {
$d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];


if ($ab=strstr($text1, "$d1$c1$d2$c2$d3")){
$ab=strstr($text1, "$d1$c1$d2$c2$d3");


$az=newAll($ab);
echo "$az";



 $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Functional)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Functional)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $ab, $matches  ))
  {

  
    $fu1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $ab, $matches)) {
    
     $fu2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {
 
  $fu3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {

  $fu4++;
  }


 $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7.$b10.$f9."/is", $ab, $matches ))
  {
   $nf1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; 
 $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
   $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';


   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$a.$b7.$b9.$b11."/is", $ab, $matches ))
  {
   $nf5++;

  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf6++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf7++;
  
  }elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf8++;
  }
 

   $b1='(\d)'; $b2='(\\.)';$b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
    $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';
   
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
$nf9++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf10++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf11++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf12++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
    $p1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p4++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
   $q1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
    $q2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q4++;
  }

    }

 }
 elseif ($c=preg_match_all ("/".$b1.$b2.$b4.$b8.$b9.$b5.$b6.$b7."/is", $text1, $matches  ))
  {
 $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
 $c3=$matches[6][0];
$d4=$matches[7][0];
 $c4=$matches[8][0];


if ($ab=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4$c4")){
$ab=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4$c4");
$az=newAll($ab);
echo "$az";




 $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Functional)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Functional)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $ab, $matches  ))
  {

  
    $fu1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $ab, $matches)) {
    
     $fu2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {
 
  $fu3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {

  $fu4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7.$b10.$f9."/is", $ab, $matches ))
  {
   $nf1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; 
 $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
   $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';


   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$a.$b7.$b9.$b11."/is", $ab, $matches ))
  {
   $nf5++;

  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf6++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf7++;
  
  }elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf8++;
  }
 

   $b1='(\d)'; $b2='(\\.)';$b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
    $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';
   
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
$nf9++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf10++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf11++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf12++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
    $p1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p4++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
   $q1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
    $q2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q4++;
  }

}
}


 elseif ($c=preg_match_all ("/".$b1.$b4.$b8.$b6.$b5.$b6.$b7."/is", $text1, $matches  )) {


  $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
       $c3=$matches[6][0];     
      $d4=$matches[7][0];


if ($ab=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4")){
$ab=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4");
$az=newAll($ab);
echo "$az";



 $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Functional)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Functional)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $ab, $matches  ))
  {

  
    $fu1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $ab, $matches)) {
    
     $fu2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {
 
  $fu3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {

  $fu4++;
  }

 $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7.$b10.$f9."/is", $ab, $matches ))
  {
   $nf1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; 
 $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
   $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';


   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$a.$b7.$b9.$b11."/is", $ab, $matches ))
  {
   $nf5++;

  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf6++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf7++;
  
  }elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf8++;
  }
 

   $b1='(\d)'; $b2='(\\.)';$b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
    $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';
   
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
$nf9++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf10++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf11++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf12++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
    $p1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p4++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
   $q1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
    $q2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q4++;
  }

}

}
  
$j1=0;$j2=0;$j3=0;$j4=0;$j5=0;$j6=0;$j7=0;$j8=0;$j9=0;$j10=0;$j11=0;$j12=0;$j13=0;$j14=0;$j15=0;$j16=0;$j17=0;$j18=0;$j19=0; $j20=0;
$j21=0;$j22=0;$j23=0;$j24=0;$j25=0;$j26=0;$j27=0;$j28=0;$j29=0;$j30=0;$j31=0;$j32=0;$j33=0;$j34=0;$j35=0;$j36=0;$j37=0;$j38=0;$j39=0; $j40=0;

$j41=0;$j42=0;$j43=0;$j44=0;$j45=0;$j46=0;$j47=0;$j48=0;$j49=0;$j50=0;$j51=0;$j52=0;$j53=0;$j54=0;$j55=0;$j56=0;$j57=0;$j58=0;$j59=0; $j60=0;
$j61=0;$j62=0;$j63=0;$j64=0;$j65=0;$j66=0;$j67=0;$j68=0;$j69=0;$j70=0;$j71=0;$j72=0;$j73=0;$j74=0;$j75=0;$j76=0;$j77=0;$j78=0;$j79=0; $j80=0;

$j81=0;$j82=0;$j83=0;$j84=0;$j85=0;$j86=0;$j87=0;$j88=0;$j89=0;$j90=0;$j91=0;$j92=0;$j93=0;$j94=0;$j95=0;$j96=0;$j97=0;$j98=0;$j99=0;

 $b1='(\d)'; $b2='(\\.)';

   $b4='(\\s+)';   $b5='(Functional)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Functional)';$f8='(\\s+)';  $f9='(Requirements)';




   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $text1, $matches  ))
  {
   

 if ($fu1 == 0) {


      $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
       $c3=$matches[6][0];     
    
 

if ($ab=strstr($text1, "$d1$c1$d2$c2$d3$c3")){
$ab1=strstr($text1, "$d1$c1$d2$c2$d3$c3");
$az=All($ab1);
echo "$az";



   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7.$b10.$f9."/is", $ab1, $matches ))
  {
   $j1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab1, $matches)) {
  $j3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab1, $matches)) {
  $j4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; 
 $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
   $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';


   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$a.$b7.$b9.$b11."/is", $ab1, $matches ))
  {
   $j5++;

  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$a.$b7.$b10.$f9."/is", $ab1, $matches)) {
    $j6++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j7++;
 
  }elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j8++;
  }
 

   $b1='(\d)'; $b2='(\\.)';$b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
    $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';
   
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
$j9++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$b7.$b10.$f9."/is", $ab1, $matches)) {
    $j10++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j11++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j12++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
    $j13++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j14++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j15++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j16++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
   $j17++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
    $j18++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j19++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j20++;
  }



}



 }

 
 else{
echo ".";
 }


  } 


 elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $text1, $matches)) {
 
 
 if ($fu2 ==0) {

      $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
    
    
 

if ($ab=strstr($text1, "$d1$c1$d2$c2$d3")){
$ab1=strstr($text1, "$d1$c1$d2$c2$d3");
$az=All($ab1);
echo "$az";




   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7.$b10.$f9."/is", $ab1, $matches ))
  {
   $j1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab1, $matches)) {
  $j3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab1, $matches)) {
  $j4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; 
 $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
   $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';


   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$a.$b7.$b9.$b11."/is", $ab1, $matches ))
  {
   $j5++;

  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$a.$b7.$b10.$f9."/is", $ab1, $matches)) {
    $j6++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j7++;
 
  }elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j8++;
  }
 

   $b1='(\d)'; $b2='(\\.)';$b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
    $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';
   
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
$j9++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$b7.$b10.$f9."/is", $ab1, $matches)) {
    $j10++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j11++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j12++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
    $j13++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j14++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j15++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j16++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
   $j17++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
    $j18++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j19++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j20++;
  }

}

 }

 
 else{
echo ".";
 }


}elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $text1, $matches)) {

 
 if ($fu3 == 0) {

      $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
      $c3=$matches[6][0];     
      $d4=$matches[7][0];
    
 

if ($ab=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4")){
$ab1=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4");
$az=All($ab1);
echo "$az";



   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7.$b10.$f9."/is", $ab1, $matches ))
  {
   $j1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab1, $matches)) {
  $j3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab1, $matches)) {
  $j4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; 
 $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
   $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';


   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$a.$b7.$b9.$b11."/is", $ab1, $matches ))
  {
   $j5++;

  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$a.$b7.$b10.$f9."/is", $ab1, $matches)) {
    $j6++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j7++;
 
  }elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j8++;
  }
 

   $b1='(\d)'; $b2='(\\.)';$b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
    $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';
   
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
$j9++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$b7.$b10.$f9."/is", $ab1, $matches)) {
    $j10++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j11++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j12++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
    $j13++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j14++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j15++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j16++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
   $j17++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
    $j18++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j19++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j20++;
  }

}


 }

 
 else{
echo ".";
 }
}

elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $text1, $matches)) {
    
 
 if ($fu4 == 0) {

  
     
      $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
      $c3=$matches[6][0];     
      $d4=$matches[7][0];
    $c4=$matches[8][0];
 

if ($ab=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4$c4")){
$ab1=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4$c4");
$az=All($ab1);
echo "$az";

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7.$b10.$f9."/is", $ab1, $matches ))
  {
   $j1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab1, $matches)) {
  $j3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab1, $matches)) {
  $j4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; 
 $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
   $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';


   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$a.$b7.$b9.$b11."/is", $ab1, $matches ))
  {
   $j5++;

  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$a.$b7.$b10.$f9."/is", $ab1, $matches)) {
    $j6++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j7++;
 
  }elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j8++;
  }
 

   $b1='(\d)'; $b2='(\\.)';$b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
    $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';
   
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
$j9++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$b7.$b10.$f9."/is", $ab1, $matches)) {
    $j10++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j11++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j12++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
    $j13++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j14++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j15++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j16++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
   $j17++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
    $j18++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j19++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j20++;
  }

}


 }

 
 else{
echo ".";
 }
}

  



$k1=0;$k2=0;$k3=0;$k4=0;$k5=0;$k6=0;$k7=0;$k8=0;$k9=0;$k10=0;$k11=0;$k12=0;$k13=0;$k14=0;$k15=0;$k16=0;$k17=0;$k18=0;$k19=0; $k20=0;
$k21=0;$k22=0;$k23=0;$k24=0;$k25=0;$k26=0;$k27=0;$k28=0;$k29=0;$k30=0;$k31=0;$k32=0;$k33=0;$k34=0;$k35=0;$k36=0;$k37=0;$k38=0;$k39=0; $k40=0;




   $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Non)';  # Word 1
  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7.$b10.$f9."/is", $text1, $matches ))
  {
  
 
 if ($nf1 == 0) {
    if ($j1 ==0) {
    

  
      $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
      $c3=$matches[6][0];     
      $d4=$matches[7][0];
     $c4=$matches[8][0];
 

if ($ab=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4$c4")){
$ab1=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4$c4");
$az=All($ab1);
echo "$az";


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
    $j13++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j14++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j15++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j16++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
   $j17++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
    $j18++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j19++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j20++;
  }

}
}

}

 else{
echo ".";
 }

  } 
  elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$b7.$b10.$f9."/is", $text1, $matches)) {
   

 
 if ($nf2 == 0) {
if ($j2 ==0) {
  
      $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
      $c3=$matches[6][0];     
      $d4=$matches[7][0];
     
 

if ($ab=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4")){
$ab1=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4");
$az=All($ab1);
echo "$az";


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
    $j13++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j14++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j15++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j16++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
   $j17++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
    $j18++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j19++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j20++;
  }
}
}
}

 else{
echo ".";
 }

  }
elseif  ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $text1, $matches)) {
  

 if ($nf3 == 0) {
if ($j3 ==0) {
  
      $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
      $c3=$matches[6][0];     
      $d4=$matches[7][0];
      $c4=$matches[8][0];     
      $d5=$matches[9][0];

if ($ab=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4$c4$d5")){
$ab1=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4$c4$d5");
$az=All($ab1);
echo "$az";


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
    $j13++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j14++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j15++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j16++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
   $j17++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
    $j18++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j19++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j20++;
  }
}
}
}
 
 else{
echo ".";
 }

  } elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $text1, $matches)) {


 if ($nf4 == 0) {
if ($j4 ==0) {
  
      $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
      $c3=$matches[6][0];     
      $d4=$matches[7][0];
     
 $c4=$matches[8][0];     
      $d5=$matches[9][0];
$c5=$matches[10][0];


if ($ab=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4$c4$d5$c5")){
$ab1=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4$c4$d5$c5");
$az=All($ab1);
echo "$az";


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
    $j13++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j14++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j15++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j16++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
   $j17++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
    $j18++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j19++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j20++;
  }
}
}
}
 
 else{
echo "already";
 }
  }


   $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Non)';  # Word 1 

  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

 $spe=0;
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$a.$b7.$b9.$b11."/is", $text1, $matches ))
  {
   
 if ($nf5 == 0) {
if ($j5 ==0) {
  
      $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
      $c3=$matches[6][0];     
      $d4=$matches[7][0];
     
 $c4=$matches[8][0];     
      


if ($ab=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4$c4")){
$ab1=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4$c4");
$az=All($ab1);
echo "$az";


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
    $j13++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j14++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j15++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j16++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
   $j17++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
    $j18++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j19++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j20++;
  }
}
}
}
 
 else{
echo ".";
 }


  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$a.$b7.$b10.$f9."/is", $text1, $matches)) {


 if ($nf6 == 0) {
if ($j6 ==0) {
  
      $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
      $c3=$matches[6][0];     
      $d4=$matches[7][0];
     
 

if ($ab=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4")){
$ab1=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4");
$az=All($ab1);
echo "$az";


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
    $j13++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j14++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j15++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j16++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
   $j17++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
    $j18++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j19++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j20++;
  }
}
}
}
 else{
echo ".";
 }


  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $text1, $matches)) {

 if ($nf7 == 0) {
if ($j7 ==0) {
  
      $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
      $c3=$matches[6][0];     
      $d4=$matches[7][0];
     
 $c4=$matches[8][0];     
      $d5=$matches[9][0];



if ($ab=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4$c4$d5")){
$ab1=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4$c4$d5");
$az=All($ab1);
echo "$az";

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
    $j13++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j14++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j15++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j16++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
   $j17++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
    $j18++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j19++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j20++;
  }
}
}
}
 
 else{
echo ".";
 }
  
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $text1, $matches)) {

 if ($nf8 == 0) {
if ($j8 ==0) {
  
      $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
      $c3=$matches[6][0];     
      $d4=$matches[7][0];
     
 $c4=$matches[8][0];     
      $d5=$matches[9][0];
$c5=$matches[10][0];


if ($ab=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4$c4$d5$c5")){
$ab1=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4$c4$d5$c5");
$az=All($ab1);
echo "$az";


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
    $j13++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j14++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j15++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j16++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
   $j17++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
    $j18++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j19++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j20++;
  }
}
}
}
 
 else{
echo ".";
 }
  }
  


   $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Non)';  # Word 1 

  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b7.$b9.$b11."/is", $text1, $matches  ))
  {


 if ($nf9 == 0) {
if ($j9 ==0) {
  
      $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
      $c3=$matches[6][0];     
      $d4=$matches[7][0];
     
 

if ($ab=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4")){
$ab1=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4");
$az=All($ab1);
echo "$az";


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
    $j13++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j14++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j15++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j16++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
   $j17++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
    $j18++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j19++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j20++;
  }
}
}
}
 else{
echo ".";
 }


  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$b7.$b10.$f9."/is", $text1, $matches)) {
  

 if ($nf10 == 0) {
if ($j10 ==0) {
  
      $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
      $c3=$matches[6][0];     
    
     
 

if ($ab=strstr($text1, "$d1$c1$d2$c2$d3$c3")){
$ab1=strstr($text1, "$d1$c1$d2$c2$d3$c3");
$az=All($ab1);
echo "$az";


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
    $j13++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j14++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j15++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j16++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
   $j17++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
    $j18++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j19++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j20++;
  }
}
}
}
 
 else{
echo ".";
 }


  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $text1, $matches)) {
   


 if ($nf11 == 0) {
if ($j11 ==0) {
  
      $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
      $c3=$matches[6][0];     
      $d4=$matches[7][0];
     $c4=$matches[8][0];
 

if ($ab=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4$c4")){
$ab1=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4$c4");
$az=All($ab1);
echo "$az";


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
    $j13++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j14++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j15++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j16++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
   $j17++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
    $j18++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j19++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j20++;
  }
}
}
}
 
 else{
echo ".";
 }

  }
 elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $text1, $matches)) {
 

 if ($nf12 == 0) {
if ($j12 ==0) {
  
      $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
      $c3=$matches[6][0];     
      $d4=$matches[7][0];
     $c4=$matches[8][0];
 $d5=$matches[9][0];

if ($ab=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4$c4$d5")){
$ab1=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4$c4$d5");
$az=All($ab1);
echo "$az";


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
    $j13++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j14++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j15++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j16++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
   $j17++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
    $j18++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j19++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j20++;
  }
}
}
}
 
 else{
echo ".";
 }
  }

/////////////////////// non functionals end//////////////////////

  
$y1=0;$y2=0;$y3=0;$y4=0;$y5=0;$y6=0;$y7=0;$y8=0;$y9=0;$y10=0;$y11=0;$y12=0;$y13=0;$y14=0;$y15=0;$y16=0;$y17=0;$y18=0;$y19=0;$y20=0;$y21=0;$y22=0;$y23=0;

   $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Non)';  # Word 1 

  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $text1, $matches  ))
  {


 if ($p1 == 0) {
if (($j13 AND $j14 AND $j15 AND $j16) > 0) {
 

      $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
      $c3=$matches[6][0];     
   

if ($ab=strstr($text1, "$d1$c1$d2$c2$d3$c3")){
$ab1=strstr($text1, "$d1$c1$d2$c2$d3$c3");
$az=All($ab1);
echo "$az";


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
   $j17++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
    $j18++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j19++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j20++;
  }
}
} 
}
 
 else{
echo " ";
 }


  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $text1, $matches)) {
 


 if ($p2 == 0) {
if (($j13 AND $j14 AND $j15 AND $j16) > 0) {
  
      $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
      

if ($ab=strstr($text1, "$d1$c1$d2$c2$d3")){
$ab1=strstr($text1, "$d1$c1$d2$c2$d3");
$az=All($ab1);
echo "$az";


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
   $j17++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
    $j18++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j19++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j20++;
  }
}
}
}
 
 
 else{
echo ".";
 }

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $text1, $matches)) {
   


 if ($p3 == 0) {

  if (($j13 AND $j14 AND $j15 AND $j16) > 0) {
      $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
      $c3=$matches[6][0];     
      $d4=$matches[7][0];
    

if ($ab=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4")){
$ab1=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4");
$az=All($ab1);
echo "$az";



   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
   $j17++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
    $j18++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j19++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j20++;
  }
}
}
}
 

 else{
echo ".";
 }
  }
 elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $text1, $matches)) {
   


 if ($p4 == 0) {
if (($j13 AND $j14 AND $j15 AND $j16) > 0) {
  
      $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
      $c3=$matches[6][0];     
      $d4=$matches[7][0];
     $c4=$matches[8][0];


if ($ab=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4$c4")){
$ab1=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4$c4");
$az=All($ab1);
echo "$az";



   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
   $j17++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
    $j18++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j19++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j20++;
  }
}
}
}
 
 else{
echo ".";
 }
  }



   $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Non)';  # Word 1 

  $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $text1, $matches  ))
  {



 if ($q1 == 0) {
if (($j17 AND $j18 AND $j19 AND $j20) > 0) {
  
      $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
      $c3=$matches[6][0];     
    


if ($ab=strstr($text1, "$d1$c1$d2$c2$d3$c3")){
$ab1=strstr($text1, "$d1$c1$d2$c2$d3$c3");
$az=All($ab1);
echo "$az";
}
}
 }
 
 else{
echo " ";
 }

   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $text1, $matches)) {
    


 if ($q2 == 0) {
if (($j17 AND $j18 AND $j19 AND $j20) > 0) {
  
      $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
      


if ($ab=strstr($text1, "$d1$c1$d2$c2$d3")){
$ab1=strstr($text1, "$d1$c1$d2$c2$d3");
$az=All($ab1);
echo "$az";
}
}
}
 
 else{
echo " ";
 }

  }
  elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $text1, $matches)) {

 if ($q3 == 0) {

  if (($j17 AND $j18 AND $j19 AND $j20) > 0) {
      $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
      $c3=$matches[6][0];     
      $d4=$matches[7][0];
     


if ($ab=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4")){
$ab1=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4");
$az=All($ab1);
echo "$az";
}
}
 }
 else{
echo " ";
 }

  }
elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $text1, $matches)) {
  



 if ($q4 == 0) {
if (($j17 AND $j18 AND $j19 AND $j20) > 0) {
  
      $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
      $c3=$matches[6][0];     
      $d4=$matches[7][0];
      $c4=$matches[8][0];


if ($ab=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4$c4")){
$ab1=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4$c4");
$az=All($ab1);
echo "$az";
}
}
}
   else{
echo " ";
 }

  }

  


}




















function docx($text1)
{

  

$f1=0; $f2=0; $f3=0;$f4=0;
$nf1=0;$nf2=0;$nf3=0;
$nf4=0;$nf5=0;$nf6=0;
$nf7=0;$nf8=0;$nf9=0;$nf10=0;$nf11=0;$nf12=0;
$p1=0; $p2=0;$p3=0; $p4=0;
$q1=0; $q2=0; $q3=0;$q4=0;


$fu1=0;
$fu2=0;$fu3=0;$fu4=0;
$a1=0;$a2=0;$a3=0;$a4=0;$a5=0;$a6=0;$a7=0;$a8=0;$a9=0;$a10=0;$a11=0;$a12=0;$a13=0;$a14=0;$a15=0;$a16=0;


$b1='(\d)'; $b2='(\\.)'; $a='(-)';
   $b4='(\\s+)';   $b5='(Specific)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Specific)';$f8='(\\s+)';  $f9='(Requirements)';

 if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $text1, $matches  ))
  {

 
      $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
      $c3=$matches[6][0];
     // print "<br><br>$d1 $c1 $d2 $c2 $d3 $c3  actual ye ha heading\n";

if (strstr($text1, "$d1$c1$d2$c2$d3$c3"))
{
$ab= strstr($text1, "$d1$c1$d2$c2$d3$c3");

$az=newAll($ab);
echo "$az";

  
 $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Functional)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Functional)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $ab, $matches  ))
  {

  
    $fu1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $ab, $matches)) {
    
     $fu2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {
 
  $fu3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {

  $fu4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7.$b10.$f9."/is", $ab, $matches ))
  {
   $nf1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; 
 $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
   $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';


   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$a.$b7.$b9.$b11."/is", $ab, $matches ))
  {
   $nf5++;

  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf6++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf7++;
  
  }elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf8++;
  }
 
    
   $b1='(\d)'; $b2='(\\.)';$b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
    $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';
   
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
$nf9++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf10++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf11++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf12++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
    $p1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p4++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
   $q1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
    $q2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q4++;
  }



}


}

 elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $text1, $matches)) {

  $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];



if ($ab=strstr($text1, "$d1$c1$d2$c2$d3")){
$ab=strstr($text1, "$d1$c1$d2$c2$d3");

 
$az=newAll($ab);
echo "$az";




 $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Functional)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Functional)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $ab, $matches  ))
  {

  
    $fu1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $ab, $matches)) {
    
     $fu2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {
 
  $fu3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {

  $fu4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7.$b10.$f9."/is", $ab, $matches ))
  {
   $nf1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; 
 $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
   $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';


   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$a.$b7.$b9.$b11."/is", $ab, $matches ))
  {
   $nf5++;

  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf6++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf7++;
  
  }elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf8++;
  }
 

   $b1='(\d)'; $b2='(\\.)';$b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
    $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';
   
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
$nf9++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf10++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf11++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf12++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
    $p1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p4++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
   $q1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
    $q2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q4++;
  }

}
}
 elseif ($c=preg_match_all ("/".$b1.$b2.$b4.$b8.$b6.$b5.$b6.$b7."/is", $text1, $matches  ))
  {
  
      $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
      $c3=$matches[6][0];
       $d4=$matches[7][0];
      $c4=$matches[8][0];
     // print "<br><br>$d1 $c1 $d2 $c2 $d3 $c3  actual ye ha heading\n";


if (strstr($text1, "$d1$c1$d2$c2$d3$c3$d4$c4"))
{
$ab= strstr($text1, "$d1$c1$d2$c2$d3$c3$d4$c4");

$az=newAll($ab);
echo "$az";





 $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Functional)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Functional)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $ab, $matches  ))
  {

  
    $fu1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $ab, $matches)) {
    
     $fu2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {
 
  $fu3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {

  $fu4++;
  }


 $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7.$b10.$f9."/is", $ab, $matches ))
  {
   $nf1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; 
 $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
   $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';


   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$a.$b7.$b9.$b11."/is", $ab, $matches ))
  {
   $nf5++;

  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf6++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf7++;
  
  }elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf8++;
  }
 

   $b1='(\d)'; $b2='(\\.)';$b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
    $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';
   
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
$nf9++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf10++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf11++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf12++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
    $p1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p4++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
   $q1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
    $q2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q4++;
  }


}
}
 elseif ($c=preg_match_all ("/".$b1.$b4.$b8.$b6.$b5.$b6.$b7."/is", $text1, $matches  )) {


  $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
       $c3=$matches[6][0];     
      $d4=$matches[7][0];


if ($ab=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4")){
$ab=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4");
$az=newAll($ab);
echo "$az";




 $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Functional)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Functional)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $ab, $matches  ))
  {

  
    $fu1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $ab, $matches)) {
    
     $fu2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {
 
  $fu3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {

  $fu4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7.$b10.$f9."/is", $ab, $matches ))
  {
   $nf1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; 
 $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
   $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';


   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$a.$b7.$b9.$b11."/is", $ab, $matches ))
  {
   $nf5++;

  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf6++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf7++;
  
  }elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf8++;
  }
 

   $b1='(\d)'; $b2='(\\.)';$b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
    $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';
   
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
$nf9++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf10++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf11++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf12++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
    $p1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p4++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
   $q1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
    $q2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q4++;
  }

}

}


 

/////////////////////////////// First typeeeeeeeeeee endddddddddddddddddddddddd////////////////////////////////


   $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Technical)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Technical)';$f8='(\\s+)';  $f9='(Requirements)';

  if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $text1, $matches  ))
  {
 $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
 $c3=$matches[6][0];



if ($ab=strstr($text1, "$d1$c1$d2$c2$d3$c3")){
$ab=strstr($text1, "$d1$c1$d2$c2$d3$c3");




$az=newAll($ab);
echo "$az";



 $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Functional)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Functional)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $ab, $matches  ))
  {

  
    $fu1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $ab, $matches)) {
    
     $fu2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {
 
  $fu3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {

  $fu4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7.$b10.$f9."/is", $ab, $matches ))
  {
   $nf1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; 
 $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
   $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';


   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$a.$b7.$b9.$b11."/is", $ab, $matches ))
  {
   $nf5++;

  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf6++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf7++;
  
  }elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf8++;
  }
 

   $b1='(\d)'; $b2='(\\.)';$b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
    $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';
   
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
$nf9++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf10++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf11++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf12++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
    $p1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p4++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
   $q1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
    $q2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q4++;
  }

}

}


 elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $text1, $matches)) {

$d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];



if ($ab=strstr($text1, "$d1$c1$d2$c2$d3")){
$ab=strstr($text1, "$d1$c1$d2$c2$d3");


$az=newAll($ab);
echo "$az";




 $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Functional)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Functional)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $ab, $matches  ))
  {

  
    $fu1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $ab, $matches)) {
    
     $fu2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {
 
  $fu3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {

  $fu4++;
  }

    $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7.$b10.$f9."/is", $ab, $matches ))
  {
   $nf1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; 
 $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
   $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';


   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$a.$b7.$b9.$b11."/is", $ab, $matches ))
  {
   $nf5++;

  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf6++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf7++;
  
  }elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf8++;
  }
 

   $b1='(\d)'; $b2='(\\.)';$b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
    $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';
   
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
$nf9++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf10++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf11++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf12++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
    $p1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p4++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
   $q1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
    $q2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q4++;
  }

}
}
   elseif ($c=preg_match_all ("/".$b1.$b2.$b4.$b8.$b9.$b5.$b6.$b7."/is", $text1, $matches  ))
  {
 $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
 $c3=$matches[6][0];
$d4=$matches[7][0];
 $c4=$matches[8][0];



if ($ab=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4$c4")){
$ab=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4$c4");

$az=newAll($ab);
echo "$az";



 $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Functional)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Functional)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $ab, $matches  ))
  {

  
    $fu1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $ab, $matches)) {
    
     $fu2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {
 
  $fu3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {

  $fu4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7.$b10.$f9."/is", $ab, $matches ))
  {
   $nf1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; 
 $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
   $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';


   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$a.$b7.$b9.$b11."/is", $ab, $matches ))
  {
   $nf5++;

  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf6++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf7++;
  
  }elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf8++;
  }
 

   $b1='(\d)'; $b2='(\\.)';$b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
    $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';
   
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
$nf9++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf10++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf11++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf12++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
    $p1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p4++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
   $q1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
    $q2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q4++;
  }

}
}


 elseif ($c=preg_match_all ("/".$b1.$b4.$b8.$b6.$b5.$b6.$b7."/is", $text1, $matches  )) {


  $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
       $c3=$matches[6][0];     
      $d4=$matches[7][0];



if ($ab=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4")){
$ab=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4");
$az=newAll($ab);
echo "$az";


 $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Functional)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Functional)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $ab, $matches  ))
  {

  
    $fu1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $ab, $matches)) {
    
     $fu2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {
 
  $fu3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {

  $fu4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7.$b10.$f9."/is", $ab, $matches ))
  {
   $nf1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; 
 $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
   $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';


   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$a.$b7.$b9.$b11."/is", $ab, $matches ))
  {
   $nf5++;

  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf6++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf7++;
  
  }elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf8++;
  }
 

   $b1='(\d)'; $b2='(\\.)';$b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
    $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';
   
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
$nf9++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf10++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf11++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf12++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
    $p1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p4++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
   $q1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
    $q2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q4++;
  }


}

}




  


   $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(System)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(System)';$f8='(\\s+)';  $f9='(Requirements)';

  
  if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $text1, $matches  ))
  {
$d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
        $c3=$matches[6][0];


if ($ab=strstr($text1, "$d1$c1$d2$c2$d3$c3")){
$ab=strstr($text1, "$d1$c1$d2$c2$d3$c3");


$az=newAll($ab);
echo "$az";



 $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Functional)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Functional)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $ab, $matches  ))
  {

  
    $fu1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $ab, $matches)) {
    
     $fu2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {
 
  $fu3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {

  $fu4++;
  }

 $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7.$b10.$f9."/is", $ab, $matches ))
  {
   $nf1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; 
 $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
   $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';


   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$a.$b7.$b9.$b11."/is", $ab, $matches ))
  {
   $nf5++;

  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf6++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf7++;
  
  }elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf8++;
  }
 

   $b1='(\d)'; $b2='(\\.)';$b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
    $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';
   
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
$nf9++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf10++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf11++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf12++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
    $p1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p4++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
   $q1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
    $q2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q4++;
  }

}


}

 elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $text1, $matches)) {
$d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];


if ($ab=strstr($text1, "$d1$c1$d2$c2$d3")){
$ab=strstr($text1, "$d1$c1$d2$c2$d3");


$az=newAll($ab);
echo "$az";



 $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Functional)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Functional)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $ab, $matches  ))
  {

  
    $fu1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $ab, $matches)) {
    
     $fu2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {
 
  $fu3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {

  $fu4++;
  }

    $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7.$b10.$f9."/is", $ab, $matches ))
  {
   $nf1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; 
 $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
   $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';


   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$a.$b7.$b9.$b11."/is", $ab, $matches ))
  {
   $nf5++;

  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf6++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf7++;
  
  }elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf8++;
  }
 

   $b1='(\d)'; $b2='(\\.)';$b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
    $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';
   
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
$nf9++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf10++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf11++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf12++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
    $p1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p4++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
   $q1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
    $q2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q4++;
  }

} 
}
elseif ($c=preg_match_all ("/".$b1.$b2.$b4.$b8.$b9.$b5.$b6.$b7."/is", $text1, $matches  ))
  {
 $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
 $c3=$matches[6][0];
$d4=$matches[7][0];
 $c4=$matches[8][0];



if ($ab=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4$c4")){
$ab=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4$c4");
$az=newAll($ab);
echo "$az";


 $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Functional)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Functional)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $ab, $matches  ))
  {

  
    $fu1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $ab, $matches)) {
    
     $fu2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {
 
  $fu3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {

  $fu4++;
  }


 $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7.$b10.$f9."/is", $ab, $matches ))
  {
   $nf1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; 
 $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
   $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';


   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$a.$b7.$b9.$b11."/is", $ab, $matches ))
  {
   $nf5++;

  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf6++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf7++;
  
  }elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf8++;
  }
 

   $b1='(\d)'; $b2='(\\.)';$b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
    $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';
   
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
$nf9++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf10++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf11++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf12++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
    $p1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p4++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
   $q1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
    $q2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q4++;
  }


}
}


 elseif ($c=preg_match_all ("/".$b1.$b4.$b8.$b6.$b5.$b6.$b7."/is", $text1, $matches  )) {


  $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
       $c3=$matches[6][0];     
      $d4=$matches[7][0];


if ($ab=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4")){
$ab=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4");
$az=newAll($ab);
echo "$az";




 $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Functional)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Functional)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $ab, $matches  ))
  {

  
    $fu1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $ab, $matches)) {
    
     $fu2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {
 
  $fu3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {

  $fu4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7.$b10.$f9."/is", $ab, $matches ))
  {
   $nf1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; 
 $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
   $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';


   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$a.$b7.$b9.$b11."/is", $ab, $matches ))
  {
   $nf5++;

  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf6++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf7++;
  
  }elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf8++;
  }
 

   $b1='(\d)'; $b2='(\\.)';$b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
    $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';
   
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
$nf9++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf10++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf11++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf12++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
    $p1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p4++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
   $q1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
    $q2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q4++;
  }

}

}

  

   $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(System)';  # Word 1
  $b6='(\\s+)';  $b7='(Features)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(System)';$f8='(\\s+)';  $f9='(Features)';

if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $text1, $matches  ))
  {
 $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
 $c3=$matches[6][0];


if ($ab=strstr($text1, "$d1$c1$d2$c2$d3$c3")){
$ab=strstr($text1, "$d1$c1$d2$c2$d3$c3");

$az=newAll($ab);
echo "$az";


 $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Functional)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Functional)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $ab, $matches  ))
  {

  
    $fu1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $ab, $matches)) {
    
     $fu2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {
 
  $fu3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {

  $fu4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7.$b10.$f9."/is", $ab, $matches ))
  {
   $nf1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; 
 $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
   $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';


   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$a.$b7.$b9.$b11."/is", $ab, $matches ))
  {
   $nf5++;

  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf6++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf7++;
  
  }elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf8++;
  }
 

   $b1='(\d)'; $b2='(\\.)';$b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
    $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';
   
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
$nf9++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf10++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf11++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf12++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
    $p1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p4++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
   $q1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
    $q2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q4++;
  }

}


}
elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $text1, $matches)) {
 $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];



if ($ab=strstr($text1, "$d1$c1$d2$c2$d3")){
$ab=strstr($text1, "$d1$c1$d2$c2$d3");


$az=newAll($ab);
echo "$az";



 $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Functional)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Functional)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $ab, $matches  ))
  {

  
    $fu1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $ab, $matches)) {
    
     $fu2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {
 
  $fu3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {

  $fu4++;
  }



  $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7.$b10.$f9."/is", $ab, $matches ))
  {
   $nf1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; 
 $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
   $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';


   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$a.$b7.$b9.$b11."/is", $ab, $matches ))
  {
   $nf5++;

  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf6++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf7++;
  
  }elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf8++;
  }
 

   $b1='(\d)'; $b2='(\\.)';$b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
    $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';
   
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
$nf9++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf10++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf11++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf12++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
    $p1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p4++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
   $q1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
    $q2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q4++;
  }

}

 }
elseif ($c=preg_match_all ("/".$b1.$b2.$b4.$b8.$b9.$b5.$b6.$b7."/is", $text1, $matches  ))
  {
 $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
 $c3=$matches[6][0];
$d4=$matches[7][0];
 $c4=$matches[8][0];


if ($ab=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4$c4")){
$ab=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4$c4");
$az=newAll($ab);
echo "$az";


 $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Functional)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Functional)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $ab, $matches  ))
  {

  
    $fu1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $ab, $matches)) {
    
     $fu2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {
 
  $fu3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {

  $fu4++;
  }


  $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7.$b10.$f9."/is", $ab, $matches ))
  {
   $nf1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; 
 $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
   $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';


   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$a.$b7.$b9.$b11."/is", $ab, $matches ))
  {
   $nf5++;

  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf6++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf7++;
  
  }elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf8++;
  }
 

   $b1='(\d)'; $b2='(\\.)';$b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
    $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';
   
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
$nf9++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf10++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf11++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf12++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
    $p1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p4++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
   $q1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
    $q2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q4++;
  }

}
}


 elseif ($c=preg_match_all ("/".$b1.$b4.$b8.$b6.$b5.$b6.$b7."/is", $text1, $matches  )) {


  $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
       $c3=$matches[6][0];     
      $d4=$matches[7][0];


if ($ab=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4")){
$ab=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4");
$az=newAll($ab);
echo "$az";


 $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Functional)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Functional)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $ab, $matches  ))
  {

  
    $fu1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $ab, $matches)) {
    
     $fu2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {
 
  $fu3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {

  $fu4++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7.$b10.$f9."/is", $ab, $matches ))
  {
   $nf1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; 
 $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
   $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';


   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$a.$b7.$b9.$b11."/is", $ab, $matches ))
  {
   $nf5++;

  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf6++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf7++;
  
  }elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf8++;
  }
 

   $b1='(\d)'; $b2='(\\.)';$b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
    $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';
   
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
$nf9++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf10++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf11++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf12++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
    $p1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p4++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
   $q1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
    $q2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q4++;
  }

}

}
  
  


   $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Requirements)';  # Word 1
  $b6='(\\s+)';  $b7='(Specification)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Requirements)';$f8='(\\s+)';  $f9='(Specification)';


if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $text1, $matches  ))
  {
$d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
 $c3=$matches[6][0];

if ($ab=strstr($text1, "$d1$c1$d2$c2$d3$c3")){
$ab=strstr($text1, "$d1$c1$d2$c2$d3$c3");


$az=newAll($ab);
echo "$az";



 $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Functional)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Functional)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $ab, $matches  ))
  {

  
    $fu1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $ab, $matches)) {
    
     $fu2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {
 
  $fu3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {

  $fu4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7.$b10.$f9."/is", $ab, $matches ))
  {
   $nf1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; 
 $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
   $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';


   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$a.$b7.$b9.$b11."/is", $ab, $matches ))
  {
   $nf5++;

  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf6++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf7++;
  
  }elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf8++;
  }
 

   $b1='(\d)'; $b2='(\\.)';$b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
    $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';
   
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
$nf9++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf10++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf11++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf12++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
    $p1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p4++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
   $q1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
    $q2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q4++;
  }

}


}
 elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $text1, $matches)) {
$d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];


if ($ab=strstr($text1, "$d1$c1$d2$c2$d3")){
$ab=strstr($text1, "$d1$c1$d2$c2$d3");


$az=newAll($ab);
echo "$az";



 $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Functional)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Functional)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $ab, $matches  ))
  {

  
    $fu1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $ab, $matches)) {
    
     $fu2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {
 
  $fu3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {

  $fu4++;
  }


 $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7.$b10.$f9."/is", $ab, $matches ))
  {
   $nf1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; 
 $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
   $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';


   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$a.$b7.$b9.$b11."/is", $ab, $matches ))
  {
   $nf5++;

  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf6++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf7++;
  
  }elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf8++;
  }
 

   $b1='(\d)'; $b2='(\\.)';$b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
    $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';
   
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
$nf9++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf10++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf11++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf12++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
    $p1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p4++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
   $q1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
    $q2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q4++;
  }

    }

 }
 elseif ($c=preg_match_all ("/".$b1.$b2.$b4.$b8.$b9.$b5.$b6.$b7."/is", $text1, $matches  ))
  {
 $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
 $c3=$matches[6][0];
$d4=$matches[7][0];
 $c4=$matches[8][0];


if ($ab=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4$c4")){
$ab=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4$c4");
$az=newAll($ab);
echo "$az";




 $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Functional)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Functional)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $ab, $matches  ))
  {

  
    $fu1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $ab, $matches)) {
    
     $fu2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {
 
  $fu3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {

  $fu4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7.$b10.$f9."/is", $ab, $matches ))
  {
   $nf1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; 
 $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
   $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';


   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$a.$b7.$b9.$b11."/is", $ab, $matches ))
  {
   $nf5++;

  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf6++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf7++;
  
  }elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf8++;
  }
 

   $b1='(\d)'; $b2='(\\.)';$b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
    $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';
   
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
$nf9++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf10++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf11++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf12++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
    $p1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p4++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
   $q1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
    $q2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q4++;
  }

}
}


 elseif ($c=preg_match_all ("/".$b1.$b4.$b8.$b6.$b5.$b6.$b7."/is", $text1, $matches  )) {


  $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
       $c3=$matches[6][0];     
      $d4=$matches[7][0];


if ($ab=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4")){
$ab=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4");
$az=newAll($ab);
echo "$az";



 $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Functional)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Functional)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $ab, $matches  ))
  {

  
    $fu1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $ab, $matches)) {
    
     $fu2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {
 
  $fu3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {

  $fu4++;
  }

 $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7.$b10.$f9."/is", $ab, $matches ))
  {
   $nf1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; 
 $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
   $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';


   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$a.$b7.$b9.$b11."/is", $ab, $matches ))
  {
   $nf5++;

  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf6++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf7++;
  
  }elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf8++;
  }
 

   $b1='(\d)'; $b2='(\\.)';$b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
    $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';
   
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
$nf9++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf10++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf11++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf12++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
    $p1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p4++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
   $q1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
    $q2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q4++;
  }

}

}

  

$j1=0;$j2=0;$j3=0;$j4=0;$j5=0;$j6=0;$j7=0;$j8=0;$j9=0;$j10=0;$j11=0;$j12=0;$j13=0;$j14=0;$j15=0;$j16=0;$j17=0;$j18=0;$j19=0; $j20=0;
$j21=0;$j22=0;$j23=0;$j24=0;$j25=0;$j26=0;$j27=0;$j28=0;$j29=0;$j30=0;$j31=0;$j32=0;$j33=0;$j34=0;$j35=0;$j36=0;$j37=0;$j38=0;$j39=0; $j40=0;

$j41=0;$j42=0;$j43=0;$j44=0;$j45=0;$j46=0;$j47=0;$j48=0;$j49=0;$j50=0;$j51=0;$j52=0;$j53=0;$j54=0;$j55=0;$j56=0;$j57=0;$j58=0;$j59=0; $j60=0;
$j61=0;$j62=0;$j63=0;$j64=0;$j65=0;$j66=0;$j67=0;$j68=0;$j69=0;$j70=0;$j71=0;$j72=0;$j73=0;$j74=0;$j75=0;$j76=0;$j77=0;$j78=0;$j79=0; $j80=0;

$j81=0;$j82=0;$j83=0;$j84=0;$j85=0;$j86=0;$j87=0;$j88=0;$j89=0;$j90=0;$j91=0;$j92=0;$j93=0;$j94=0;$j95=0;$j96=0;$j97=0;$j98=0;$j99=0;

 $b1='(\d)'; $b2='(\\.)';

   $b4='(\\s+)';   $b5='(Functional)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Functional)';$f8='(\\s+)';  $f9='(Requirements)';




   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $text1, $matches  ))
  {
   

 if ($fu1 == 0) {


      $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
       $c3=$matches[6][0];     
    
 

if ($ab=strstr($text1, "$d1$c1$d2$c2$d3$c3")){
$ab1=strstr($text1, "$d1$c1$d2$c2$d3$c3");
$az=All($ab1);
echo "$az";



   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7.$b10.$f9."/is", $ab1, $matches ))
  {
   $j1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab1, $matches)) {
  $j3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab1, $matches)) {
  $j4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; 
 $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
   $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';


   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$a.$b7.$b9.$b11."/is", $ab1, $matches ))
  {
   $j5++;

  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$a.$b7.$b10.$f9."/is", $ab1, $matches)) {
    $j6++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j7++;
 
  }elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j8++;
  }
 

   $b1='(\d)'; $b2='(\\.)';$b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
    $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';
   
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
$j9++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$b7.$b10.$f9."/is", $ab1, $matches)) {
    $j10++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j11++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j12++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
    $j13++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j14++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j15++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j16++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
   $j17++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
    $j18++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j19++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j20++;
  }



}



 }

 
 else{
echo ".";
 }


  } 


 elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $text1, $matches)) {
 
 
 if ($fu2 ==0) {

      $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
    
    
 

if ($ab=strstr($text1, "$d1$c1$d2$c2$d3")){
$ab1=strstr($text1, "$d1$c1$d2$c2$d3");
$az=All($ab1);
echo "$az";




   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7.$b10.$f9."/is", $ab1, $matches ))
  {
   $j1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab1, $matches)) {
  $j3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab1, $matches)) {
  $j4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; 
 $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
   $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';


   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$a.$b7.$b9.$b11."/is", $ab1, $matches ))
  {
   $j5++;

  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$a.$b7.$b10.$f9."/is", $ab1, $matches)) {
    $j6++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j7++;
 
  }elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j8++;
  }
 

   $b1='(\d)'; $b2='(\\.)';$b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
    $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';
   
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
$j9++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$b7.$b10.$f9."/is", $ab1, $matches)) {
    $j10++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j11++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j12++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
    $j13++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j14++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j15++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j16++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
   $j17++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
    $j18++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j19++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j20++;
  }

}

 }

 
 else{
echo ".";
 }


}elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $text1, $matches)) {

 
 if ($fu3 == 0) {

      $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
      $c3=$matches[6][0];     
      $d4=$matches[7][0];
    
 

if ($ab=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4")){
$ab1=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4");
$az=All($ab1);
echo "$az";



   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7.$b10.$f9."/is", $ab1, $matches ))
  {
   $j1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab1, $matches)) {
  $j3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab1, $matches)) {
  $j4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; 
 $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
   $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';


   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$a.$b7.$b9.$b11."/is", $ab1, $matches ))
  {
   $j5++;

  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$a.$b7.$b10.$f9."/is", $ab1, $matches)) {
    $j6++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j7++;
 
  }elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j8++;
  }
 

   $b1='(\d)'; $b2='(\\.)';$b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
    $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';
   
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
$j9++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$b7.$b10.$f9."/is", $ab1, $matches)) {
    $j10++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j11++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j12++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
    $j13++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j14++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j15++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j16++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
   $j17++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
    $j18++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j19++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j20++;
  }

}


 }

 
 else{
echo ".";
 }
}

elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $text1, $matches)) {
    
 
 if ($fu4 == 0) {

  
     
      $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
      $c3=$matches[6][0];     
      $d4=$matches[7][0];
    $c4=$matches[8][0];
 

if ($ab=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4$c4")){
$ab1=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4$c4");
$az=All($ab1);
echo "$az";

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7.$b10.$f9."/is", $ab1, $matches ))
  {
   $j1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab1, $matches)) {
  $j3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab1, $matches)) {
  $j4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; 
 $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
   $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';


   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$a.$b7.$b9.$b11."/is", $ab1, $matches ))
  {
   $j5++;

  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$a.$b7.$b10.$f9."/is", $ab1, $matches)) {
    $j6++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j7++;
 
  }elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j8++;
  }
 

   $b1='(\d)'; $b2='(\\.)';$b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
    $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';
   
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
$j9++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$b7.$b10.$f9."/is", $ab1, $matches)) {
    $j10++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j11++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j12++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
    $j13++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j14++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j15++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j16++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
   $j17++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
    $j18++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j19++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j20++;
  }

}


 }

 
 else{
echo ".";
 }
}



$k1=0;$k2=0;$k3=0;$k4=0;$k5=0;$k6=0;$k7=0;$k8=0;$k9=0;$k10=0;$k11=0;$k12=0;$k13=0;$k14=0;$k15=0;$k16=0;$k17=0;$k18=0;$k19=0; $k20=0;
$k21=0;$k22=0;$k23=0;$k24=0;$k25=0;$k26=0;$k27=0;$k28=0;$k29=0;$k30=0;$k31=0;$k32=0;$k33=0;$k34=0;$k35=0;$k36=0;$k37=0;$k38=0;$k39=0; $k40=0;




   $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Non)';  # Word 1
  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7.$b10.$f9."/is", $text1, $matches ))
  {
  
 
 if ($nf1 == 0) {
    if ($j1 ==0) {
    

  
      $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
      $c3=$matches[6][0];     
      $d4=$matches[7][0];
     $c4=$matches[8][0];
 

if ($ab=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4$c4")){
$ab1=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4$c4");
$az=All($ab1);
echo "$az";


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
    $j13++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j14++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j15++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j16++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
   $j17++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
    $j18++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j19++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j20++;
  }

}
}

}

 else{
echo ".";
 }

  } 
  elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$b7.$b10.$f9."/is", $text1, $matches)) {
   

 
 if ($nf2 == 0) {
if ($j2 ==0) {
  
      $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
      $c3=$matches[6][0];     
      $d4=$matches[7][0];
     
 

if ($ab=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4")){
$ab1=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4");
$az=All($ab1);
echo "$az";


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
    $j13++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j14++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j15++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j16++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
   $j17++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
    $j18++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j19++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j20++;
  }
}
}
}

 else{
echo ".";
 }

  }
elseif  ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $text1, $matches)) {
  

 if ($nf3 == 0) {
if ($j3 ==0) {
  
      $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
      $c3=$matches[6][0];     
      $d4=$matches[7][0];
      $c4=$matches[8][0];     
      $d5=$matches[9][0];

if ($ab=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4$c4$d5")){
$ab1=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4$c4$d5");
$az=All($ab1);
echo "$az";


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
    $j13++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j14++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j15++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j16++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
   $j17++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
    $j18++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j19++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j20++;
  }
}
}
}
 
 else{
echo ".";
 }

  } elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $text1, $matches)) {


 if ($nf4 == 0) {
if ($j4 ==0) {
  
      $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
      $c3=$matches[6][0];     
      $d4=$matches[7][0];
     
 $c4=$matches[8][0];     
      $d5=$matches[9][0];
$c5=$matches[10][0];


if ($ab=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4$c4$d5$c5")){
$ab1=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4$c4$d5$c5");
$az=All($ab1);
echo "$az";


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
    $j13++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j14++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j15++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j16++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
   $j17++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
    $j18++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j19++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j20++;
  }
}
}
}
 
 else{
echo "already";
 }
  }

  

   $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Non)';  # Word 1 

  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

 $spe=0;
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$a.$b7.$b9.$b11."/is", $text1, $matches ))
  {
   
 if ($nf5 == 0) {
if ($j5 ==0) {
  
      $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
      $c3=$matches[6][0];     
      $d4=$matches[7][0];
     
 $c4=$matches[8][0];     
      


if ($ab=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4$c4")){
$ab1=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4$c4");
$az=All($ab1);
echo "$az";


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
    $j13++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j14++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j15++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j16++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
   $j17++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
    $j18++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j19++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j20++;
  }
}
}
}
 
 else{
echo ".";
 }


  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$a.$b7.$b10.$f9."/is", $text1, $matches)) {


 if ($nf6 == 0) {
if ($j6 ==0) {
  
      $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
      $c3=$matches[6][0];     
      $d4=$matches[7][0];
     
 

if ($ab=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4")){
$ab1=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4");
$az=All($ab1);
echo "$az";


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
    $j13++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j14++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j15++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j16++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
   $j17++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
    $j18++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j19++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j20++;
  }
}
}
}
 else{
echo ".";
 }


  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $text1, $matches)) {

 if ($nf7 == 0) {
if ($j7 ==0) {
  
      $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
      $c3=$matches[6][0];     
      $d4=$matches[7][0];
     
 $c4=$matches[8][0];     
      $d5=$matches[9][0];



if ($ab=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4$c4$d5")){
$ab1=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4$c4$d5");
$az=All($ab1);
echo "$az";

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
    $j13++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j14++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j15++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j16++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
   $j17++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
    $j18++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j19++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j20++;
  }
}
}
}
 
 else{
echo ".";
 }
  
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $text1, $matches)) {

 if ($nf8 == 0) {
if ($j8 ==0) {
  
      $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
      $c3=$matches[6][0];     
      $d4=$matches[7][0];
     
 $c4=$matches[8][0];     
      $d5=$matches[9][0];
$c5=$matches[10][0];


if ($ab=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4$c4$d5$c5")){
$ab1=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4$c4$d5$c5");
$az=All($ab1);
echo "$az";


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
    $j13++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j14++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j15++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j16++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
   $j17++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
    $j18++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j19++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j20++;
  }
}
}
}
 
 else{
echo ".";
 }
  }
  


   $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Non)';  # Word 1 

  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b7.$b9.$b11."/is", $text1, $matches  ))
  {


 if ($nf9 == 0) {
if ($j9 ==0) {
  
      $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
      $c3=$matches[6][0];     
      $d4=$matches[7][0];
     
 

if ($ab=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4")){
$ab1=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4");
$az=All($ab1);
echo "$az";


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
    $j13++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j14++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j15++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j16++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
   $j17++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
    $j18++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j19++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j20++;
  }
}
}
}
 else{
echo ".";
 }


  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$b7.$b10.$f9."/is", $text1, $matches)) {
  

 if ($nf10 == 0) {
if ($j10 ==0) {
  
      $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
      $c3=$matches[6][0];     
    
     
 

if ($ab=strstr($text1, "$d1$c1$d2$c2$d3$c3")){
$ab1=strstr($text1, "$d1$c1$d2$c2$d3$c3");
$az=All($ab1);
echo "$az";


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
    $j13++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j14++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j15++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j16++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
   $j17++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
    $j18++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j19++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j20++;
  }
}
}
}
 
 else{
echo ".";
 }


  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $text1, $matches)) {
   


 if ($nf11 == 0) {
if ($j11 ==0) {
  
      $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
      $c3=$matches[6][0];     
      $d4=$matches[7][0];
     $c4=$matches[8][0];
 

if ($ab=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4$c4")){
$ab1=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4$c4");
$az=All($ab1);
echo "$az";


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
    $j13++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j14++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j15++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j16++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
   $j17++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
    $j18++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j19++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j20++;
  }
}
}
}
 
 else{
echo ".";
 }

  }
 elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $text1, $matches)) {
 

 if ($nf12 == 0) {
if ($j12 ==0) {
  
      $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
      $c3=$matches[6][0];     
      $d4=$matches[7][0];
     $c4=$matches[8][0];
 $d5=$matches[9][0];

if ($ab=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4$c4$d5")){
$ab1=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4$c4$d5");
$az=All($ab1);
echo "$az";


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
    $j13++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j14++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j15++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j16++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
   $j17++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
    $j18++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j19++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j20++;
  }
}
}
}
 
 else{
echo ".";
 }
  }


/////////////////////// non functionals end//////////////////////

  
$y1=0;$y2=0;$y3=0;$y4=0;$y5=0;$y6=0;$y7=0;$y8=0;$y9=0;$y10=0;$y11=0;$y12=0;$y13=0;$y14=0;$y15=0;$y16=0;$y17=0;$y18=0;$y19=0;$y20=0;$y21=0;$y22=0;$y23=0;

   $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Non)';  # Word 1 

  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $text1, $matches  ))
  {


 if ($p1 == 0) {
if (($j13 AND $j14 AND $j15 AND $j16) > 0) {
 

      $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
      $c3=$matches[6][0];     
   

if ($ab=strstr($text1, "$d1$c1$d2$c2$d3$c3")){
$ab1=strstr($text1, "$d1$c1$d2$c2$d3$c3");
$az=All($ab1);
echo "$az";


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
   $j17++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
    $j18++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j19++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j20++;
  }
}
} 
}
 
 else{
echo " ";
 }


  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $text1, $matches)) {
 


 if ($p2 == 0) {
if (($j13 AND $j14 AND $j15 AND $j16) > 0) {
  
      $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
      

if ($ab=strstr($text1, "$d1$c1$d2$c2$d3")){
$ab1=strstr($text1, "$d1$c1$d2$c2$d3");
$az=All($ab1);
echo "$az";


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
   $j17++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
    $j18++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j19++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j20++;
  }
}
}
}
 
 
 else{
echo ".";
 }

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $text1, $matches)) {
   


 if ($p3 == 0) {

  if (($j13 AND $j14 AND $j15 AND $j16) > 0) {
      $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
      $c3=$matches[6][0];     
      $d4=$matches[7][0];
    

if ($ab=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4")){
$ab1=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4");
$az=All($ab1);
echo "$az";



   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
   $j17++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
    $j18++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j19++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j20++;
  }
}
}
}
 

 else{
echo ".";
 }
  }
 elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $text1, $matches)) {
   


 if ($p4 == 0) {
if (($j13 AND $j14 AND $j15 AND $j16) > 0) {
  
      $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
      $c3=$matches[6][0];     
      $d4=$matches[7][0];
     $c4=$matches[8][0];


if ($ab=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4$c4")){
$ab1=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4$c4");
$az=All($ab1);
echo "$az";



   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
   $j17++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
    $j18++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j19++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j20++;
  }
}
}
}
 
 else{
echo ".";
 }
  }

 

   $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Non)';  # Word 1 

  $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $text1, $matches  ))
  {



 if ($q1 == 0) {
if (($j17 AND $j18 AND $j19 AND $j20) > 0) {
  
      $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
      $c3=$matches[6][0];     
    


if ($ab=strstr($text1, "$d1$c1$d2$c2$d3$c3")){
$ab1=strstr($text1, "$d1$c1$d2$c2$d3$c3");
$az=All($ab1);
echo "$az";
}
}
 }
 
 else{
echo " ";
 }

   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $text1, $matches)) {
    


 if ($q2 == 0) {
if (($j17 AND $j18 AND $j19 AND $j20) > 0) {
  
      $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
      


if ($ab=strstr($text1, "$d1$c1$d2$c2$d3")){
$ab1=strstr($text1, "$d1$c1$d2$c2$d3");
$az=All($ab1);
echo "$az";
}
}
}
 
 else{
echo " ";
 }

  }
  elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $text1, $matches)) {

 if ($q3 == 0) {

  if (($j17 AND $j18 AND $j19 AND $j20) > 0) {
      $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
      $c3=$matches[6][0];     
      $d4=$matches[7][0];
     


if ($ab=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4")){
$ab1=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4");
$az=All($ab1);
echo "$az";
}
}
 }
 else{
echo " ";
 }

  }
elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $text1, $matches)) {
  



 if ($q4 == 0) {
if (($j17 AND $j18 AND $j19 AND $j20) > 0) {
  
      $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
      $c3=$matches[6][0];     
      $d4=$matches[7][0];
      $c4=$matches[8][0];


if ($ab=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4$c4")){
$ab1=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4$c4");
$az=All($ab1);
echo "$az";
}
}
}
   else{
echo " ";
 }

  }


}













































function doc($text1)
{

  

$f1=0; $f2=0; $f3=0;$f4=0;
$nf1=0;$nf2=0;$nf3=0;
$nf4=0;$nf5=0;$nf6=0;
$nf7=0;$nf8=0;$nf9=0;$nf10=0;$nf11=0;$nf12=0;
$p1=0; $p2=0;$p3=0; $p4=0;
$q1=0; $q2=0; $q3=0;$q4=0;


$fu1=0;
$fu2=0;$fu3=0;$fu4=0;
$a1=0;$a2=0;$a3=0;$a4=0;$a5=0;$a6=0;$a7=0;$a8=0;$a9=0;$a10=0;$a11=0;$a12=0;$a13=0;$a14=0;$a15=0;$a16=0;



$b1='(\d)'; $b2='(\\.)'; $a='(-)';
   $b4='(\\s+)';   $b5='(Specific)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Specific)';$f8='(\\s+)';  $f9='(Requirements)';

 if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $text1, $matches  ))
  {

 
      $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
      $c3=$matches[6][0];
     // print "<br><br>$d1 $c1 $d2 $c2 $d3 $c3  actual ye ha heading\n";

if (strstr($text1, "$d1$c1$d2$c2$d3$c3"))
{
$ab= strstr($text1, "$d1$c1$d2$c2$d3$c3");

$az=All($ab);
echo "$az";

  
 $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Functional)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Functional)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $ab, $matches  ))
  {

  
    $fu1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $ab, $matches)) {
    
     $fu2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {
 
  $fu3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {

  $fu4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7.$b10.$f9."/is", $ab, $matches ))
  {
   $nf1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; 
 $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
   $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';


   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$a.$b7.$b9.$b11."/is", $ab, $matches ))
  {
   $nf5++;

  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf6++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf7++;
  
  }elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf8++;
  }
 
    
   $b1='(\d)'; $b2='(\\.)';$b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
    $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';
   
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
$nf9++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf10++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf11++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf12++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
    $p1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p4++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
   $q1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
    $q2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q4++;
  }



}


}

 elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $text1, $matches)) {

  $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];



if ($ab=strstr($text1, "$d1$c1$d2$c2$d3")){
$ab=strstr($text1, "$d1$c1$d2$c2$d3");

 
$az=All($ab);
echo "$az";




 $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Functional)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Functional)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $ab, $matches  ))
  {

  
    $fu1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $ab, $matches)) {
    
     $fu2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {
 
  $fu3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {

  $fu4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7.$b10.$f9."/is", $ab, $matches ))
  {
   $nf1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; 
 $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
   $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';


   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$a.$b7.$b9.$b11."/is", $ab, $matches ))
  {
   $nf5++;

  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf6++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf7++;
  
  }elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf8++;
  }
 

   $b1='(\d)'; $b2='(\\.)';$b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
    $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';
   
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
$nf9++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf10++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf11++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf12++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
    $p1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p4++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
   $q1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
    $q2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q4++;
  }

}
}
 elseif ($c=preg_match_all ("/".$b1.$b2.$b4.$b8.$b6.$b5.$b6.$b7."/is", $text1, $matches  ))
  {
  
      $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
      $c3=$matches[6][0];
       $d4=$matches[7][0];
      $c4=$matches[8][0];
     // print "<br><br>$d1 $c1 $d2 $c2 $d3 $c3  actual ye ha heading\n";


if (strstr($text1, "$d1$c1$d2$c2$d3$c3$d4$c4"))
{
$ab= strstr($text1, "$d1$c1$d2$c2$d3$c3$d4$c4");

$az=All($ab);
echo "$az";





 $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Functional)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Functional)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $ab, $matches  ))
  {

  
    $fu1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $ab, $matches)) {
    
     $fu2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {
 
  $fu3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {

  $fu4++;
  }


 $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7.$b10.$f9."/is", $ab, $matches ))
  {
   $nf1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; 
 $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
   $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';


   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$a.$b7.$b9.$b11."/is", $ab, $matches ))
  {
   $nf5++;

  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf6++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf7++;
  
  }elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf8++;
  }
 

   $b1='(\d)'; $b2='(\\.)';$b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
    $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';
   
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
$nf9++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf10++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf11++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf12++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
    $p1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p4++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
   $q1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
    $q2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q4++;
  }


}
}
 elseif ($c=preg_match_all ("/".$b1.$b4.$b8.$b6.$b5.$b6.$b7."/is", $text1, $matches  )) {


  $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
       $c3=$matches[6][0];     
      $d4=$matches[7][0];


if ($ab=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4")){
$ab=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4");
$az=All($ab);
echo "$az";




 $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Functional)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Functional)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $ab, $matches  ))
  {

  
    $fu1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $ab, $matches)) {
    
     $fu2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {
 
  $fu3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {

  $fu4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7.$b10.$f9."/is", $ab, $matches ))
  {
   $nf1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; 
 $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
   $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';


   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$a.$b7.$b9.$b11."/is", $ab, $matches ))
  {
   $nf5++;

  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf6++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf7++;
  
  }elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf8++;
  }
 

   $b1='(\d)'; $b2='(\\.)';$b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
    $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';
   
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
$nf9++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf10++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf11++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf12++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
    $p1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p4++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
   $q1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
    $q2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q4++;
  }

}

}



/////////////////////////////// First typeeeeeeeeeee endddddddddddddddddddddddd////////////////////////////////


   $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Technical)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Technical)';$f8='(\\s+)';  $f9='(Requirements)';

  if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $text1, $matches  ))
  {
 $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
 $c3=$matches[6][0];



if ($ab=strstr($text1, "$d1$c1$d2$c2$d3$c3")){
$ab=strstr($text1, "$d1$c1$d2$c2$d3$c3");




$az=All($ab);
echo "$az";



 $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Functional)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Functional)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $ab, $matches  ))
  {

  
    $fu1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $ab, $matches)) {
    
     $fu2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {
 
  $fu3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {

  $fu4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7.$b10.$f9."/is", $ab, $matches ))
  {
   $nf1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; 
 $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
   $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';


   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$a.$b7.$b9.$b11."/is", $ab, $matches ))
  {
   $nf5++;

  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf6++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf7++;
  
  }elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf8++;
  }
 

   $b1='(\d)'; $b2='(\\.)';$b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
    $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';
   
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
$nf9++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf10++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf11++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf12++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
    $p1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p4++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
   $q1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
    $q2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q4++;
  }

}

}


 elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $text1, $matches)) {

$d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];



if ($ab=strstr($text1, "$d1$c1$d2$c2$d3")){
$ab=strstr($text1, "$d1$c1$d2$c2$d3");


$az=All($ab);
echo "$az";




 $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Functional)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Functional)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $ab, $matches  ))
  {

  
    $fu1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $ab, $matches)) {
    
     $fu2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {
 
  $fu3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {

  $fu4++;
  }

    $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7.$b10.$f9."/is", $ab, $matches ))
  {
   $nf1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; 
 $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
   $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';


   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$a.$b7.$b9.$b11."/is", $ab, $matches ))
  {
   $nf5++;

  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf6++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf7++;
  
  }elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf8++;
  }
 

   $b1='(\d)'; $b2='(\\.)';$b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
    $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';
   
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
$nf9++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf10++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf11++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf12++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
    $p1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p4++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
   $q1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
    $q2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q4++;
  }

}
}
   elseif ($c=preg_match_all ("/".$b1.$b2.$b4.$b8.$b9.$b5.$b6.$b7."/is", $text1, $matches  ))
  {
 $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
 $c3=$matches[6][0];
$d4=$matches[7][0];
 $c4=$matches[8][0];



if ($ab=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4$c4")){
$ab=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4$c4");

$az=All($ab);
echo "$az";



 $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Functional)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Functional)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $ab, $matches  ))
  {

  
    $fu1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $ab, $matches)) {
    
     $fu2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {
 
  $fu3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {

  $fu4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7.$b10.$f9."/is", $ab, $matches ))
  {
   $nf1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; 
 $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
   $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';


   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$a.$b7.$b9.$b11."/is", $ab, $matches ))
  {
   $nf5++;

  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf6++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf7++;
  
  }elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf8++;
  }
 

   $b1='(\d)'; $b2='(\\.)';$b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
    $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';
   
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
$nf9++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf10++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf11++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf12++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
    $p1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p4++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
   $q1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
    $q2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q4++;
  }

}
}


 elseif ($c=preg_match_all ("/".$b1.$b4.$b8.$b6.$b5.$b6.$b7."/is", $text1, $matches  )) {


  $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
       $c3=$matches[6][0];     
      $d4=$matches[7][0];



if ($ab=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4")){
$ab=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4");
$az=All($ab);
echo "$az";


 $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Functional)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Functional)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $ab, $matches  ))
  {

  
    $fu1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $ab, $matches)) {
    
     $fu2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {
 
  $fu3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {

  $fu4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7.$b10.$f9."/is", $ab, $matches ))
  {
   $nf1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; 
 $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
   $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';


   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$a.$b7.$b9.$b11."/is", $ab, $matches ))
  {
   $nf5++;

  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf6++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf7++;
  
  }elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf8++;
  }
 

   $b1='(\d)'; $b2='(\\.)';$b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
    $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';
   
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
$nf9++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf10++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf11++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf12++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
    $p1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p4++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
   $q1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
    $q2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q4++;
  }


}

}




  


   $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(System)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(System)';$f8='(\\s+)';  $f9='(Requirements)';

  
  if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $text1, $matches  ))
  {
$d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
        $c3=$matches[6][0];


if ($ab=strstr($text1, "$d1$c1$d2$c2$d3$c3")){
$ab=strstr($text1, "$d1$c1$d2$c2$d3$c3");


$az=All($ab);
echo "$az";



 $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Functional)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Functional)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $ab, $matches  ))
  {

  
    $fu1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $ab, $matches)) {
    
     $fu2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {
 
  $fu3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {

  $fu4++;
  }

 $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7.$b10.$f9."/is", $ab, $matches ))
  {
   $nf1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; 
 $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
   $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';


   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$a.$b7.$b9.$b11."/is", $ab, $matches ))
  {
   $nf5++;

  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf6++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf7++;
  
  }elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf8++;
  }
 

   $b1='(\d)'; $b2='(\\.)';$b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
    $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';
   
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
$nf9++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf10++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf11++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf12++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
    $p1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p4++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
   $q1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
    $q2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q4++;
  }

}


}

 elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $text1, $matches)) {
$d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];


if ($ab=strstr($text1, "$d1$c1$d2$c2$d3")){
$ab=strstr($text1, "$d1$c1$d2$c2$d3");


$az=All($ab);
echo "$az";



 $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Functional)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Functional)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $ab, $matches  ))
  {

  
    $fu1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $ab, $matches)) {
    
     $fu2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {
 
  $fu3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {

  $fu4++;
  }

    $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7.$b10.$f9."/is", $ab, $matches ))
  {
   $nf1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; 
 $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
   $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';


   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$a.$b7.$b9.$b11."/is", $ab, $matches ))
  {
   $nf5++;

  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf6++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf7++;
  
  }elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf8++;
  }
 

   $b1='(\d)'; $b2='(\\.)';$b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
    $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';
   
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
$nf9++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf10++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf11++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf12++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
    $p1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p4++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
   $q1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
    $q2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q4++;
  }

} 
}
elseif ($c=preg_match_all ("/".$b1.$b2.$b4.$b8.$b9.$b5.$b6.$b7."/is", $text1, $matches  ))
  {
 $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
 $c3=$matches[6][0];
$d4=$matches[7][0];
 $c4=$matches[8][0];



if ($ab=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4$c4")){
$ab=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4$c4");
$az=All($ab);
echo "$az";


 $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Functional)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Functional)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $ab, $matches  ))
  {

  
    $fu1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $ab, $matches)) {
    
     $fu2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {
 
  $fu3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {

  $fu4++;
  }


 $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7.$b10.$f9."/is", $ab, $matches ))
  {
   $nf1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; 
 $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
   $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';


   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$a.$b7.$b9.$b11."/is", $ab, $matches ))
  {
   $nf5++;

  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf6++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf7++;
  
  }elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf8++;
  }
 

   $b1='(\d)'; $b2='(\\.)';$b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
    $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';
   
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
$nf9++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf10++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf11++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf12++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
    $p1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p4++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
   $q1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
    $q2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q4++;
  }


}
}


 elseif ($c=preg_match_all ("/".$b1.$b4.$b8.$b6.$b5.$b6.$b7."/is", $text1, $matches  )) {


  $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
       $c3=$matches[6][0];     
      $d4=$matches[7][0];


if ($ab=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4")){
$ab=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4");
$az=All($ab);
echo "$az";




 $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Functional)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Functional)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $ab, $matches  ))
  {

  
    $fu1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $ab, $matches)) {
    
     $fu2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {
 
  $fu3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {

  $fu4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7.$b10.$f9."/is", $ab, $matches ))
  {
   $nf1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; 
 $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
   $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';


   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$a.$b7.$b9.$b11."/is", $ab, $matches ))
  {
   $nf5++;

  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf6++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf7++;
  
  }elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf8++;
  }
 

   $b1='(\d)'; $b2='(\\.)';$b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
    $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';
   
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
$nf9++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf10++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf11++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf12++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
    $p1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p4++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
   $q1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
    $q2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q4++;
  }

}

}


   $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(System)';  # Word 1
  $b6='(\\s+)';  $b7='(Features)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(System)';$f8='(\\s+)';  $f9='(Features)';

if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $text1, $matches  ))
  {
 $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
 $c3=$matches[6][0];


if ($ab=strstr($text1, "$d1$c1$d2$c2$d3$c3")){
$ab=strstr($text1, "$d1$c1$d2$c2$d3$c3");

$az=All($ab);
echo "$az";


 $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Functional)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Functional)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $ab, $matches  ))
  {

  
    $fu1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $ab, $matches)) {
    
     $fu2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {
 
  $fu3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {

  $fu4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7.$b10.$f9."/is", $ab, $matches ))
  {
   $nf1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; 
 $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
   $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';


   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$a.$b7.$b9.$b11."/is", $ab, $matches ))
  {
   $nf5++;

  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf6++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf7++;
  
  }elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf8++;
  }
 

   $b1='(\d)'; $b2='(\\.)';$b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
    $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';
   
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
$nf9++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf10++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf11++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf12++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
    $p1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p4++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
   $q1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
    $q2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q4++;
  }

}


}
elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $text1, $matches)) {
 $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];



if ($ab=strstr($text1, "$d1$c1$d2$c2$d3")){
$ab=strstr($text1, "$d1$c1$d2$c2$d3");


$az=All($ab);
echo "$az";



 $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Functional)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Functional)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $ab, $matches  ))
  {

  
    $fu1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $ab, $matches)) {
    
     $fu2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {
 
  $fu3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {

  $fu4++;
  }



  $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7.$b10.$f9."/is", $ab, $matches ))
  {
   $nf1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; 
 $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
   $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';


   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$a.$b7.$b9.$b11."/is", $ab, $matches ))
  {
   $nf5++;

  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf6++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf7++;
  
  }elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf8++;
  }
 

   $b1='(\d)'; $b2='(\\.)';$b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
    $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';
   
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
$nf9++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf10++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf11++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf12++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
    $p1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p4++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
   $q1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
    $q2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q4++;
  }

}

 }
elseif ($c=preg_match_all ("/".$b1.$b2.$b4.$b8.$b9.$b5.$b6.$b7."/is", $text1, $matches  ))
  {
 $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
 $c3=$matches[6][0];
$d4=$matches[7][0];
 $c4=$matches[8][0];


if ($ab=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4$c4")){
$ab=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4$c4");
$az=All($ab);
echo "$az";


 $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Functional)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Functional)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $ab, $matches  ))
  {

  
    $fu1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $ab, $matches)) {
    
     $fu2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {
 
  $fu3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {

  $fu4++;
  }


  $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7.$b10.$f9."/is", $ab, $matches ))
  {
   $nf1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; 
 $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
   $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';


   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$a.$b7.$b9.$b11."/is", $ab, $matches ))
  {
   $nf5++;

  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf6++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf7++;
  
  }elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf8++;
  }
 

   $b1='(\d)'; $b2='(\\.)';$b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
    $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';
   
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
$nf9++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf10++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf11++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf12++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
    $p1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p4++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
   $q1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
    $q2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q4++;
  }

}
}


 elseif ($c=preg_match_all ("/".$b1.$b4.$b8.$b6.$b5.$b6.$b7."/is", $text1, $matches  )) {


  $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
       $c3=$matches[6][0];     
      $d4=$matches[7][0];


if ($ab=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4")){
$ab=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4");
$az=All($ab);
echo "$az";


 $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Functional)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Functional)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $ab, $matches  ))
  {

  
    $fu1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $ab, $matches)) {
    
     $fu2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {
 
  $fu3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {

  $fu4++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7.$b10.$f9."/is", $ab, $matches ))
  {
   $nf1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; 
 $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
   $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';


   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$a.$b7.$b9.$b11."/is", $ab, $matches ))
  {
   $nf5++;

  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf6++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf7++;
  
  }elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf8++;
  }
 

   $b1='(\d)'; $b2='(\\.)';$b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
    $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';
   
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
$nf9++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf10++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf11++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf12++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
    $p1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p4++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
   $q1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
    $q2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q4++;
  }

}

}
  


   $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Requirements)';  # Word 1
  $b6='(\\s+)';  $b7='(Specification)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Requirements)';$f8='(\\s+)';  $f9='(Specification)';


if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $text1, $matches  ))
  {
$d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
 $c3=$matches[6][0];

if ($ab=strstr($text1, "$d1$c1$d2$c2$d3$c3")){
$ab=strstr($text1, "$d1$c1$d2$c2$d3$c3");


$az=All($ab);
echo "$az";



 $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Functional)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Functional)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $ab, $matches  ))
  {

  
    $fu1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $ab, $matches)) {
    
     $fu2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {
 
  $fu3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {

  $fu4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7.$b10.$f9."/is", $ab, $matches ))
  {
   $nf1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; 
 $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
   $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';


   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$a.$b7.$b9.$b11."/is", $ab, $matches ))
  {
   $nf5++;

  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf6++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf7++;
  
  }elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf8++;
  }
 

   $b1='(\d)'; $b2='(\\.)';$b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
    $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';
   
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
$nf9++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf10++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf11++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf12++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
    $p1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p4++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
   $q1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
    $q2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q4++;
  }

}


}
 elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $text1, $matches)) {
$d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];


if ($ab=strstr($text1, "$d1$c1$d2$c2$d3")){
$ab=strstr($text1, "$d1$c1$d2$c2$d3");


$az=All($ab);
echo "$az";



 $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Functional)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Functional)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $ab, $matches  ))
  {

  
    $fu1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $ab, $matches)) {
    
     $fu2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {
 
  $fu3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {

  $fu4++;
  }


 $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7.$b10.$f9."/is", $ab, $matches ))
  {
   $nf1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; 
 $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
   $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';


   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$a.$b7.$b9.$b11."/is", $ab, $matches ))
  {
   $nf5++;

  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf6++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf7++;
  
  }elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf8++;
  }
 

   $b1='(\d)'; $b2='(\\.)';$b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
    $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';
   
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
$nf9++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf10++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf11++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf12++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
    $p1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p4++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
   $q1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
    $q2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q4++;
  }

    }

 }
 elseif ($c=preg_match_all ("/".$b1.$b2.$b4.$b8.$b9.$b5.$b6.$b7."/is", $text1, $matches  ))
  {
 $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
 $c3=$matches[6][0];
$d4=$matches[7][0];
 $c4=$matches[8][0];


if ($ab=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4$c4")){
$ab=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4$c4");
$az=All($ab);
echo "$az";




 $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Functional)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Functional)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $ab, $matches  ))
  {

  
    $fu1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $ab, $matches)) {
    
     $fu2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {
 
  $fu3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {

  $fu4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7.$b10.$f9."/is", $ab, $matches ))
  {
   $nf1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; 
 $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
   $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';


   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$a.$b7.$b9.$b11."/is", $ab, $matches ))
  {
   $nf5++;

  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf6++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf7++;
  
  }elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf8++;
  }
 

   $b1='(\d)'; $b2='(\\.)';$b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
    $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';
   
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
$nf9++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf10++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf11++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf12++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
    $p1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p4++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
   $q1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
    $q2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q4++;
  }

}
}


 elseif ($c=preg_match_all ("/".$b1.$b4.$b8.$b6.$b5.$b6.$b7."/is", $text1, $matches  )) {


  $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
       $c3=$matches[6][0];     
      $d4=$matches[7][0];


if ($ab=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4")){
$ab=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4");
$az=All($ab);
echo "$az";



 $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Functional)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Functional)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $ab, $matches  ))
  {

  
    $fu1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $ab, $matches)) {
    
     $fu2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {
 
  $fu3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $ab, $matches)) {

  $fu4++;
  }

 $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7.$b10.$f9."/is", $ab, $matches ))
  {
   $nf1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab, $matches)) {
  $nf4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; 
 $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
   $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';


   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$a.$b7.$b9.$b11."/is", $ab, $matches ))
  {
   $nf5++;

  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf6++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf7++;
  
  }elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf8++;
  }
 

   $b1='(\d)'; $b2='(\\.)';$b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
    $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';
   
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
$nf9++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
    $nf10++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf11++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab, $matches)) {
   $nf12++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
    $p1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $p4++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab, $matches  ))
  {
   $q1++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab, $matches)) {
    $q2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab, $matches)) {
   $q4++;
  }

}

}
 

$j1=0;$j2=0;$j3=0;$j4=0;$j5=0;$j6=0;$j7=0;$j8=0;$j9=0;$j10=0;$j11=0;$j12=0;$j13=0;$j14=0;$j15=0;$j16=0;$j17=0;$j18=0;$j19=0; $j20=0;
$j21=0;$j22=0;$j23=0;$j24=0;$j25=0;$j26=0;$j27=0;$j28=0;$j29=0;$j30=0;$j31=0;$j32=0;$j33=0;$j34=0;$j35=0;$j36=0;$j37=0;$j38=0;$j39=0; $j40=0;

$j41=0;$j42=0;$j43=0;$j44=0;$j45=0;$j46=0;$j47=0;$j48=0;$j49=0;$j50=0;$j51=0;$j52=0;$j53=0;$j54=0;$j55=0;$j56=0;$j57=0;$j58=0;$j59=0; $j60=0;
$j61=0;$j62=0;$j63=0;$j64=0;$j65=0;$j66=0;$j67=0;$j68=0;$j69=0;$j70=0;$j71=0;$j72=0;$j73=0;$j74=0;$j75=0;$j76=0;$j77=0;$j78=0;$j79=0; $j80=0;

$j81=0;$j82=0;$j83=0;$j84=0;$j85=0;$j86=0;$j87=0;$j88=0;$j89=0;$j90=0;$j91=0;$j92=0;$j93=0;$j94=0;$j95=0;$j96=0;$j97=0;$j98=0;$j99=0;

 $b1='(\d)'; $b2='(\\.)';

   $b4='(\\s+)';   $b5='(Functional)';  # Word 1
  $b6='(\\s+)';  $b7='(Requirements)'; $b8='(The)';$b9='(\\s+)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Functional)';$f8='(\\s+)';  $f9='(Requirements)';




   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7."/is", $text1, $matches  ))
  {
   

 if ($fu1 == 0) {


      $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
       $c3=$matches[6][0];     
    
 

if ($ab=strstr($text1, "$d1$c1$d2$c2$d3$c3")){
$ab1=strstr($text1, "$d1$c1$d2$c2$d3$c3");
$az=All($ab1);
echo "$az";



   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7.$b10.$f9."/is", $ab1, $matches ))
  {
   $j1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab1, $matches)) {
  $j3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab1, $matches)) {
  $j4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; 
 $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
   $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';


   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$a.$b7.$b9.$b11."/is", $ab1, $matches ))
  {
   $j5++;

  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$a.$b7.$b10.$f9."/is", $ab1, $matches)) {
    $j6++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j7++;
 
  }elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j8++;
  }
 

   $b1='(\d)'; $b2='(\\.)';$b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
    $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';
   
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
$j9++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$b7.$b10.$f9."/is", $ab1, $matches)) {
    $j10++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j11++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j12++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
    $j13++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j14++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j15++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j16++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
   $j17++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
    $j18++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j19++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j20++;
  }



}



 }

 
 else{
echo ".";
 }


  } 


 elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$f9."/is", $text1, $matches)) {
 
 
 if ($fu2 ==0) {

      $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
    
    
 

if ($ab=strstr($text1, "$d1$c1$d2$c2$d3")){
$ab1=strstr($text1, "$d1$c1$d2$c2$d3");
$az=All($ab1);
echo "$az";




   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7.$b10.$f9."/is", $ab1, $matches ))
  {
   $j1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab1, $matches)) {
  $j3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab1, $matches)) {
  $j4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; 
 $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
   $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';


   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$a.$b7.$b9.$b11."/is", $ab1, $matches ))
  {
   $j5++;

  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$a.$b7.$b10.$f9."/is", $ab1, $matches)) {
    $j6++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j7++;
 
  }elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j8++;
  }
 

   $b1='(\d)'; $b2='(\\.)';$b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
    $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';
   
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
$j9++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$b7.$b10.$f9."/is", $ab1, $matches)) {
    $j10++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j11++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j12++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
    $j13++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j14++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j15++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j16++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
   $j17++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
    $j18++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j19++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j20++;
  }

}

 }

 
 else{
echo ".";
 }


}elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$f9."/is", $text1, $matches)) {

 
 if ($fu3 == 0) {

      $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
      $c3=$matches[6][0];     
      $d4=$matches[7][0];
    
 

if ($ab=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4")){
$ab1=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4");
$az=All($ab1);
echo "$az";



   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7.$b10.$f9."/is", $ab1, $matches ))
  {
   $j1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab1, $matches)) {
  $j3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab1, $matches)) {
  $j4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; 
 $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
   $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';


   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$a.$b7.$b9.$b11."/is", $ab1, $matches ))
  {
   $j5++;

  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$a.$b7.$b10.$f9."/is", $ab1, $matches)) {
    $j6++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j7++;
 
  }elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j8++;
  }
 

   $b1='(\d)'; $b2='(\\.)';$b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
    $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';
   
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
$j9++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$b7.$b10.$f9."/is", $ab1, $matches)) {
    $j10++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j11++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j12++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
    $j13++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j14++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j15++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j16++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
   $j17++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
    $j18++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j19++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j20++;
  }

}


 }

 
 else{
echo ".";
 }
}

elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$f9."/is", $text1, $matches)) {
    
 
 if ($fu4 == 0) {

  
     
      $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
      $c3=$matches[6][0];     
      $d4=$matches[7][0];
    $c4=$matches[8][0];
 

if ($ab=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4$c4")){
$ab=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4$c4");
$az=All($ab);
echo "$az";

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7.$b10.$f9."/is", $ab1, $matches ))
  {
   $j1++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j2++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab1, $matches)) {
  $j3++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $ab1, $matches)) {
  $j4++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; 
 $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
   $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';


   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$a.$b7.$b9.$b11."/is", $ab1, $matches ))
  {
   $j5++;

  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$a.$b7.$b10.$f9."/is", $ab1, $matches)) {
    $j6++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j7++;
 
  }elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j8++;
  }
 

   $b1='(\d)'; $b2='(\\.)';$b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
    $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';
   
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
$j9++;
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$b7.$b10.$f9."/is", $ab1, $matches)) {
    $j10++;

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j11++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j12++;
  }

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
    $j13++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j14++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j15++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j16++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
   $j17++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
    $j18++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j19++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j20++;
  }

}


 }

 
 else{
echo ".";
 }
}




$k1=0;$k2=0;$k3=0;$k4=0;$k5=0;$k6=0;$k7=0;$k8=0;$k9=0;$k10=0;$k11=0;$k12=0;$k13=0;$k14=0;$k15=0;$k16=0;$k17=0;$k18=0;$k19=0; $k20=0;
$k21=0;$k22=0;$k23=0;$k24=0;$k25=0;$k26=0;$k27=0;$k28=0;$k29=0;$k30=0;$k31=0;$k32=0;$k33=0;$k34=0;$k35=0;$k36=0;$k37=0;$k38=0;$k39=0; $k40=0;




   $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Non)';  # Word 1
  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)'; 
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b6.$b7.$b10.$f9."/is", $text1, $matches ))
  {
  
 
 if ($nf1 == 0) {
    if ($j1 ==0) {
    

  
      $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
      $c3=$matches[6][0];     
      $d4=$matches[7][0];
     $c4=$matches[8][0];
 

if ($ab=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4$c4")){
$ab1=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4$c4");
$az=All($ab1);
echo "$az";


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
    $j13++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j14++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j15++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j16++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
   $j17++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
    $j18++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j19++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j20++;
  }

}
}

}

 else{
echo ".";
 }

  } 
  elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$f8.$b7.$b10.$f9."/is", $text1, $matches)) {
   

 
 if ($nf2 == 0) {
if ($j2 ==0) {
  
      $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
      $c3=$matches[6][0];     
      $d4=$matches[7][0];
     
 

if ($ab=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4")){
$ab1=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4");
$az=All($ab1);
echo "$az";


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
    $j13++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j14++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j15++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j16++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
   $j17++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
    $j18++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j19++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j20++;
  }
}
}
}

 else{
echo ".";
 }

  }
elseif  ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $text1, $matches)) {
  

 if ($nf3 == 0) {
if ($j3 ==0) {
  
      $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
      $c3=$matches[6][0];     
      $d4=$matches[7][0];
      $c4=$matches[8][0];     
      $d5=$matches[9][0];

if ($ab=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4$c4$d5")){
$ab1=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4$c4$d5");
$az=All($ab1);
echo "$az";


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
    $j13++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j14++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j15++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j16++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
   $j17++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
    $j18++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j19++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j20++;
  }
}
}
}
 
 else{
echo ".";
 }

  } elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$f8.$b7.$b10.$f9."/is", $text1, $matches)) {


 if ($nf4 == 0) {
if ($j4 ==0) {
  
      $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
      $c3=$matches[6][0];     
      $d4=$matches[7][0];
     
 $c4=$matches[8][0];     
      $d5=$matches[9][0];
$c5=$matches[10][0];


if ($ab=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4$c4$d5$c5")){
$ab1=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4$c4$d5$c5");
$az=All($ab1);
echo "$az";


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
    $j13++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j14++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j15++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j16++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
   $j17++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
    $j18++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j19++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j20++;
  }
}
}
}
 
 else{
echo "already";
 }
  }



   $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Non)';  # Word 1 

  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

 $spe=0;
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$a.$b7.$b9.$b11."/is", $text1, $matches ))
  {
   
 if ($nf5 == 0) {
if ($j5 ==0) {
  
      $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
      $c3=$matches[6][0];     
      $d4=$matches[7][0];
     
 $c4=$matches[8][0];     
      


if ($ab=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4$c4")){
$ab1=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4$c4");
$az=All($ab1);
echo "$az";


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
    $j13++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j14++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j15++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j16++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
   $j17++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
    $j18++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j19++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j20++;
  }
}
}
}
 
 else{
echo ".";
 }


  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$a.$b7.$b10.$f9."/is", $text1, $matches)) {


 if ($nf6 == 0) {
if ($j6 ==0) {
  
      $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
      $c3=$matches[6][0];     
      $d4=$matches[7][0];
     
 

if ($ab=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4")){
$ab1=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4");
$az=All($ab1);
echo "$az";


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
    $j13++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j14++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j15++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j16++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
   $j17++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
    $j18++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j19++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j20++;
  }
}
}
}
 else{
echo ".";
 }


  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $text1, $matches)) {

 if ($nf7 == 0) {
if ($j7 ==0) {
  
      $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
      $c3=$matches[6][0];     
      $d4=$matches[7][0];
     
 $c4=$matches[8][0];     
      $d5=$matches[9][0];



if ($ab=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4$c4$d5")){
$ab1=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4$c4$d5");
$az=All($ab1);
echo "$az";

   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
    $j13++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j14++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j15++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j16++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
   $j17++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
    $j18++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j19++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j20++;
  }
}
}
}
 
 else{
echo ".";
 }
  
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$a.$b7.$b10.$f9."/is", $text1, $matches)) {

 if ($nf8 == 0) {
if ($j8 ==0) {
  
      $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
      $c3=$matches[6][0];     
      $d4=$matches[7][0];
     
 $c4=$matches[8][0];     
      $d5=$matches[9][0];
$c5=$matches[10][0];


if ($ab=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4$c4$d5$c5")){
$ab1=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4$c4$d5$c5");
$az=All($ab1);
echo "$az";


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
    $j13++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j14++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j15++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j16++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
   $j17++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
    $j18++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j19++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j20++;
  }
}
}
}
 
 else{
echo ".";
 }
  }
 


   $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Non)';  # Word 1 

  $b6='(\\s+)';  $b7='(Functional)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';
   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b5.$b7.$b9.$b11."/is", $text1, $matches  ))
  {


 if ($nf9 == 0) {
if ($j9 ==0) {
  
      $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
      $c3=$matches[6][0];     
      $d4=$matches[7][0];
     
 

if ($ab=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4")){
$ab1=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4");
$az=All($ab1);
echo "$az";


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
    $j13++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j14++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j15++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j16++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
   $j17++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
    $j18++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j19++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j20++;
  }
}
}
}
 else{
echo ".";
 }


  } elseif ($ac=preg_match_all ("/".$f3.$f6.$f7.$b7.$b10.$f9."/is", $text1, $matches)) {
  

 if ($nf10 == 0) {
if ($j10 ==0) {
  
      $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
      $c3=$matches[6][0];     
    
     
 

if ($ab=strstr($text1, "$d1$c1$d2$c2$d3$c3")){
$ab1=strstr($text1, "$d1$c1$d2$c2$d3$c3");
$az=All($ab1);
echo "$az";


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
    $j13++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j14++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j15++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j16++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
   $j17++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
    $j18++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j19++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j20++;
  }
}
}
}
 
 else{
echo ".";
 }


  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $text1, $matches)) {
   


 if ($nf11 == 0) {
if ($j11 ==0) {
  
      $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
      $c3=$matches[6][0];     
      $d4=$matches[7][0];
     $c4=$matches[8][0];
 

if ($ab=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4$c4")){
$ab1=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4$c4");
$az=All($ab1);
echo "$az";


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
    $j13++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j14++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j15++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j16++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
   $j17++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
    $j18++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j19++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j20++;
  }
}
}
}
 
 else{
echo ".";
 }

  }
 elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$f7.$b7.$b10.$f9."/is", $text1, $matches)) {
 

 if ($nf12 == 0) {
if ($j12 ==0) {
  
      $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
      $c3=$matches[6][0];     
      $d4=$matches[7][0];
     $c4=$matches[8][0];
 $d5=$matches[9][0];

if ($ab=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4$c4$d5")){
$ab1=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4$c4$d5");
$az=All($ab1);
echo "$az";


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)';  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  
   $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
    $j13++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j14++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j15++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j16++;
  }


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
   $j17++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
    $j18++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j19++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j20++;
  }
}
}
}
 
 else{
echo ".";
 }
  }
 
/////////////////////// non functionals end//////////////////////

  
$y1=0;$y2=0;$y3=0;$y4=0;$y5=0;$y6=0;$y7=0;$y8=0;$y9=0;$y10=0;$y11=0;$y12=0;$y13=0;$y14=0;$y15=0;$y16=0;$y17=0;$y18=0;$y19=0;$y20=0;$y21=0;$y22=0;$y23=0;

   $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Non)';  # Word 1 

  $b6='(\\s+)';  $b7='(Performance)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $text1, $matches  ))
  {


 if ($p1 == 0) {
if (($j13 AND $j14 AND $j15 AND $j16) > 0) {
 

      $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
      $c3=$matches[6][0];     
   

if ($ab=strstr($text1, "$d1$c1$d2$c2$d3$c3")){
$ab1=strstr($text1, "$d1$c1$d2$c2$d3$c3");
$az=All($ab1);
echo "$az";


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
   $j17++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
    $j18++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j19++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j20++;
  }
}
} 
}
 
 else{
echo " ";
 }


  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $text1, $matches)) {
 


 if ($p2 == 0) {
if (($j13 AND $j14 AND $j15 AND $j16) > 0) {
  
      $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
      

if ($ab=strstr($text1, "$d1$c1$d2$c2$d3")){
$ab1=strstr($text1, "$d1$c1$d2$c2$d3");
$az=All($ab1);
echo "$az";


   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
   $j17++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
    $j18++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j19++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j20++;
  }
}
}
}
 
 
 else{
echo ".";
 }

  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $text1, $matches)) {
   


 if ($p3 == 0) {

  if (($j13 AND $j14 AND $j15 AND $j16) > 0) {
      $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
      $c3=$matches[6][0];     
      $d4=$matches[7][0];
    

if ($ab=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4")){
$ab1=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4");
$az=All($ab1);
echo "$az";



   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
   $j17++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
    $j18++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j19++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j20++;
  }
}
}
}
 

 else{
echo ".";
 }
  }
 elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $text1, $matches)) {
   


 if ($p4 == 0) {
if (($j13 AND $j14 AND $j15 AND $j16) > 0) {
  
      $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
      $c3=$matches[6][0];     
      $d4=$matches[7][0];
     $c4=$matches[8][0];


if ($ab=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4$c4")){
$ab1=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4$c4");
$az=All($ab1);
echo "$az";



   $b1='(\d)'; $b2='(\\.)'; $b4='(\\s+)';   $b5='(Non)'; $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)';
    $b11='(Requirements)';  $a='(-)'; $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $ab1, $matches  ))
  {
   $j17++;
   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $ab1, $matches)) {
    $j18++;
  }elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j19++;
  }
  elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $ab1, $matches)) {
   $j20++;
  }
}
}
}
 
 else{
echo ".";
 }
  }

  


   $b1='(\d)'; $b2='(\\.)';
   $b4='(\\s+)';   $b5='(Non)';  # Word 1 

  $b6='(\\s+)';  $b7='(Quality)'; $b8='(The)';$b9='(\\s+)'; $b10='(\\s+)'; $b11='(Requirements)';  $a='(-)';
  
 $f2='(\\.)';   $f3='(\d)'; $f6='(\\s+)';  $f7='(Non)';$f8='(\\s+)';  $f9='(Requirements)';

   if ($c=preg_match_all ("/".$b1.$b2.$b4.$b7.$b9.$b11."/is", $text1, $matches  ))
  {



 if ($q1 == 0) {
if (($j17 AND $j18 AND $j19 AND $j20) > 0) {
  
      $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
      $c3=$matches[6][0];     
    


if ($ab=strstr($text1, "$d1$c1$d2$c2$d3$c3")){
$ab1=strstr($text1, "$d1$c1$d2$c2$d3$c3");
$az=All($ab1);
echo "$az";
}
}
 }
 
 else{
echo " ";
 }

   
  } elseif ($ac=preg_match_all ("/".$f3.$f6.$b7.$b10.$f9."/is", $text1, $matches)) {
    


 if ($q2 == 0) {
if (($j17 AND $j18 AND $j19 AND $j20) > 0) {
  
      $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
      


if ($ab=strstr($text1, "$d1$c1$d2$c2$d3")){
$ab1=strstr($text1, "$d1$c1$d2$c2$d3");
$az=All($ab1);
echo "$az";
}
}
}
 
 else{
echo " ";
 }

  }
  elseif ($ad=preg_match_all ("/".$f3.$f6.$b8.$b9.$b7.$b10.$f9."/is", $text1, $matches)) {

 if ($q3 == 0) {

  if (($j17 AND $j18 AND $j19 AND $j20) > 0) {
      $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
      $c3=$matches[6][0];     
      $d4=$matches[7][0];
     


if ($ab=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4")){
$ab1=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4");
$az=All($ab1);
echo "$az";
}
}
 }
 else{
echo " ";
 }

  }
elseif ($ad=preg_match_all ("/".$f3.$f2.$f6.$b8.$b9.$b7.$b10.$f9."/is", $text1, $matches)) {
  



 if ($q4 == 0) {
if (($j17 AND $j18 AND $j19 AND $j20) > 0) {
  
      $d1=$matches[1][0];
      $c1=$matches[2][0];
      $d2=$matches[3][0];
      $c2=$matches[4][0];     
      $d3=$matches[5][0];
      $c3=$matches[6][0];     
      $d4=$matches[7][0];
      $c4=$matches[8][0];


if ($ab=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4$c4")){
$ab1=strstr($text1, "$d1$c1$d2$c2$d3$c3$d4$c4");
$az=All($ab1);
echo "$az";
}
}
}
   else{
echo " ";
 }

  }

  

}






?>