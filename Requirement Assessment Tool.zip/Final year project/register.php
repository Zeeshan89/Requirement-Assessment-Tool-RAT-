<?php
	ob_start();
	session_start();
	if( isset($_SESSION['user'])!="" ){
		header("Location: all.php");
	}
	include_once 'database1.php';

	$error = false;

	if ( isset($_POST['btn-signup']) ) {
		
		// clean user inputs to prevent sql injections
		$name = trim($_POST['name']);
		$name = strip_tags($name);
		$name = htmlspecialchars($name);
		
		$email = trim($_POST['email']);
		$email = strip_tags($email);
		$email = htmlspecialchars($email);


      $con = trim($_POST['phone']);
        $con = strip_tags($con);
        $con = htmlspecialchars($con);
    
		
		$pass = trim($_POST['pass']);
		$pass = strip_tags($pass);
		$pass = htmlspecialchars($pass);


		// basic name validation
		if (empty($name)) {
			$error = true;
			$nameError = "Please enter your full name.";
		} else if (strlen($name) < 3) {
			$error = true;
			$nameError = "Name must have atleat 3 characters.";
		} else if (!preg_match("/^[a-zA-Z ]+$/",$name)) {
			$error = true;
			$nameError = "Name must contain alphabets and space.";
		}
		
		//basic email validation
		if ( !filter_var($email,FILTER_VALIDATE_EMAIL) ) {
			$error = true;
			$emailError = "Please enter valid email address.";
		} else {
			// check email exist or not
			$query = "SELECT userEmail FROM users WHERE userEmail='$email'";
			$result = mysqli_query($connection,$query);
			$count = mysqli_num_rows($result);
			if($count!=0){
				$error = true;
				$emailError = "Provided Email is already in use.";
			}
		}
////contact////////////////

if (empty($con)) {
            $error = true;
            $phoneError = "Please enter your phone number.";
        } else if (strlen($con) < 8) {           
         $error = true;
            $phoneError = "Phone number must be valid.";
        } else if (!preg_match("/([0-9]{10})|(\([0-9]{3}\)\s+[0-9]{3}\-[0-9]{4})/",$con)) {
            $error = true;
            $phoneError = "Phone number must contain digits.";
        }


		// password validation
		if (empty($pass)){
			$error = true;
			$passError = "Please enter password.";
		} else if(strlen($pass) < 6) {
			$error = true;
			$passError = "Password must have atleast 6 characters.";
		}
		
		// password encrypt using SHA256();
		$password = hash('sha256', $pass);


  
		
		// if there's no error, continue to signup
		if( !$error ) {
			
			$query = "INSERT INTO users(userName,userEmail,contact,userPass,datet) VALUES('$name','$email','$con','$password', now())";
			$res = mysqli_query($connection,$query);
				
			if ($res) {
				$errTyp = "success";
				$errMSG = "Successfully registered, you may login now";
				unset($name);
				unset($email);
        unset($con);
				unset($pass);
			} else {
				$errTyp = "danger";
				$errMSG = "Something went wrong, try again later...";	
			}	
				
		}
		
		
	}
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>User Registration</title>

  <link rel="stylesheet" type="text/css" href="assets/css/bootstrap.css">
<link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">
<script type="text/javascript" src="assets/jquery/jquery.validate.js"></script>
<script type="text/javascript" src="assets/jquery/jquery-3.2.1.min.js"></script>
<style >
  body{

  font-family: 'Droid Sans', sans-serif;
  font-size:100%;
 
  background-repeat: no-repeat;
  background-attachment: fixed;
  background-position: center;
  background-size: cover;
}
img{max-width:100%;}


  .main {
    width: 60%;
    margin: 0 auto;
  }
  

</style>
</head>
<body background="12345.jpeg">


<script type="text/javascript" src="assets/jquery/jquery.validate.min.js"></script>

  <script type="text/javascript">
    $().ready(function() {
        $("#form").validate(
        
        {

            rules : {

                name : {

                  required : true,
                    minlength : 4,
                    maxlength : 15,
             		
                },
                email : {
                    required : true,
                    email : true
                },
                phone : {
                    required : true,
                    minlength:9,
                     maxlength:17,
                    phoneUS: true
                    
                },
                pass : {
                    required : true,
                    minlength : 6,
                    maxlength : 20,
                    
                }
            },
            messages: {
                name: "Name must contain alphabets and space",
                phone: {
                   required: "Enter your contact number",
                    minlength: "Contact must have atleat 9 digits",
                    maxlength: "contact length must be valid"
                 },
               // email: "Enter valid email"
           },
            submitHandler: function(form) {
                form.submit();
            },
             errorElement: "div",
    wrapper: "div",
    errorPlacement: function(error, element) {
        offset = element.offset();
        error.insertAfter(element)
        error.css('color','red');
        error.css('font-size','14px');
    }
        });
        jQuery.validator.addMethod("phoneUS", function (phone_number, element) {
            //////replacing spaces in number/////////
            phone_number = phone_number.replace(/\s+/g, "");
            return this.optional(element) || phone_number.length > 9 &&
                  phone_number.match(/\(?([0-9]{3})\)?([ .-]?)([0-9]{3})\2([0-9]{4})/);
        }, "Invalid phone number");


    });
</script>

<style>
  #form input.error {
    color: red;
    font-weight: bold;
  }
  .main {
    width: 60%;
    margin: 0 auto;
    padding-left: 70px;
  }
  span a{
    color: #fff;
}
.z:hover{
    color:orange;
}
</style>
<div class="container">
<h1 style="color:white; font-weight: bold; " align="center">Requirement Assessment Tool</h1>


	<div id="login-form" class="main">
    <form method="post" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" autocomplete="off" id="form">
    
    	<div class="col-md-9" style=" margin-top: 30px;">
        
        	<div class="form-group">
            	<h2  style="color:#fff;">Sign Up.</h2>
            </div>
        
        	<div class="form-group">
            	<hr />
            </div>
            
            <?php
			if ( isset($errMSG) ) {
				
				?>
				<div class="form-group">
            	<div class="alert alert-<?php echo ($errTyp=="success") ? "success" : $errTyp; ?>">
				<span class="glyphicon glyphicon-info-sign"></span> <?php echo $errMSG; ?>
                </div>
            	</div>
                <?php
			}
			?>
            
            <div class="form-group">
            	<div class="input-group">
                <span class="input-group-addon"><span class="glyphicon glyphicon-user"></span></span>
            	<input type="text" name="name"  class="form-control" placeholder="Enter Name" maxlength="50" value="<?php echo $name ?>" />
                </div>
                <span class="text-danger"><?php echo $nameError; ?></span>
            </div>
            
            <div class="form-group">
            	<div class="input-group">
                <span class="input-group-addon"><span class="glyphicon glyphicon-envelope"></span></span>
            	<input type="email" name="email" class="form-control" placeholder="Enter Your Email" maxlength="40" value="<?php echo $email ?>" />
                </div>
                <span class="text-danger"><?php echo $emailError; ?></span>
            </div>
            
            
                <div class="form-group">
                <div class="input-group">
                <span class="input-group-addon"><span class="glyphicon glyphicon-phone"></span></span>
                <input type="text" name="phone" class="form-control" placeholder="Enter valid phone no" maxlength="17" value="<?php echo $con ?>" />
                </div>
                <span class="text-danger"><?php echo $phoneError; ?></span>
                
            </div>

            <div class="form-group">
            	<div class="input-group">
                <span class="input-group-addon"><span class="glyphicon glyphicon-lock"></span></span>
            	<input type="password" name="pass" class="form-control" placeholder="Enter Password" maxlength="15" />
                </div>
                <span class="text-danger"><?php echo $passError; ?></span>
            </div>
            
            <div class="form-group">
            	<hr />
            </div>
            
            <div class="form-group">
            	<button type="submit" class="btn btn-block btn-primary" name="btn-signup">Sign Up</button>
            </div>
            
            <div class="form-group">
            	<hr />
            </div>
            
            
            <div class="form-group ">
            <span style="font-size:20px;" > <a href="index.php"  class="z" >Sign in Here...</a></span>
            </div>
        
        
        </div>
   
    </form>
    </div>	

</div>

</body>
</html>
<?php ob_end_flush(); ?>