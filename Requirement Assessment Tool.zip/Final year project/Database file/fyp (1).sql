-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Mar 28, 2018 at 06:54 AM
-- Server version: 10.1.9-MariaDB
-- PHP Version: 5.6.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `fyp`
--

-- --------------------------------------------------------

--
-- Table structure for table `all_words`
--

CREATE TABLE `all_words` (
  `id` int(10) NOT NULL,
  `title` text NOT NULL,
  `words` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `all_words`
--

INSERT INTO `all_words` (`id`, `title`, `words`) VALUES
(1, 'Imperatives', 'shall'),
(2, 'Imperatives', 'must'),
(3, 'Imperatives', 'required to'),
(4, 'Imperatives', 'are applicable'),
(5, 'Imperatives', 'are too'),
(6, 'Imperatives', 'responsible for'),
(7, 'Imperatives', 'will'),
(8, 'Negative imperatives', 'shall not'),
(9, 'Negative imperatives', 'must not'),
(10, 'Negative imperatives', 'is not required to'),
(11, 'Negative imperatives', 'are not applicable'),
(12, 'Negative imperatives', 'are not to'),
(13, 'Negative imperatives', ' not responsible for '),
(14, 'Negative imperatives', ' will not '),
(15, 'Negative imperatives', 'should not'),
(16, 'Options', ' can '),
(17, 'Options', ' may '),
(18, 'Options', ' optionally '),
(19, 'Options', ' should '),
(21, 'Universal quantifiers', 'always'),
(22, 'Universal quantifiers', ' any '),
(23, 'Universal quantifiers', 'every'),
(24, 'Universal quantifiers', ' no '),
(25, 'Universal quantifiers', 'never'),
(26, 'Universal quantifiers', 'none'),
(27, 'Universal quantifiers', 'nothing'),
(28, 'Universal quantifiers', ' each '),
(29, 'Universal quantifiers', ' many '),
(30, 'Universal quantifiers', 'most'),
(31, 'Universal quantifiers', 'often'),
(32, 'Universal quantifiers', 'usually'),
(33, 'Directives', 'e.g.'),
(34, 'Directives', 'i.e.'),
(35, 'Directives', 'for example'),
(36, 'Directives', ' figure '),
(37, 'Directives', ' table '),
(38, 'Directives', 'note:'),
(39, 'Continuances', 'below:'),
(40, 'Continuances', 'as follow:'),
(41, 'Continuances', 'following:'),
(42, 'Continuances', 'listed:'),
(43, 'Continuances', 'in particular:'),
(44, 'Continuances', 'supported:'),
(45, 'Continuances', 'and'),
(47, 'Vagues', 'adequate'),
(48, 'Vagues', 'adequately'),
(49, 'Vagues', ' all '),
(50, 'Vagues', 'appropriate'),
(51, 'Vagues', 'as appropriate'),
(52, 'Vagues', 'as big'),
(53, 'Vagues', 'as possible'),
(54, 'Vagues', 'as required'),
(55, 'Vagues', 'as small'),
(56, 'Vagues', 'as soon as possible'),
(57, 'Vagues', 'at a given time'),
(58, 'Vagues', 'bad'),
(59, 'Vagues', ' be able to '),
(60, 'Vagues', ' be capable of '),
(61, 'Vagues', 'beautifull'),
(62, 'Vagues', 'better'),
(63, 'Vagues', 'beautiful'),
(64, 'Vagues', 'capability of'),
(65, 'Vagues', 'capability to'),
(66, 'Vagues', 'completely'),
(67, 'Vagues', 'consistent with'),
(68, 'Vagues', 'correct'),
(69, 'Vagues', 'correctly'),
(70, 'Vagues', 'currently'),
(71, 'Vagues', 'custom'),
(72, 'Vagues', 'customize'),
(73, 'Vagues', 'customized'),
(74, 'Vagues', 'customizing'),
(75, 'Vagues', 'easy'),
(76, 'Vagues', 'easily'),
(77, 'Vagues', ' effective '),
(78, 'Vagues', ' efficient '),
(79, 'Vagues', ' efficiently '),
(80, 'Vagues', 'enough'),
(81, 'Vagues', 'etc'),
(82, 'Vagues', 'every'),
(83, 'Vagues', 'faithfully'),
(84, 'Vagues', 'far'),
(85, 'Vagues', 'fast'),
(86, 'Vagues', 'flexible'),
(87, 'Vagues', 'formerly'),
(88, 'Vagues', 'good'),
(89, 'Vagues', ' harmonious '),
(90, 'Vagues', 'immediately'),
(91, 'Vagues', 'improved'),
(92, 'Vagues', 'improving'),
(93, 'Vagues', 'in mind'),
(94, 'Vagues', 'in the past'),
(95, 'Vagues', 'instantly'),
(96, 'Vagues', ' it '),
(97, 'Vagues', 'judiciously'),
(98, 'Vagues', 'lately'),
(99, 'Vagues', 'later'),
(100, 'Vagues', 'legible'),
(101, 'Vagues', 'leverage'),
(102, 'Vagues', 'maximal'),
(103, 'Vagues', 'maximize'),
(104, 'Vagues', 'maximise'),
(105, 'Vagues', 'maximized'),
(106, 'Vagues', 'maximizing'),
(107, 'Vagues', 'meaningful'),
(108, 'Vagues', 'minimal'),
(109, 'Vagues', 'minimise'),
(110, 'Vagues', 'minimize'),
(111, 'Vagues', 'minimized'),
(112, 'Vagues', 'minimizing'),
(113, 'Vagues', 'normal'),
(114, 'Vagues', 'not limited to'),
(115, 'Vagues', ' optimal '),
(116, 'Vagues', 'precise'),
(117, 'Vagues', 'presently'),
(118, 'Vagues', 'promptly'),
(119, 'Vagues', ' proper '),
(120, 'Vagues', 'provide for'),
(121, 'Vagues', 'quickly'),
(122, 'Vagues', 'readily'),
(123, 'Vagues', 'realistic'),
(124, 'Vagues', 'realistically'),
(125, 'Vagues', ' reasonable '),
(126, 'Vagues', ' reasonably '),
(127, 'Vagues', 'recent'),
(128, 'Vagues', 'recently'),
(129, 'Vagues', 'reflect'),
(130, 'Vagues', 'represent'),
(131, 'Vagues', ' representable '),
(132, 'Vagues', 'representative'),
(133, 'Vagues', 'seamless'),
(134, 'Vagues', 'seamlessly'),
(135, 'Vagues', 'significant'),
(136, 'Vagues', 'significantly'),
(137, 'Vagues', 'similar'),
(138, 'Vagues', 'similarly'),
(139, 'Vagues', 'simple'),
(140, 'Vagues', 'simplified'),
(141, 'Vagues', 'simultaneous'),
(142, 'Vagues', 'smoothly'),
(143, 'Vagues', 'some'),
(144, 'Vagues', ' standard '),
(145, 'Vagues', 'strong'),
(146, 'Vagues', 'such as'),
(147, 'Vagues', 'sufficient'),
(148, 'Vagues', 'sufficiently'),
(149, 'Vagues', ' suitable '),
(150, 'Vagues', 'take into account'),
(151, 'Vagues', 'take into consideration'),
(152, 'Vagues', 'TBC'),
(153, 'Vagues', 'TBD'),
(154, 'Vagues', 'timely'),
(155, 'Vagues', 'to date'),
(156, 'Vagues', ' tolerable '),
(157, 'Vagues', 'typical'),
(158, 'Vagues', 'universal'),
(159, 'Vagues', 'up to'),
(160, 'Vagues', 'useful'),
(161, 'Vagues', 'usefully'),
(162, 'Vagues', 'usefull'),
(163, 'Vagues', 'user friendly'),
(164, 'Vagues', 'versatile'),
(165, 'Vagues', 'widely'),
(166, 'Vagues', 'worse'),
(167, 'Vagues', 'year ago'),
(168, 'Vagues', ' or '),
(169, 'Negative imperatives', 'not most'),
(170, 'Negative imperatives', 'not required'),
(171, 'Negative imperatives', 'not applicable'),
(172, 'Negative imperatives', 'are not'),
(173, 'Negative imperatives', 'not responsible'),
(174, 'Vagues', 'number of times'),
(175, 'Vagues', 'big'),
(176, 'Vagues', 'possible'),
(177, 'Vagues', ' able to ');

-- --------------------------------------------------------

--
-- Table structure for table `continuances`
--

CREATE TABLE `continuances` (
  `id` int(10) NOT NULL,
  `title` text NOT NULL,
  `words` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `continuances`
--

INSERT INTO `continuances` (`id`, `title`, `words`) VALUES
(1, 'Continuances', 'below:'),
(2, 'Continuances', 'as follow:'),
(3, 'Continuances', 'following:'),
(4, 'Continuances', 'listed:'),
(5, 'Continuances', 'in particular:'),
(6, 'Continuances', 'supported:'),
(7, 'Continuances', 'and');

-- --------------------------------------------------------

--
-- Table structure for table `directives`
--

CREATE TABLE `directives` (
  `id` int(10) NOT NULL,
  `title` text NOT NULL,
  `words` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `directives`
--

INSERT INTO `directives` (`id`, `title`, `words`) VALUES
(1, 'Directives', 'e.g.'),
(2, 'Directives', 'i.e.'),
(3, 'Directives', 'for example'),
(4, 'Directives', 'figure'),
(5, 'Directives', 'table'),
(6, 'Directives', 'note:');

-- --------------------------------------------------------

--
-- Table structure for table `file`
--

CREATE TABLE `file` (
  `id` int(10) NOT NULL,
  `file` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `file`
--

INSERT INTO `file` (`id`, `file`) VALUES
(1317, 'txt.txt'),
(1318, 'txt.txt'),
(1319, 'txt.txt'),
(1320, 'txt.txt'),
(1321, 'txt.txt'),
(1322, 'txt.txt'),
(1323, 'txt.txt'),
(1324, 'txt.txt'),
(1325, 'txt.txt'),
(1326, 'txt.txt'),
(1327, 'txt.txt'),
(1328, 'txt.txt'),
(1329, 'txt.txt'),
(1330, 'txt.txt'),
(1331, 'txt.txt'),
(1332, 'txt.txt'),
(1333, 'txt.txt'),
(1334, 'txt.txt'),
(1335, 'txt.txt'),
(1336, 'txt.txt'),
(1337, 'txt.txt'),
(1338, 'txt.txt'),
(1339, 'txt.txt'),
(1340, 'txt.txt'),
(1341, 'txt.txt'),
(1342, 'txt.txt'),
(1343, 'txt.txt'),
(1344, 'txt.txt'),
(1345, 'txt.txt'),
(1346, 'txt.txt'),
(1347, 'txt.txt'),
(1348, 'txt.txt'),
(1349, 'txt.txt'),
(1350, 'txt.txt'),
(1351, 'txt.txt'),
(1352, 'txt.txt'),
(1353, 'txt.txt'),
(1354, 'txt.txt'),
(1355, 'txt.txt'),
(1356, 'txt.txt'),
(1357, 'txt.txt'),
(1358, 'txt.txt'),
(1359, 'txt.txt'),
(1360, 'txt.txt'),
(1361, 'txt.txt'),
(1362, 'txt.txt'),
(1363, 'txt.txt'),
(1364, 'txt.txt'),
(1365, 'txt.txt'),
(1366, 'txt.txt'),
(1367, 'txt.txt'),
(1368, 'txt.txt'),
(1369, 'txt.txt'),
(1370, 'txt.txt'),
(1371, 'txt.txt'),
(1372, 'txt.txt'),
(1373, 'txt.txt'),
(1374, 'txt.txt'),
(1375, 'txt.txt'),
(1376, 'txt.txt'),
(1377, 'txt.txt'),
(1378, 'txt.txt'),
(1379, 'txt.txt'),
(1380, 'txt.txt'),
(1381, 'txt.txt'),
(1382, 'txt.txt'),
(1383, 'txt.txt'),
(1384, 'txt.txt'),
(1385, 'txt.txt'),
(1386, 'txt.txt'),
(1387, 'txt.txt'),
(1388, 'txt.txt'),
(1389, 'txt.txt'),
(1390, 'txt.txt'),
(1391, 'txt.txt'),
(1392, 'txt.txt'),
(1393, 'txt.txt'),
(1394, 'txt.txt'),
(1395, 'txt.txt'),
(1396, 'txt.txt'),
(1397, 'txt.txt'),
(1398, 'txt.txt'),
(1399, 'txt.txt'),
(1400, 'txt.txt');

-- --------------------------------------------------------

--
-- Table structure for table `headings`
--

CREATE TABLE `headings` (
  `id` int(10) NOT NULL,
  `title` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `headings`
--

INSERT INTO `headings` (`id`, `title`) VALUES
(1, ' Introduction'),
(2, ' Overall Description'),
(3, ' Specific Requirements'),
(4, ' General characteristics'),
(5, 'Functional Requirements '),
(6, ' Non Functional Requirements ');

-- --------------------------------------------------------

--
-- Table structure for table `imperatives`
--

CREATE TABLE `imperatives` (
  `id` int(10) NOT NULL,
  `title` text NOT NULL,
  `words` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `imperatives`
--

INSERT INTO `imperatives` (`id`, `title`, `words`) VALUES
(1, 'Imperatives', 'shall'),
(2, 'Imperatives', 'must'),
(3, 'Imperatives', 'is required'),
(4, 'Imperatives', 'are applicable'),
(5, 'Imperatives', 'are too'),
(6, 'Imperatives', 'responsible for'),
(9, 'Imperatives', ' will'),
(10, 'Negative Imperatives', 'must not'),
(11, 'Negative_Imperatives', 'shall not'),
(12, 'Negative_Imperatives', 'is not required to'),
(13, 'Negative_Imperatives', 'are not to'),
(14, 'Negative_Imperatives', 'not responsible for'),
(15, 'Negative_Imperatives', 'will not'),
(16, 'Negative_Imperatives', 'should not');

-- --------------------------------------------------------

--
-- Table structure for table `negative_imperatives`
--

CREATE TABLE `negative_imperatives` (
  `id` int(11) NOT NULL,
  `title` text NOT NULL,
  `word` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `negative_imperatives`
--

INSERT INTO `negative_imperatives` (`id`, `title`, `word`) VALUES
(1, 'Negative imperatives', 'shall not'),
(2, 'Negative imperatives', 'must not'),
(3, 'Negative imperatives', 'is not required '),
(4, 'Negative imperatives', 'are not applicable'),
(5, 'Negative imperatives', 'are not to'),
(6, 'Negative imperatives', 'not responsible for'),
(7, 'Negative imperatives', 'will not'),
(8, 'Negative imperatives', 'should not');

-- --------------------------------------------------------

--
-- Table structure for table `options`
--

CREATE TABLE `options` (
  `id` int(10) NOT NULL,
  `title` text NOT NULL,
  `words` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `options`
--

INSERT INTO `options` (`id`, `title`, `words`) VALUES
(1, 'Options', 'can'),
(2, 'Options', 'may'),
(3, 'Options', 'optionally'),
(4, 'Options', 'should'),
(5, 'Options', 'will');

-- --------------------------------------------------------

--
-- Table structure for table `reqengg`
--

CREATE TABLE `reqengg` (
  `id` int(10) NOT NULL,
  `name` text NOT NULL,
  `requirement` text NOT NULL,
  `quality` text NOT NULL,
  `count` text NOT NULL,
  `Date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `reqengg`
--

INSERT INTO `reqengg` (`id`, `name`, `requirement`, `quality`, `count`, `Date`) VALUES
(1, '', 'i <span style="background-color: yellow;">shall</span>', '92 ', '2', '2018-03-18 11:49:48'),
(2, '', 'i <span style="background-color: yellow;">shall</span>', '92 ', '2', '2018-03-18 12:00:15'),
(3, '', 'i <span style="background-color: yellow;">shall</span>', '92 ', '2', '2018-03-18 12:02:34'),
(4, 'requirement', 'i <span style="background-color: yellow;">shall</span> be a', '92 ', '2', '2018-03-18 15:40:19'),
(5, 'requirement', 'i am', 'Statement contains no imperatives', 'no match', '2018-03-18 15:42:23'),
(6, 'requirement', 'i am', 'Statement contains no imperatives', 'no match', '2018-03-18 15:46:09'),
(7, 'requirement', 'i am', 'Statement contains no imperatives', 'no match', '2018-03-18 15:46:57'),
(8, 'requirement', 'i am', 'Statement contains no imperatives', 'no match', '2018-03-18 15:48:21'),
(9, 'requirement', 'i <span style="background-color: yellow;">shall</span> <span style="background-color: yellow;">and</span><span style="background-color: yellow;"> all </span><span style="background-color: yellow;">adequate</span> <span style="background-color: yellow;">most</span>', '53.20325203252', '7', '2018-03-19 10:04:14'),
(10, 'requirement', 'i <span style="background-color: yellow;">shall</span> <span style="background-color: yellow;">and</span><span style="background-color: yellow;"> all </span><span style="background-color: yellow;">adequate</span> <span style="background-color: yellow;">most</span>', '53.20325203252', '7', '2018-03-19 10:20:25'),
(11, 'requirement', 'i <span style="background-color: yellow;">shall</span> <span style="background-color: yellow;">and</span><span style="background-color: yellow;"> all </span><span style="background-color: yellow;">adequate</span> <span style="background-color: yellow;">most</span>', '53.20325203252', '7', '2018-03-19 10:21:07'),
(12, 'abdulah', 'my name is zeeshan aslam  from bsse 8th <span style="background-color: yellow;"><span style="background-color: yellow;"><span style="background-color: yellow;"><span style="background-color: yellow;"><span style="background-color: yellow;"><span style="background-color: yellow;"><span style="background-color: yellow;"><span style="background-color: yellow;">and</span></span></span></span></span></span></span></span> my name is zeeshan aslam  from bsse 8th <span style="background-color: yellow;"><span style="background-color: yellow;"><span style="background-color: yellow;"><span style="background-color: yellow;"><span style="background-color: yellow;"><span style="background-color: yellow;"><span style="background-color: yellow;"><span style="background-color: yellow;">and</span></span></span></span></span></span></span></span> my name is zeeshan aslam  from bsse 8th <span style="background-color: yellow;"><span style="background-color: yellow;"><span style="background-color: yellow;"><span style="background-color: yellow;"><span style="background-color: yellow;"><span style="background-color: yellow;"><span style="background-color: yellow;"><span style="background-color: yellow;">and</span></span></span></span></span></span></span></span> my name is zeeshan aslam  from bsse 8th <span style="background-color: yellow;"><span style="background-color: yellow;"><span style="background-color: yellow;"><span style="background-color: yellow;"><span style="background-color: yellow;"><span style="background-color: yellow;"><span style="background-color: yellow;"><span style="background-color: yellow;">and</span></span></span></span></span></span></span></span> my name is zeeshan aslam  from bsse 8th <span style="background-color: yellow;"><span style="background-color: yellow;"><span style="background-color: yellow;"><span style="background-color: yellow;"><span style="background-color: yellow;"><span style="background-color: yellow;"><span style="background-color: yellow;"><span style="background-color: yellow;">and</span></span></span></span></span></span></span></span> my name is zeeshan aslam  from bsse 8th <span style="background-color: yellow;"><span style="background-color: yellow;"><span style="background-color: yellow;"><span style="background-color: yellow;"><span style="background-color: yellow;"><span style="background-color: yellow;"><span style="background-color: yellow;"><span style="background-color: yellow;">and</span></span></span></span></span></span></span></span> my name is zeeshan aslam  from bsse 8th <span style="background-color: yellow;"><span style="background-color: yellow;"><span style="background-color: yellow;"><span style="background-color: yellow;"><span style="background-color: yellow;"><span style="background-color: yellow;"><span style="background-color: yellow;"><span style="background-color: yellow;">and</span></span></span></span></span></span></span></span> my name is zeeshan aslam  from bsse 8th <span style="background-color: yellow;"><span style="background-color: yellow;"><span style="background-color: yellow;"><span style="background-color: yellow;"><span style="background-color: yellow;"><span style="background-color: yellow;"><span style="background-color: yellow;"><span style="background-color: yellow;">and</span></span></span></span></span></span></span></span>', '8', '1', '2018-03-19 10:29:58'),
(13, 'abdulah', 'i <span style="background-color: yellow;">shall</span>', '92 ', '2', '2018-03-19 10:30:33'),
(14, 'requirement', 'i want a chair <span style="background-color: yellow;">and</span> i wish', '8', '1', '2018-03-19 10:52:03'),
(15, 'requirement', 'i have<span style="background-color: yellow;"> many </span>books <span style="background-color: yellow;">for example</span>', ' 8 ', '2', '2018-03-19 11:12:16'),
(16, 'requirement', '<span style="background-color: yellow;">easy</span> <span style="background-color: yellow;">and</span>', '12 ', '2', '2018-03-19 11:13:41'),
(17, 'requirement', '<span style="background-color: yellow;">easy</span> <span style="background-color: yellow;">and</span>', '65.5 ', '2', '2018-03-19 11:15:28'),
(18, 'requirement', '<span style="background-color: yellow;">easy</span> <span style="background-color: yellow;">and</span>', '0', '2', '2018-03-19 11:25:24'),
(19, 'requirement', '<span style="background-color: yellow;">easy</span> <span style="background-color: yellow;">and</span>', '0', '2', '2018-03-19 11:26:47'),
(20, 'requirement', '<span style="background-color: yellow;">easy</span> <span style="background-color: yellow;">and</span>', '0', '2', '2018-03-19 11:27:30'),
(21, 'requirement', '<span style="background-color: yellow;">easy</span> <span style="background-color: yellow;">and</span>', '0', '2', '2018-03-19 11:27:34'),
(22, 'requirement', '<span style="background-color: yellow;">easy</span> <span style="background-color: yellow;">and</span>', '0', '2', '2018-03-19 11:31:32'),
(23, 'requirement', '<span style="background-color: yellow;">easy</span> <span style="background-color: yellow;">and</span>', '0', '2', '2018-03-19 11:32:32'),
(24, 'requirement', '<span style="background-color: yellow;">easy</span> <span style="background-color: yellow;">and</span>', '0', '2', '2018-03-19 11:32:55'),
(25, 'requirement', '<span style="background-color: yellow;">easy</span> <span style="background-color: yellow;">and</span>', '0', '2', '2018-03-19 11:33:13'),
(26, 'requirement', '<span style="background-color: yellow;">easy</span> <span style="background-color: yellow;">and</span>', ' 0', '2', '2018-03-19 11:35:31'),
(27, 'requirement', 'i want a chair <span style="background-color: yellow;">and</span> a book', '8', '1', '2018-03-19 13:32:17'),
(28, 'requirement', 'i want a chair <span style="background-color: yellow;">and</span> a book', '8', '1', '2018-03-19 19:05:18'),
(29, 'requirement', 'i want a chair <span style="background-color: yellow;">and</span> a book can', ' 6 ', '2', '2018-03-19 19:09:34'),
(30, 'requirement', 'i want a chair <span style="background-color: yellow;">and</span> a book can', ' 6 ', '2', '2018-03-19 20:09:15'),
(31, 'requirement', 'i <span style="background-color: yellow;">shall</span> be', '92 ', '2', '2018-03-19 20:09:35'),
(32, 'requirement', 'i <span style="background-color: yellow;">must</span> be', '92 ', '2', '2018-03-19 20:09:43'),
(33, 'requirement', 'i <span style="background-color: yellow;">must</span> <span style="background-color: yellow;">and</span> <span style="background-color: yellow;">will</span><span style="background-color: yellow;"> can </span><span style="background-color: yellow;">most</span> <span style="background-color: yellow;">always</span>', '55 ', '7', '2018-03-19 20:10:03'),
(34, 'requirement', 'i <span style="background-color: yellow;">must</span> <span style="background-color: yellow;">and</span> <span style="background-color: yellow;">will</span><span style="background-color: yellow;"> can </span><span style="background-color: yellow;">most</span> <span style="background-color: yellow;">always</span>', '55 ', '7', '2018-03-19 22:27:14'),
(35, 'requirement', 'i <span style="background-color: yellow;">must</span> <span style="background-color: yellow;">and</span> <span style="background-color: yellow;">will</span><span style="background-color: yellow;"> can </span><span style="background-color: yellow;">most</span> <span style="background-color: yellow;">always</span>', '55 ', '7', '2018-03-19 22:45:40'),
(36, 'requirement', 'i <span style="background-color: yellow;">must</span>', '92 ', '2', '2018-03-19 22:45:48'),
(37, 'requirement', 'i <span style="background-color: yellow;">must</span> <span style="background-color: yellow;">shall</span>', '4 ', '4', '2018-03-19 22:46:35'),
(38, 'requirement', 'i <span style="background-color: yellow;">shall</span> be a <span style="background-color: yellow;">good</span> boy <span style="background-color: yellow;">and</span> <span style="background-color: yellow;">must</span>', '4 ', '6', '2018-03-20 19:16:33'),
(39, 'requirement', 'i <span style="background-color: yellow;">shall</span>', '92 ', '2', '2018-03-21 17:34:17'),
(40, 'requirement', 'i <span style="background-color: yellow;">shall</span>', '92 ', '2', '2018-03-21 17:35:16'),
(41, 'requirement', 'i <span style="background-color: yellow;">shall</span>', '92 ', '2', '2018-03-21 17:35:29'),
(42, 'requirement', 'i <span style="background-color: yellow;">shall</span>', '92 ', '2', '2018-03-21 17:38:19'),
(43, 'requirement', 'i <span style="background-color: yellow;">shall</span>', '92 ', '2', '2018-03-26 16:26:00');

-- --------------------------------------------------------

--
-- Table structure for table `srswords`
--

CREATE TABLE `srswords` (
  `id` int(10) NOT NULL,
  `title` text NOT NULL,
  `words` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `srswords`
--

INSERT INTO `srswords` (`id`, `title`, `words`) VALUES
(1, 'Imperatives', 'Shall '),
(2, 'Imperatives', 'must'),
(3, 'Imperatives', 'is required to'),
(4, 'Imperatives', 'are applicable '),
(5, 'Imperatives', 'responsible for'),
(6, 'Imperatives', 'will'),
(7, 'Imperatives', 'should'),
(8, 'Imperatives', 'are too'),
(9, 'Universal quantifiers', 'always'),
(10, 'Universal quantifiers', 'any'),
(11, 'Universal quantifiers', 'every'),
(12, 'Universal quantifiers', 'no '),
(13, 'Universal quantifiers', 'never'),
(14, 'Universal quantifiers', 'none'),
(15, 'Universal quantifiers', 'nothing'),
(16, 'Universal quantifiers', 'each'),
(17, 'Universal quantifiers', 'many'),
(18, 'Universal quantifiers', 'most'),
(19, 'Universal quantifiers', 'often'),
(20, 'Universal quantifiers', 'usually'),
(21, 'Directives', 'e.g.'),
(22, 'Directives', 'i.e.'),
(23, 'Directives', 'for example'),
(24, 'Directives', 'figure'),
(25, 'Directives', 'table '),
(26, 'Directives', 'note:'),
(27, 'Vagues', 'adequate'),
(28, 'Vagues', ' all '),
(29, 'Vagues', 'appropriate'),
(30, 'Vagues', 'as big'),
(31, 'Vagues', 'as possible'),
(32, 'Vagues', 'as required'),
(33, 'Vagues', 'as small'),
(34, 'Vagues', 'as soon as possible'),
(35, 'Vagues', 'at a given time'),
(36, 'Vagues', 'bad'),
(37, 'Vagues', ' be able to'),
(38, 'Vagues', 'be capable of'),
(39, 'Vagues', 'beautiful'),
(40, 'Vagues', 'better'),
(41, 'Vagues', 'capability'),
(42, 'Vagues', 'completely'),
(43, 'Vagues', 'consistent'),
(44, 'Vagues', 'correct'),
(45, 'Vagues', 'currently'),
(46, 'Vagues', 'custom'),
(47, 'Vagues', 'customize'),
(48, 'Vagues', 'easy'),
(49, 'Vagues', 'effective'),
(50, 'Vagues', 'effecient'),
(51, 'Vagues', 'enough'),
(52, 'Vagues', 'etc'),
(53, 'Vagues', 'every'),
(54, 'Vagues', 'faithfully'),
(55, 'Vagues', 'far'),
(56, 'Vagues', 'fast'),
(57, 'Vagues', 'flexible'),
(58, 'Vagues', 'formerly'),
(59, 'Vagues', 'good'),
(60, 'Vagues', 'harmonious'),
(61, 'Vagues', 'immediately'),
(62, 'Vagues', 'improved'),
(63, 'Vagues', 'improving'),
(64, 'Vagues', 'in mind'),
(65, 'Vagues', 'in the past'),
(66, 'Vagues', 'instantly'),
(67, 'Vagues', 'it '),
(68, 'Vagues', 'judiciously'),
(69, 'Vagues', 'lately'),
(70, 'Vagues', 'later'),
(71, 'Vagues', 'legible'),
(72, 'Vagues', 'leverage'),
(73, 'Vagues', 'maximal'),
(74, 'Vagues', 'maximize'),
(75, 'Vagues', 'maximizing'),
(76, 'Vagues', 'meaningful'),
(77, 'Vagues', 'minimal'),
(78, 'Vagues', 'minimize'),
(79, 'Vagues', 'minimizing'),
(80, 'Vagues', 'normal'),
(81, 'Vagues', 'not limited to'),
(82, 'Vagues', 'optimal'),
(83, 'Vagues', 'precise'),
(84, 'Vagues', 'presently'),
(85, 'Vagues', 'promptly'),
(86, 'Vagues', 'proper'),
(87, 'Vagues', 'provide for'),
(88, 'Vagues', 'quickly'),
(89, 'Vagues', 'readily'),
(90, 'Vagues', 'realistic'),
(91, 'Vagues', 'reasonable '),
(92, 'Vagues', 'reasonably'),
(93, 'Vagues', 'recent'),
(94, 'Vagues', 'reflect'),
(95, 'Vagues', 'represent'),
(96, 'Vagues', 'representable'),
(97, 'Vagues', 'seamless'),
(98, 'Vagues', 'significant'),
(99, 'Vagues', 'similar'),
(100, 'Vagues', 'similarly'),
(101, 'Vagues', 'simple'),
(102, 'Vagues', 'simplified'),
(103, 'Vagues', 'simultaneously'),
(104, 'Vagues', 'smoothly'),
(105, 'Vagues', 'some'),
(107, 'Vagues', 'strong'),
(108, 'Vagues', 'such as'),
(109, 'Vagues', 'sufficient'),
(110, 'Vagues', 'suitable '),
(111, 'Vagues', 'take into account'),
(112, 'Vagues', 'take into consideration'),
(113, 'Vagues', 'TBC'),
(114, 'Vagues', 'TBD'),
(115, 'Vagues', 'timely'),
(116, 'Vagues', 'to date'),
(117, 'Vagues', 'tolerable '),
(118, 'Vagues', 'typical'),
(119, 'Vagues', 'universal'),
(120, 'Vagues', 'up to'),
(121, 'Vagues', 'useful'),
(122, 'Vagues', 'usefully'),
(123, 'Vagues', 'user friendly'),
(124, 'Vagues', 'versatile'),
(125, 'Vagues', 'widely'),
(126, 'Vagues', 'worse'),
(127, 'Vagues', 'year ago'),
(128, 'Vagues', 'number of times'),
(129, 'Vagues', 'standard');

-- --------------------------------------------------------

--
-- Table structure for table `universal_quantifiers`
--

CREATE TABLE `universal_quantifiers` (
  `id` int(11) NOT NULL,
  `title` text NOT NULL,
  `words` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `universal_quantifiers`
--

INSERT INTO `universal_quantifiers` (`id`, `title`, `words`) VALUES
(1, 'Universal quantifiers', 'all'),
(2, 'Universal quantifiers', 'always'),
(3, 'Universal quantifiers', 'any'),
(4, 'Universal quantifiers', 'every'),
(5, 'Universal quantifiers', 'no'),
(6, 'Universal quantifiers', 'never'),
(7, 'Universal quantifiers', 'none'),
(8, 'Universal quantifiers', 'nothing'),
(9, 'Universal quantifiers', 'each'),
(10, 'Universal quantifiers', 'many'),
(11, 'Universal quantifiers', 'most'),
(12, 'Universal quantifiers', 'often'),
(13, 'Universal quantifiers', 'usually');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `userId` int(11) NOT NULL,
  `userName` varchar(200) NOT NULL,
  `userEmail` varchar(200) NOT NULL,
  `userPass` text NOT NULL,
  `datet` datetime(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`userId`, `userName`, `userEmail`, `userPass`, `datet`) VALUES
(1, 'requirement', 'req@gmail.com', '7554bcbdb6632a441160510f082a14437c19e54fe6a129dcfed571d2b93f4edf', '2018-03-03 13:43:42.0');

-- --------------------------------------------------------

--
-- Table structure for table `vagues`
--

CREATE TABLE `vagues` (
  `id` int(10) NOT NULL,
  `title` text NOT NULL,
  `words` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vagues`
--

INSERT INTO `vagues` (`id`, `title`, `words`) VALUES
(1, 'Vagues', 'adequate'),
(2, 'Vagues', 'adequately'),
(3, 'vagues', 'all appropriate'),
(4, 'vagues', 'as appropriate'),
(5, 'vagues', 'as big'),
(6, 'vagues', 'as possible'),
(7, 'vagues', 'as required'),
(8, 'vagues', 'as small'),
(9, 'vagues', 'as soon as possible'),
(10, 'vagues', 'at a given time'),
(11, 'vagues', 'bad'),
(12, 'vagues', 'ba able to');

-- --------------------------------------------------------

--
-- Table structure for table `words_catagories`
--

CREATE TABLE `words_catagories` (
  `Imperatives` text NOT NULL,
  `Negative_Imperatives` text NOT NULL,
  `Vagues` text NOT NULL,
  `Options` text NOT NULL,
  `Continuances` text NOT NULL,
  `Directives` text NOT NULL,
  `Universal_quantifiers` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `words_catagories`
--

INSERT INTO `words_catagories` (`Imperatives`, `Negative_Imperatives`, `Vagues`, `Options`, `Continuances`, `Directives`, `Universal_quantifiers`) VALUES
('shall,must,is required to,are applicable,are too,responsible for,will', 'shall not,must not,is not required to,are not applicable,are not to,not responsible for,will not,should not', 'adequate,adequately,all,appropriate,as appropriate,as big,as possible,as required,as small,as soon as possible,at a given time,bad,be able to,be capable of,beautiful,better,capability of,capability to,completely,consistent with,correct,correctly,currently,custom,customize,customized,customizing,easy,easily,effective,efficient,efficiently,enough,etc,every,faithfully,far,fast,flexible,formerly,good,harmonious,immediately,improved,improving,in mind,in the past,instantly,it,judiciously,lately,later,legible,leverage,maximal,maximize,maximise,maximized,maximizing,meaningful,minimal,minimise,minimize,minimized,minimizing,normal,not limited to,optimal,precise,presently,promptly,proper,provide for,quickly,readily,realistic,realistically,reasonable,reasonably,recent,recently,reflect,represent,representable,representative,seamless,seamlessly,significant,significantly,similar,similarly,simple,simplified,simultaneous,smoothly,some,standard,strong,such as,sufficient,sufficiently,suitable,take into account,take into consideration,TBC,TBD,timely,to date,tolerable,typical,universal,up to,useful,usefully,user friendly,versatile,widely,worse,year ago', 'can,may,optionally,should', 'below: ,as follow: ,following: ,listed: ,in particular: ,supported: ,and', 'e.g. ,i.e. ,for example,figure,table,note: ', 'all,always,any,every,no,never,none,nothing,each,many,most,often,usually');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `all_words`
--
ALTER TABLE `all_words`
  ADD PRIMARY KEY (`id`);
ALTER TABLE `all_words` ADD FULLTEXT KEY `words` (`words`);

--
-- Indexes for table `continuances`
--
ALTER TABLE `continuances`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `directives`
--
ALTER TABLE `directives`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `file`
--
ALTER TABLE `file`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `headings`
--
ALTER TABLE `headings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `imperatives`
--
ALTER TABLE `imperatives`
  ADD PRIMARY KEY (`id`);
ALTER TABLE `imperatives` ADD FULLTEXT KEY `words` (`words`);
ALTER TABLE `imperatives` ADD FULLTEXT KEY `words_2` (`words`);
ALTER TABLE `imperatives` ADD FULLTEXT KEY `words_3` (`words`);

--
-- Indexes for table `negative_imperatives`
--
ALTER TABLE `negative_imperatives`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `options`
--
ALTER TABLE `options`
  ADD PRIMARY KEY (`id`);
ALTER TABLE `options` ADD FULLTEXT KEY `words` (`words`);

--
-- Indexes for table `reqengg`
--
ALTER TABLE `reqengg`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `srswords`
--
ALTER TABLE `srswords`
  ADD PRIMARY KEY (`id`);
ALTER TABLE `srswords` ADD FULLTEXT KEY `words` (`words`);
ALTER TABLE `srswords` ADD FULLTEXT KEY `title` (`title`);
ALTER TABLE `srswords` ADD FULLTEXT KEY `words_2` (`words`);

--
-- Indexes for table `universal_quantifiers`
--
ALTER TABLE `universal_quantifiers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`userId`);

--
-- Indexes for table `vagues`
--
ALTER TABLE `vagues`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `words_catagories`
--
ALTER TABLE `words_catagories` ADD FULLTEXT KEY `Universal_quantifiers` (`Universal_quantifiers`);
ALTER TABLE `words_catagories` ADD FULLTEXT KEY `Imperatives` (`Imperatives`);
ALTER TABLE `words_catagories` ADD FULLTEXT KEY `Negative_Imperatives` (`Negative_Imperatives`);
ALTER TABLE `words_catagories` ADD FULLTEXT KEY `Vagues` (`Vagues`);
ALTER TABLE `words_catagories` ADD FULLTEXT KEY `Options` (`Options`);
ALTER TABLE `words_catagories` ADD FULLTEXT KEY `Continuances` (`Continuances`);
ALTER TABLE `words_catagories` ADD FULLTEXT KEY `Directives` (`Directives`);
ALTER TABLE `words_catagories` ADD FULLTEXT KEY `Imperatives_2` (`Imperatives`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `all_words`
--
ALTER TABLE `all_words`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=178;
--
-- AUTO_INCREMENT for table `continuances`
--
ALTER TABLE `continuances`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `directives`
--
ALTER TABLE `directives`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `file`
--
ALTER TABLE `file`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1401;
--
-- AUTO_INCREMENT for table `headings`
--
ALTER TABLE `headings`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `imperatives`
--
ALTER TABLE `imperatives`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT for table `negative_imperatives`
--
ALTER TABLE `negative_imperatives`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `options`
--
ALTER TABLE `options`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `reqengg`
--
ALTER TABLE `reqengg`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;
--
-- AUTO_INCREMENT for table `srswords`
--
ALTER TABLE `srswords`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=130;
--
-- AUTO_INCREMENT for table `universal_quantifiers`
--
ALTER TABLE `universal_quantifiers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `userId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `vagues`
--
ALTER TABLE `vagues`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
