<?php
  ob_start();
  session_start();
  require_once 'database1.php';
  if( !isset($_SESSION['user']) ) {
    header("Location: ../../index.php");
    exit;
  }
  
  $res=mysqli_query($connection,"SELECT * FROM users WHERE userId=".$_SESSION['user']);
   while ($userRow=mysqli_fetch_array($res)) {
  $name=$userRow['userName'];
  $email=$userRow['userEmail'];

  } 
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Welcome - <?php echo $name; ?></title>


 <link rel="stylesheet" type="text/css" href="assets/css/bootstrap.css">
<link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">
<script type="text/javascript" src="assets/js/bootstrap.js"></script>
<script type="text/javascript" src="assets/js/bootstrap.min.js"></script>
<script type="text/javascript" src="assets/jquery/jquery.min.js"></script>
<script type="text/javascript" src="assets/jquery/jquery-3.2.1.min.js"></script>
<script type="text/javascript" src="assets/js/transition.js"></script>
<script type="text/javascript" src="assets/js/collapse.js"></script>
<script type="text/javascript" src="assets/js/dropdown.js"></script>
 <style>
  body {
      font: 400 15px Lato, sans-serif;
      line-height: 1.8;
     
  }
  h2 {
      font-size: 24px;
      text-transform: uppercase;
      color: #303030;
      font-weight: 600;
      margin-bottom: 30px;
  }
  h4 {
      font-size: 19px;
      line-height: 1.375em;
      color: #303030;
      font-weight: 400;
      margin-bottom: 30px;
  }  
  .jumbotron {
      background-color:black;
      color: #fff;
      padding: 100px 25px;
      font-family: Montserrat, sans-serif;
  }
  .container-fluid {
      padding: 60px 50px;
  }
  .bg-grey {
      background-color: #f6f6f6;
  }
  .logo-small {
      color: #330033;
      font-size: 50px;
  }
  .logo {
    margin-top: 120px;
      color: black;
      font-size: 200px;
  }
  .thumbnail {
      padding: 0 0 15px 0;
      border: none;
      border-radius: 0;
  }
  .thumbnail img {
      width: 100%;
      height: 100%;
      margin-bottom: 10px;
  }
  .carousel-control.right, .carousel-control.left {
      background-image: none;
      color: #f4511e;
  }
  .carousel-indicators li {
      border-color: #f4511e;
  }
  .carousel-indicators li.active {
      background-color: #f4511e;
  }
  .item h4 {
      font-size: 19px;
      line-height: 1.375em;
      font-weight: 400;
      font-style: italic;
      margin: 70px 0;
  }
  .item span {
      font-style: normal;
  }
  .panel {
      border: 1px solid #f4511e; 
      border-radius:0 !important;
      transition: box-shadow 0.5s;
  }
  .panel:hover {
      box-shadow: 5px 0px 40px rgba(0,0,0, .2);
  }
  .panel-footer .btn:hover {
      border: 1px solid #330033;
      background-color: #fff !important;
      color: #330033;
  }
  .panel-heading {
      color: #fff !important;
      background-color: #f4511e !important;
      padding: 25px;
      border-bottom: 1px solid transparent;
      border-top-left-radius: 0px;
      border-top-right-radius: 0px;
      border-bottom-left-radius: 0px;
      border-bottom-right-radius: 0px;
  }
  .panel-footer {
      background-color: white !important;
  }
  .panel-footer h3 {
      font-size: 32px;
  }
  .panel-footer h4 {
      color: #aaa;
      font-size: 14px;
  }
  .panel-footer .btn {
      margin: 15px 0;
      background-color: #330033;
      color: #fff;
  }
  .navbar {
      margin-bottom: 0;
      background-color: purple;
      z-index: 9999;
      border: 0;
      font-size: 12px !important;
      line-height: 1.42857143 !important;
      letter-spacing: 4px;
      border-radius: 0;
      font-family: Montserrat, sans-serif;
  }
  .navbar li a, .navbar  {
     
  }
  .navbar-nav li a:hover, .navbar-nav li.active a {
      color: #330033 !important;
      background-color: #E8DAEF !important;
  }
  .navbar-default .navbar-toggle {
      border-color: transparent;
      color: #fff !important;
  }
  footer .glyphicon {
      font-size: 20px;
      margin-bottom: 20px;
      color: #330033;
  }
  .slideanim {visibility:hidden;}
  .slide {
      animation-name: slide;
      -webkit-animation-name: slide;
      animation-duration: 1s;
      -webkit-animation-duration: 1s;
      visibility: visible;
  }
  @keyframes slide {
    0% {
      opacity: 0;
      transform: translateY(70%);
    } 
    100% {
      opacity: 1;
      transform: translateY(0%);
    }
  }
  @-webkit-keyframes slide {
    0% {
      opacity: 0;
      -webkit-transform: translateY(70%);
    } 
    100% {
      opacity: 1;
      -webkit-transform: translateY(0%);
    }
  }
  @media screen and (max-width: 768px) {
    .col-sm-4 {
      text-align: center;
      margin: 25px 0;
    }
    .btn-lg {
        width: 100%;
        margin-bottom: 35px;
    }
  }
  @media screen and (max-width: 480px) {
    .logo {
        font-size: 150px;
    }
  }
  </style>
</head>
<body>

<nav class="navbar navbar-default navbar-fixed-top">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
             <a class="navbar-brand" href="../main.php" style="margin-top: -9px;">
        <img alt="Brand" src="pic.jpg" width="60px" height="40px">
      </a>
        </div>
          <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav">
            <li ><a style="color: #fff;" href="../main.php">Home</a></li>
            <li ><a style="color: #fff;" href="all.php">Single Requirement</a></li> 
          </ul>
          <ul class="nav navbar-nav navbar-right"> 
          
            <li class="dropdown ">
              <a href="#" style="color: #fff;" class=" dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false" data-target="dropdown-item">
         <span class="glyphicon glyphicon-user"></span>&nbsp;Hi' <?php echo $name; ?>&nbsp;<span class="caret"></span></a>
              <ul class="dropdown-menu ">
                <li class="dropdown-item " ><a href="logout.php?logout"><span class="glyphicon glyphicon-log-out"></span>&nbsp;Sign Out</a></li>
              </ul>
            </li>
          </ul>
        </div><!--/.nav-collapse -->
      </div>
    </nav> 
    <nav>

  <div id="wrapper">

  <div class="container">
    
      <div class="page-header"><br>
      <h3 align="center" style="font-size: 50px; font-weight: bold; text-shadow: 2px 2px rgb(128,128,128); ">Requirement Statements</h3>
      </div>
        
        <div class="row">
        <div class="col-lg-12">

        <table  class="table table-bordered table-responsive"  width="auto"  >
      
    <tr>
      <td align="center" style="font-weight: bold; font-size: 25px;">Id</td>
      <td align="center" style="font-weight: bold; font-size: 25px;">Name</td>
      <td align="center" style="font-weight: bold; font-size: 25px;">Requirement</td>
      <td align="center" style="font-weight: bold; font-size: 25px;">Quality</td>
     
      <td align="center" style="font-weight: bold; font-size: 25px;">Date and time</td>
      
    </tr>
   <?php


$i=0;
/////////display user stored info///////

$res=mysqli_query($connection,"SELECT * FROM users WHERE userId=".$_SESSION['user']);
   while ($userRow=mysqli_fetch_array($res)) {
  $name=$userRow['userName'];
  $em=$userRow['userEmail'];
  } 
$res=mysqli_query($connection,"SELECT * FROM reqengg WHERE email='$em'  ");
   while ($userRow=mysqli_fetch_array($res)) {
    $i++;
  $id=$userRow['id'];
  $name=$userRow['name'];
  $require=$userRow['requirement'];
  $quality=$userRow['quality'];
  //$count=$userRow['count'];
  $date=$userRow['Date'];

   
    
  ?>
    <tr>
      <td><b><?php echo $i;?></b></td>
      <td><?php echo $name;?></td>
      <td><?php echo $require;?></td>
      <td><?php

if ($quality > 0) {
   echo $quality."%";
}
else
{
   echo "Statement contain no imperative";
}
      ?></td>
     
      <td align="center"><?php echo $date;?></td>
      
     
     
    </tr>
<?php }?>
        </table>
        </div>
        </div>
    
    </div>
    
    </div>
    
  
</body>
</html>

</body>
</html>
